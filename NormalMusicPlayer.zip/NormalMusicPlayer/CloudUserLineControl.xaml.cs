﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using NormalMusicPlayer.Sql;
using NormalFTP;
using LaoyaosFile;
using System.IO;
using LaoyaosImage;

namespace NormalMusicPlayer
{
    /// <summary>
    /// CloudUserLineControl.xaml 的交互逻辑
    /// </summary>
    public partial class CloudUserLineControl : UserControl
    {
        private bool IsChoosed = false;
        private const int IconWH = 80;

        /// <summary>
        /// 线被点击事件代理
        /// </summary>
        /// <param name="sender">发送者</param>
        /// <param name="userID">用户ID</param>
        public delegate void LineClickEventDel(CloudUserLineControl sender , NormalMusicUserInformation user);

        private LineClickEventDel LineClickEvent = null;
        private NormalMusicUserInformation UserInformation = null;

        public CloudUserLineControl()
        {
            InitializeComponent();
        }

        public CloudUserLineControl(NormalMusicUserInformation user, LineClickEventDel click)
        {
            InitializeComponent();

            UserInformation = user;
            LineClickEvent = click;

            NameTextBlock.Text = user.Name;

            SetUserIconAsync();
        }


        private async void SetUserIconAsync()
        {
            //用户ICON缓存路径
            string buffPath = FileStruct.UserIconBuffBook + "\\" + UserInformation.ID + ".jpg";
            FileInfo checkForExist = new FileInfo(buffPath);

            if(checkForExist.Exists)
            {
                UserIcon.Source = JPGImage.ResizeImage(buffPath, IconWH, IconWH);
            }
            else
            {
                await Task.Run(() =>
                {
                    bool isTaskSuccess = false;

                    MainWindow.NormalFTP.DownLoadFile(buffPath, UserInformation.BelongBookPath + "\\" + NormalFTPFileStruct.UserIconName, (NormalFTPControl.FTPDisposeStateEnum state, double percentage, string message) =>
                    {
                        if (state == NormalFTPControl.FTPDisposeStateEnum.Finished)
                        {
                            isTaskSuccess = true;
                        }
                    });

                    //如果成功下载则显示图片，否则则显示默认
                    if (isTaskSuccess)
                    {
                        this.Dispatcher.Invoke(() =>
                        {
                            UserIcon.Source = JPGImage.ResizeImage(buffPath, IconWH, IconWH);
                        });
                    }
                });
            }
            
        }

        private void ContainGrid_MouseEnter(object sender, MouseEventArgs e)
        {
            if (!IsChoosed)
            {
                ContainGrid.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#AFB7B7B7"));
            }
        }

        /// <summary>
        /// 取消被选择
        /// </summary>
        public void UnChoosed()
        {
            IsChoosed = false;
            ContainGrid.Background = null;
        }

        private void ContainGrid_MouseLeave(object sender, MouseEventArgs e)
        {
            if (!IsChoosed)
            {
                ContainGrid.Background = null;
            }
        }

        private void ContainGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            CloudLineChoosed();
        }

        /// <summary>
        /// 音乐集合被选择事件 ， 此事件外部只能在初始化时设置默认音乐集合被选择时调用、
        /// </summary>
        public void CloudLineChoosed()
        {
            //防止被重复点击，重复执行
            if (IsChoosed)
            {
                return;
            }
            IsChoosed = true;
            ContainGrid.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#AFB7B7B7"));

            //调用委托函数
            if (LineClickEvent != null)
            {
                LineClickEvent.Invoke(this , UserInformation);
            }
        }
    }
}
