﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NormalMusicPlayer
{
    /// <summary>
    /// LaoyaosDialogBoxForSure.xaml 的交互逻辑
    /// </summary>
    public partial class LaoyaosDialogBoxForSure : Window
    {
        /// <summary>
        /// 确认对话框
        /// </summary>
        /// <param name="message">确认信息</param>
        public LaoyaosDialogBoxForSure(string message)
        {
            InitializeComponent();
            MessageTextBox.Text = message;
        }

        //点击离开，直接返回false
        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private void BaseTopGrid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            //move the windows
            this.DragMove();
        }

        private void YesOrNoButton_MouseEnter(object sender, MouseEventArgs e)
        {
            Border button = (Border)sender;
            button.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFD2D2D2"));
        }

        private void YesOrNoNoButton_MouseLeave(object sender, MouseEventArgs e)
        {
            Border button = (Border)sender;
            button.Background = null;
        }
        //点击yes 则返回true
        private void YesButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            this.DialogResult = true;
        }

        //点击No按钮直接返回结果为false
        private void NoButton_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}
