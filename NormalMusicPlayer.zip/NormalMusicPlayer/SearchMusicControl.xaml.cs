﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LaoyaosMedia;
using System.Windows.Media.Animation;


namespace NormalMusicPlayer
{
    /// <summary>
    /// SearchMusicControl.xaml 的交互逻辑
    /// </summary>
    public partial class SearchMusicControl : UserControl
    {
        //网络音乐没有总上下文 ， 不能执行上移动或者下移动或者随机操作
        //全局上下文
        //private List<MusicPlayBarGridControl.MusicContextSingle> TotalContext = null;

        private NetMusicSearch MusicSearchControl = null;
        //一次获取的歌曲数目
        private const int OnceGetResultSongNumber = 10;
        //正在播放的网络歌曲显示栏
        private SearchResultSongDisplayGrid NowPlayingNetSongDisplay = null;

        public SearchMusicControl()
        {
            InitializeComponent();
            //初始化集合
            //TotalContext = new List<MusicPlayBarGridControl.MusicContextSingle>();
            //隐藏信息显示label
            MessageDisplayLabel.Visibility = Visibility.Collapsed;
            //隐藏查看更多按钮
            SeeMoreGrid.Visibility = Visibility.Collapsed;
            //隐藏加载界面
            LoadingUIDisappear();
        }

        private void SearchBeginButton_Click(object sender, RoutedEventArgs e)
        {
            //拥有关键字才会开始搜索
            if(SearchTextBox.Text != string.Empty)
            {
                BeginSearch();
            }
        }

        private async void BeginSearch()
        {
            //获取搜索的关键字
            string sreachWords = SearchTextBox.Text;

            //禁止操作搜索栏
            SearchTextBox.IsEnabled = false;
            //禁止操作开始搜索按钮
            SearchBeginButton.IsEnabled = false;
            //禁止操作更多按钮
            SeeMoreButton.IsEnabled = false;
            //隐藏查看更多按钮
            SeeMoreGrid.Visibility = Visibility.Collapsed;
            //隐藏信息显示label
            MessageDisplayLabel.Visibility = Visibility.Collapsed;
            //清除之前已经搜索的所有
            SreachResultStackControlPanel.Children.Clear();
            //清空所有集合子集
            //TotalContext.Clear();
            //重置正在播放的网络歌曲显示栏，因为实例已经被清除了，所以不能再操作
            NowPlayingNetSongDisplay = null;

            LoadingUIAppear();

            await Task.Run(() =>
            {
                string errorMessage = null;
                List<NetMusicSearch.SongInformation> informations = null;

                //设置关键字
                MusicSearchControl = new NetMusicSearch(sreachWords);
                //开始搜索
                errorMessage = MusicSearchControl.SearchhSong(OnceGetResultSongNumber, out informations);

                //成功获取
                if(errorMessage == string.Empty)
                {
                    this.Dispatcher.Invoke(() =>
                    {
                        //允许操作搜索栏
                        SearchTextBox.IsEnabled = true;
                        //允许操作开始搜索按钮
                        SearchBeginButton.IsEnabled = true;
                        //隐藏错误显示栏
                        MessageDisplayLabel.Visibility = Visibility.Collapsed;

                        //开启查看更多gird
                        SeeMoreGrid.Visibility = Visibility.Visible;
                        if (MusicSearchControl.HadGetNumber == MusicSearchControl.SongTotalCount)
                        {
                            //禁止操作更多按钮
                            SeeMoreButton.IsEnabled = false;
                        }
                        else
                        {
                            //开启操作更多按钮
                            SeeMoreButton.IsEnabled = true;
                        }
                        //显示以获取和获取总数
                        SearchResultNumberTextBlock.Text = MusicSearchControl.HadGetNumber + "/" + MusicSearchControl.SongTotalCount;

                        //将所有获取信息添加到管理grid内
                        for(int counter = 0; counter < informations.Count; counter++)
                        {
                            MusicPlayBarGridControl.MusicContextSingle single = new MusicPlayBarGridControl.MusicContextSingle(informations[counter]);
                            //TotalContext.Add(single);
                            SearchResultSongDisplayGrid display = new SearchResultSongDisplayGrid(single/*, TotalContext*/ , SingleSongDoubleClick);
                            SreachResultStackControlPanel.Children.Add(display);
                        }
                    });
                }
                //获取失败
                else
                {
                    this.Dispatcher.Invoke(() =>
                    {
                        //允许操作搜索栏
                        SearchTextBox.IsEnabled = true;
                        //允许操作开始搜索按钮
                        SearchBeginButton.IsEnabled = true;
                        //开启信息显示label
                        MessageDisplayLabel.Visibility = Visibility.Visible;
                        //显示错误信息
                        MessageDisplayLabel.Content = errorMessage;
                    });
                    
                }

                this.Dispatcher.Invoke(() =>
                {
                    LoadingUIDisappear();
                });
            });
        }

        private void SingleSongDoubleClick(SearchResultSongDisplayGrid sender)
        {
            if(NowPlayingNetSongDisplay == null)
            {
                NowPlayingNetSongDisplay = sender;
                return;
            }

            if(NowPlayingNetSongDisplay != sender)
            {
                //设置为没有被选择
                NowPlayingNetSongDisplay.UnChoosed();
                NowPlayingNetSongDisplay = sender;
            }
        }

        private void SeeMoreButton_Click(object sender, RoutedEventArgs e)
        {
            SeeMore();
        }
    
        public void LoadingUIDisappear()
        {
            //隐藏下载loading界面
            LoadingAnimatioGrid.Visibility = Visibility.Collapsed;
            //禁止下载界面
            LoadingAnimatioGrid.IsEnabled = false;
        }

        public void LoadingUIAppear()
        {
            Storyboard story = (Storyboard)Resources["SearchingLoadingAnimation"];

            //隐藏下载loading界面
            LoadingAnimatioGrid.Visibility = Visibility.Visible;
            //禁止下载界面
            LoadingAnimatioGrid.IsEnabled = true;
            story.Begin();

        }

        private async void SeeMore()
        {
            //禁止操作搜索栏
            SearchTextBox.IsEnabled = false;
            //禁止操作开始搜索按钮
            SearchBeginButton.IsEnabled = false;
            //禁止操作更多按钮
            SeeMoreButton.IsEnabled = false;
            //隐藏错误显示栏
            MessageDisplayLabel.Visibility = Visibility.Collapsed;

            LoadingUIAppear();

            await Task.Run(() =>
            {
                string errorMessage = null;
                List<NetMusicSearch.SongInformation> informations = null;

                //开始搜索
                errorMessage = MusicSearchControl.SearchhSong(OnceGetResultSongNumber, out informations);

                //成功获取
                if (errorMessage == string.Empty)
                {
                    this.Dispatcher.Invoke(() =>
                    {
                        //隐藏错误显示栏
                        MessageDisplayLabel.Visibility = Visibility.Collapsed;
                        //允许操作搜索栏
                        SearchTextBox.IsEnabled = true;
                        //允许操作开始搜索按钮
                        SearchBeginButton.IsEnabled = true;

                        //开启查看更多gird
                        SeeMoreGrid.Visibility = Visibility.Visible;
                        if (MusicSearchControl.HadGetNumber == MusicSearchControl.SongTotalCount)
                        {
                            //禁止操作更多按钮
                            SeeMoreButton.IsEnabled = false;
                        }
                        else
                        {
                            //开启操作更多按钮
                            SeeMoreButton.IsEnabled = true;
                        }
                        //显示以获取和获取总数
                        SearchResultNumberTextBlock.Text = MusicSearchControl.HadGetNumber + "/" + MusicSearchControl.SongTotalCount;

                        //将所有获取信息添加到管理grid内
                        for (int counter = 0; counter < informations.Count; counter++)
                        {
                            MusicPlayBarGridControl.MusicContextSingle single = new MusicPlayBarGridControl.MusicContextSingle(informations[counter]);
                            //TotalContext.Add(single);
                            SearchResultSongDisplayGrid display = new SearchResultSongDisplayGrid(single/*, TotalContext*/, SingleSongDoubleClick);
                            SreachResultStackControlPanel.Children.Add(display);
                        }
                    });
                }
                else
                {
                    this.Dispatcher.Invoke(() =>
                    {
                        //允许操作搜索栏
                        SearchTextBox.IsEnabled = true;
                        //允许操作开始搜索按钮
                        SearchBeginButton.IsEnabled = true;
                        //开启信息显示label
                        MessageDisplayLabel.Visibility = Visibility.Visible;
                        //显示错误信息
                        MessageDisplayLabel.Content = errorMessage;

                        //开启查看更多gird
                        SeeMoreGrid.Visibility = Visibility.Visible;
                        if (MusicSearchControl.HadGetNumber == MusicSearchControl.SongTotalCount)
                        {
                            //禁止操作更多按钮
                            SeeMoreButton.IsEnabled = false;
                        }
                        else
                        {
                            //开启操作更多按钮
                            SeeMoreButton.IsEnabled = true;
                        }
                    });
                }

                this.Dispatcher.Invoke(() =>
                {
                    LoadingUIDisappear();
                });
            });
        }
    }
}
