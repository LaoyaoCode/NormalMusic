﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Drawing.Imaging;
using System.IO;
using Shell32;
using System.Net;
using System.Web;
using Newtonsoft.Json;
using System.Xml;
using System.Runtime.InteropServices;
using LaoyaosFile;
using Id3;
using Tags;

namespace LaoyaosMedia
{
    /// <summary>
    /// 下载控制关键实例
    /// </summary>
    public class DownLoadControlKey
    {
        private bool _IsBreakAndStop = false;

        public DownLoadControlKey()
        {
            
        }
        /// <summary>
        /// 开始停止
        /// </summary>
        public void Stop()
        {
            _IsBreakAndStop = true;
        }
        /// <summary>
        /// 是否停止并退出下载
        /// </summary>
        public bool IsBreakAndStop
        {
            get
            {
                return _IsBreakAndStop;
            }
        }
    }

    public class NetMusicDownLoad
    {
        private string SaveFilePath = string.Empty;

        public enum DownLoadCondition
        {
            /// <summary>
            /// 处理开始
            /// </summary>
            Start,
            /// <summary>
            /// 正在处理
            /// </summary>
            Disposing,
            /// <summary>
            /// 处理完成
            /// </summary>
            Finished,
            /// <summary>
            /// 处理出现了错误
            /// </summary>
            Error ,
            /// <summary>
            /// 强制退出并结束
            /// </summary>
            BreakAndStop
        }

        //缓冲区大小20KB
        private const int BuffSize = 2048 * 10;

        //最大响应时间， 5s之内没有收到回应则直接显示错误
        private const int MaxResponseTime = 5000;

        //最大响应读取时间， 3s之内没有收到回应则直接显示错误
        private const int MaxResponseReadTime = 3000;
        /// <summary>
        /// 上传或者下载过程代理
        /// </summary>
        /// <param name="percentage">下载进度百分比</param>
        /// <param name="condition">下载的状态</param>
        public delegate void DownLoadConditionInformDel(double percentage, DownLoadCondition condition);

        private event DownLoadConditionInformDel DownLoadConditionInformEvent;

        /// <summary>
        /// 下载网易云音乐
        /// <para>test success</para>
        /// <para>注：专辑图片和歌手图片将与音乐文件在同一目录</para>
        /// <para>专辑图片：savePath.album.jpg</para>
        /// <para>歌手图片：savePath.artist.jpg</para>
        /// </summary>
        /// <param name="information">要下载的网易云音乐信息</param>
        /// <param name="savePath">文件保存的地址,无需附带后缀名</param>
        /// <param name="del">事件代理，通知进程</param>
        /// <param name="key">控制关键字</param>
        public NetMusicDownLoad(NetMusicSearch.SongInformation information ,  string savePath , DownLoadConditionInformDel del , DownLoadControlKey key = null)
        {
            //保存文件名
            SaveFilePath = savePath;
            //添加代理
            DownLoadConditionInformEvent += del;

            DownLoadAsync(information , key);
        }

        private async void DownLoadAsync(NetMusicSearch.SongInformation information , DownLoadControlKey controlKey )
        {
            HttpWebRequest request =(HttpWebRequest) HttpWebRequest.Create(information.mp3Url);
            HttpWebRequest albumImageRequest = (HttpWebRequest)HttpWebRequest.Create(information.album.picUrl);
            HttpWebRequest artistImageRequest = (HttpWebRequest)HttpWebRequest.Create(information.artist.picUrl);

            HttpWebResponse response = null;
            HttpWebResponse albumImageResponse = null;
            HttpWebResponse artistImageResponse = null;
            Stream resourceStream = null;
            byte[] buff = new byte[BuffSize];
            int recieveSize = 0;
            long recieveLength = 0;
            long totalRecieveSize = 0;
            int checkNetResult = 0;

            //设置最大响应时间
            request.Timeout = MaxResponseTime;
            albumImageRequest.Timeout = MaxResponseTime;
            artistImageRequest.Timeout = MaxResponseTime;

            //检查网络连接是否正常
            if (!NetMusicWeb.InternetGetConnectedState(ref checkNetResult, 0))
            {
                //出现了错误直接返回
                DownLoadConditionInformEvent.Invoke(0.0, DownLoadCondition.Error);
                return;
            }

            //开始异步下载文件
            await Task.Run(() =>
            {
                try
                {
                    response = (HttpWebResponse)request.GetResponse();
                    albumImageResponse = (HttpWebResponse)albumImageRequest.GetResponse();
                    artistImageResponse = (HttpWebResponse)artistImageRequest.GetResponse();
                }
                catch
                {
                    //出现了错误直接返回
                    DownLoadConditionInformEvent.Invoke(0.0, DownLoadCondition.Error);
                    return;
                }

                try
                {
                    //表示为开始
                    DownLoadConditionInformEvent.Invoke(0.0, DownLoadCondition.Start);

                    //下载专辑图片
                    using (resourceStream = albumImageResponse.GetResponseStream())
                    {
                        using (FileStream file = File.Open(SaveFilePath + FileStruct.SaveAlbumImageAddString, FileMode.Create, FileAccess.ReadWrite))
                        {
                            resourceStream.CopyTo(file);
                        }
                    }

                    //下载歌手图片
                    using (resourceStream = artistImageResponse.GetResponseStream())
                    {
                        using (FileStream file = File.Open(SaveFilePath + FileStruct.SaveArtistImageAddString, FileMode.Create, FileAccess.ReadWrite))
                        {
                            resourceStream.CopyTo(file);
                        }
                    }

                    //下载音乐文件
                    using (resourceStream = response.GetResponseStream())
                    {
                        using (FileStream file = File.Open(SaveFilePath + FileStruct.SaveSongAddString, FileMode.Create, FileAccess.ReadWrite))
                        {
                            //获取文件长度
                            recieveLength = GetHttpLength(information.mp3Url);

                            if(recieveLength <= 0 )
                            {
                                recieveLength = int.MaxValue;
                            }
                            //设置反应读取最大时间
                            resourceStream.ReadTimeout = MaxResponseReadTime;

                            do
                            {
                                //如果存在关键字
                                if(controlKey != null)
                                {
                                    //并且关键字设置为停止
                                   if(controlKey.IsBreakAndStop)
                                    {
                                        //则直接退出
                                        break;
                                    }
                                }

                                //读取数据
                                recieveSize = resourceStream.Read(buff, 0, buff.Length);
                                //写入数据到本地
                                file.Write(buff, 0, recieveSize);
                                //累加数据
                                totalRecieveSize += recieveSize;
                                //提示进度
                                DownLoadConditionInformEvent(totalRecieveSize / (double)recieveLength, DownLoadCondition.Disposing);
                            } while (recieveSize != 0);
                        }
                    }

                    if(controlKey != null && controlKey.IsBreakAndStop)
                    {
                        //标识强制退出完成
                        DownLoadConditionInformEvent(0.0, DownLoadCondition.BreakAndStop);
                    }
                    //如果没有设置关键字或者没有强制停止，则为正常下载完成
                    else
                    {
                        //标识完成了下载
                        DownLoadConditionInformEvent(1.0, DownLoadCondition.Finished);
                    }
                }
                catch
                {
                    //标识错误发生
                    DownLoadConditionInformEvent(0.0, DownLoadCondition.Error);
                }
            });
        }

        private static long GetHttpLength(string url)
        {
            var length = 0L;

            try
            {
                var req = (HttpWebRequest)WebRequest.CreateDefault(new Uri(url));

                req.Method = "HEAD";
                req.Timeout = MaxResponseTime;
                using (HttpWebResponse res = (HttpWebResponse)req.GetResponse())
                {
                    if (res.StatusCode == HttpStatusCode.OK)
                    {
                        length = res.ContentLength;
                    }

                }

                return length;
            }
            catch
            {
                return 0;
            }
        }
    }

    public static class MP3Information
    {
        public struct TimeStruct
        {
            public int hour;
            public int min;
            public int second;

            public void Clear()
            {
                hour = 0;
                min = 0;
                second = 0;
            }

            public long TimeInSeconds()
            {
                return hour * 60 * 60 + min * 60 + second;
            }
        }

        //MP3信息对应ID
        private const int MP3LengthID = 27;
        private const int MP3ArtistsID = 13;
        private const int MP3AlbumID = 14;
        private const int MP3YearID = 15;
        private const int MP3TitleID = 21;

        /// <summary>
        /// 信息结构体
        /// </summary>
        public struct InformationStruct
        {
            /// <summary>
            /// 歌曲名  
            /// </summary>
            public string Title;
            /// <summary>
            /// 歌手名  
            /// </summary>
            public string Artist;
            /// <summary>
            /// 所属唱片
            /// </summary>
            public string Album;
            /// <summary>
            /// 年 
            /// </summary>      
            public string Year;
            /// <summary>
            /// 时长
            /// </summary>
            public string Length;
            /// <summary>
            /// MP3附带图片集合
            /// </summary>
            public List<BitmapImage> Images;
        }

        /// <summary>
        /// 获取信息
        /// <para>返回信息结构体</para>
        /// </summary>
        /// <param name="filePath"></param>
        /// <returns></returns>
        public static InformationStruct GetInformation(string filePath)
        {
            InformationStruct information;
            FileInfo check = new FileInfo(filePath);

            //检查文件是否存在
            if(!check.Exists)
            {
                throw new Exception("File is not exist,file name : " + filePath);
            }

            //获取mp3文字信息
            information = GetMP3StringInformation(filePath);
            //获取mp3图片信息
            information.Images = GetMP3Image(filePath);

            return information;
        }
 
        /// <summary>
        /// 获取mp3的图片
        /// <para>返回 ， bitmap集合体</para>
        /// </summary>
        /// <param name="filePath">文件路径</param>
        /// <returns></returns>
        public static List<BitmapImage> GetMP3Image(string filePath)
        {
            List<BitmapImage> list_bitmapimg = new List<BitmapImage>();
            Tags.ID3.ID3Info File = new Tags.ID3.ID3Info(filePath, true);

            // 此段代码用于将获得的System.Drawing.Image类型转化为WPF中Image控件可以接受的内容
            foreach (Tags.ID3.ID3v2Frames.BinaryFrames.AttachedPictureFrame F in File.ID3v2Info.AttachedPictureFrames)
            {
                
                BitmapImage bi = new BitmapImage();
                System.Drawing.Image imgWinForms = F.Picture;
                float scale = imgWinForms.Height / imgWinForms.Width;

                bi.BeginInit();
                MemoryStream ms = new MemoryStream();
                imgWinForms.Save(ms, ImageFormat.Bmp);
                ms.Seek(0, SeekOrigin.Begin);
                bi.StreamSource = ms;
                bi.EndInit();
                list_bitmapimg.Add(bi);
            }

            return list_bitmapimg;
        }


        /// <summary>
        /// 获取MP3的字符信息
        /// test success , 2017.01.30
        /// </summary>
        /// <param name="filePath">完全文件名路径</param>
        /// <returns>包含信息的返回值</returns>
        /*
        public static InformationStruct GetMP3StringInformation(string filePath)
        {
            InformationStruct information = new InformationStruct();

            using (Mp3File file = new Mp3File(filePath, Mp3Permissions.Read))
            {
                Id3Tag tag = file.GetTag(Id3TagFamily.Version2x);

                tag.Title.EncodingType = Id3TextEncoding.Unicode;
                tag.Album.EncodingType = Id3TextEncoding.Unicode;
                tag.Artists.EncodingType = Id3TextEncoding.Unicode;

                information.Album = tag.Album;
                information.Artist = tag.Artists;
                information.Length = tag.Length;
                information.Title = tag.Title;
                information.Year = tag.Year;
            }

            return information;
        }*/
        /// <summary>
        /// 获取MP3的字符信息
        /// test success , 2017.01.30
        /// </summary>
        /// <param name="filePath">完全文件名路径</param>
        /// <returns>包含信息的返回值</returns>

        public static InformationStruct GetMP3StringInformation(string filePath)
        {
            InformationStruct information = new InformationStruct();

            if (!filePath.Contains(":\\"))
            {
                filePath = AppDomain.CurrentDomain.BaseDirectory + filePath;
            }

            ShellClass sh = new ShellClass();

            string test = System.IO.Path.GetDirectoryName(filePath);

            Folder dir = sh.NameSpace(System.IO.Path.GetDirectoryName(filePath));
            FolderItem item = dir.ParseName(System.IO.Path.GetFileName(filePath));

            information.Title = dir.GetDetailsOf(item, MP3TitleID); // 获取歌曲名字
            information.Album = dir.GetDetailsOf(item, MP3AlbumID);//获取歌曲专辑
            information.Artist = dir.GetDetailsOf(item, MP3ArtistsID);//获取作者名字
            information.Year = dir.GetDetailsOf(item, MP3YearID);//获取歌曲年份
            information.Length = dir.GetDetailsOf(item, MP3LengthID);//获取歌曲年份

            return information;
        }

        /// <summary>
        /// 修改MP3 TAG信息
        /// <para>成功 返回 true , 失败 返回 false</para>
        /// </summary>
        /// <param name="path">音乐文件地址</param>
        /// <param name="title">音乐名</param>
        /// <param name="album">音乐专辑</param>
        /// <param name="artist">歌手</param>
        /// <returns></returns>
        public static bool ModifyMP3Tag(string path, string title, string album, string artist)
        {
            bool result = false;

            using (Mp3File file = new Mp3File(path, Mp3Permissions.ReadWrite))
            {
                Id3Tag tag = file.GetTag(Id3TagFamily.Version2x);

                tag.Title.EncodingType = Id3TextEncoding.Unicode;
                tag.Album.EncodingType = Id3TextEncoding.Unicode;
                tag.Artists.EncodingType = Id3TextEncoding.Unicode;

                if(title != string.Empty && title != null)
                {
                    tag.Title.Value = title;
                }
                
                if(artist != string.Empty && artist != null)
                {
                    tag.Artists.Value.Clear();
                    tag.Artists.Value.Add(artist);
                }

                if (album != string.Empty && album != null)
                {
                    tag.Album.Value = album;
                }
                    
                result = file.WriteTag(tag, WriteConflictAction.Replace);
            }

            return result;
        }

        public static TimeStruct GetMP3Time(string filePath)
        {
            TimeStruct time;
            string[] timeStrings = null;

            if (!filePath.Contains(":\\"))
            {
                filePath = AppDomain.CurrentDomain.BaseDirectory + filePath;
            }

            ShellClass sh = new ShellClass();

            string test = System.IO.Path.GetDirectoryName(filePath);

            Folder dir = sh.NameSpace(System.IO.Path.GetDirectoryName(filePath));
            FolderItem item = dir.ParseName(System.IO.Path.GetFileName(filePath));

            timeStrings = dir.GetDetailsOf(item, MP3LengthID).Split(new char[] { ':' });//获取歌曲年份

            time.hour = int.Parse(timeStrings[0]);
            time.min = int.Parse(timeStrings[1]);
            time.second = int.Parse(timeStrings[2]);

            return time;
        }
    }

    public static class NetMusicWeb
    {
        [DllImport("winInet.dll ")]
        public static extern bool InternetGetConnectedState(
             ref int dwFlag,
             int dwReserved
         );
    }

    public class NetMusicSearch
    {
        private const string XMLRootNodeName = "root";
        private const string SearchSongXMLResultNodeName = "result";
        private const string SearchSongXMLCodeNodeName = "code";
        private const string SearchSongXMLSongCountNodeName = "songCount";
        private const string SearchSongXMLSongNodeName = "songs";
        private const string SearchSongXMLArtistNodeName = "artists";
        private const string SearchSongXMLAlbumNodeName = "album";
        private const string SearchSongXMLNameNodeName = "name";
        private const string SearchSongXMLIDNodeName = "id";
        private const string SearchSongXMLMP3UrlNodeName = "mp3Url";
        private const string SearchSongXMLPicUrlNodeName = "picUrl";
        private const string SearchSongXMLSizeNodeName = "size";

        //最大响应时间， 5s之内没有收到回应则直接显示错误
        private const int MaxResponseTime = 5000;

        /// <summary>
        /// 歌曲信息结构体
        /// </summary>
        public struct SongInformation
        {
            /// <summary>
            /// 歌曲名字
            /// </summary>
            public string name;

            /// <summary>
            /// 歌曲ID
            /// </summary>
            public string id;

            /// <summary>
            /// 歌手信息
            /// </summary>
            public Artist artist;

            /// <summary>
            /// 专辑信息
            /// </summary>
            public Album album;

            /// <summary>
            /// 对应歌曲mp3 url地址
            /// </summary>
            public string mp3Url;

            public override string ToString()
            {
                string result = string.Empty;

                result += "Song Name : " + name + "\n";
                result += "Artist Name : " + artist.name + "\n";
                result += "Album Name : " + album.name + "\n";

                return result;
            }
        }

        /// <summary>
        /// 歌手信息
        /// </summary>
        public struct Artist
        {
            /// <summary>
            /// 歌手名字
            /// </summary>
            public string name;

            /// <summary>
            /// 歌手ID
            /// </summary>
            public string id;

            /// <summary>
            /// 歌手图片Url地址
            /// </summary>
            public string picUrl;
        }

        /// <summary>
        /// 专辑信息
        /// </summary>
        public struct Album
        {
            /// <summary>
            /// 专辑名字
            /// </summary>
            public string name;

            /// <summary>
            /// 专辑ID
            /// </summary>
            public string id;

            /// <summary>
            /// 专辑歌曲数目
            /// </summary>
            public string size;

            /// <summary>
            /// 专辑图片Url地址
            /// </summary>
            public string picUrl;

            /// <summary>
            /// 专辑作者信息
            /// </summary>
            public Artist artist;
        }

        private const string SreachUri = "http://music.163.com/api/search/pc";
        //关键字
        private string KeyWords = string.Empty;
        //偏移量
        private int Offset = 0;
        //获取信息总数
        private int _SongTotalCount = 0;

        /// <summary>
        /// 已经获取的歌曲数目
        /// </summary>
        public int HadGetNumber
        {
            get
            {
                return Offset;
            }
        }
        /// <summary>
        /// 查询信息条数总数
        /// </summary>
        public int SongTotalCount
        {
            get
            {
                return _SongTotalCount;
            }
        }

        public NetMusicSearch(string keyWords)
        {
            KeyWords = keyWords;
        }

        /// <summary>
        /// 根据关键字搜索歌曲信息
        /// <para>返回 string.Empty 表明无错误发生 ， 否则返回错误信息</para>
        /// <para>test success , 2017.4.24</para>
        /// </summary>
        /// <param name="messageMaxNumber">这次要获取的最大信息数目</param>
        /// <param name="songCollections">信息集合的引用</param>
        /// <returns></returns>
        public string SearchhSong(int messageMaxNumber , out List<SongInformation> songCollections)
        {
            
            //GB2312中文编码
            Encoding myEncoding = Encoding.GetEncoding("gb2312");
            //参数字符串
            string para = string.Empty;
            //post 数据
            byte[] message = null;
            //XML 格式数据
            XmlDocument xmlDoc = null;
            //歌曲集合
            songCollections = null;
            //返回的信息
            string result = string.Empty;
            //http请求
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(SreachUri);
            //最大响应时间
            request.Timeout = MaxResponseTime;
            //检查网络是否正常连接
            int checkNetResult = 0 ;

            //检查网络连接是否正常
            if (!NetMusicWeb.InternetGetConnectedState(ref checkNetResult, 0))
            {
                //如果无网络连接,则返回错误
                return "No network connection ";
            }

            //设定参数
            //讲中文编码转化为ASCII编码
            para += "s=" + HttpUtility.UrlEncode(KeyWords, myEncoding) + "&";
            para += "offset=" + Offset.ToString() + "&";
            para += "limit=" + messageMaxNumber.ToString() + "&";
            //默认搜索歌曲
            para += "type=1";

            //转化为ASCII编码
            message = Encoding.ASCII.GetBytes(para);

            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded;charset=gb2312";
            request.ContentLength = message.Length;

            try
            {
                //写入请求流
                using (Stream reqStream = request.GetRequestStream())
                {
                    reqStream.Write(message, 0, message.Length);
                }

                //获得应答
                using (WebResponse response = request.GetResponse())
                {
                    using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                    {
                        string jsonString = reader.ReadToEnd();

                        //获取json格式字符串，并且处理得到能够转化为xml格式的数据
                        jsonString = @"{
                              ""?xml"": {
                                ""@version"": ""1.0"",
                                ""@standalone"": ""yes""
                              }," + "\"" + XMLRootNodeName + "\"" + ":"
                                   + jsonString + "}";

                        //转化为xml格式
                        xmlDoc = (XmlDocument)JsonConvert.DeserializeXmlNode(jsonString);
                        //获取集合以及结果字符串
                        result = DisposeSreachSongXMLData(xmlDoc, out songCollections);
                    }
                }
            }
            catch(Exception e)
            {
                result = e.Message;
            }

            //返回信息
            return result;
        }
        
        /// <summary>
        /// 处理歌曲搜索XML数据
        /// <para>返回 string.Empty 表明无错误发生 ， 否则返回错误信息</para>
        /// </summary>
        /// <param name="xmlDoc">xml 数据</param>
        /// <param name="informations">存储信息的对象引用</param>
        /// <returns></returns>
        private string DisposeSreachSongXMLData(XmlDocument xmlDoc , out List<SongInformation> informations)
        {
            informations = new List<SongInformation>();
            //获取根节点
            XmlNode rootNode = xmlDoc.SelectSingleNode(XMLRootNodeName);
            //获取代码节点名
            XmlNode codeNode = rootNode.SelectSingleNode(SearchSongXMLCodeNodeName);
            //结果节点
            XmlNode resultNode = null;
            //result 所有的子节点
            XmlNodeList resultChildNodes = null;

            //如果不是正确代码的话，直接返回错误信息
            if(codeNode.InnerText != "200")
            {
                return "Can not get the song message";
            }

            try
            {
                //获取结果节点
                resultNode = rootNode.SelectSingleNode(SearchSongXMLResultNodeName);
                //获取所有的子节点
                resultChildNodes = resultNode.ChildNodes;

                foreach (XmlNode resultChildNode in resultChildNodes)
                {
                    //循环到count 节点
                    if (resultChildNode.Name == SearchSongXMLSongCountNodeName)
                    {
                        //获取信息总数，每次更新
                        _SongTotalCount = int.Parse(resultChildNode.InnerText);
                    }
                    //循环到歌曲节点
                    else if (resultChildNode.Name == SearchSongXMLSongNodeName)
                    {
                        //信息结构体
                        SongInformation information = new SongInformation();

                        foreach (XmlNode songChildNode in resultChildNode.ChildNodes)
                        {
                            //寻找到了歌曲名
                            if (songChildNode.Name == SearchSongXMLNameNodeName)
                            {
                                information.name = songChildNode.InnerText;
                            }
                            //寻找到了歌曲id
                            else if (songChildNode.Name == SearchSongXMLIDNodeName)
                            {
                                information.id = songChildNode.InnerText;
                            }
                            //寻找到了歌手信息节点
                            else if (songChildNode.Name == SearchSongXMLArtistNodeName)
                            {
                                foreach (XmlNode artistNode in songChildNode.ChildNodes)
                                {
                                    //寻找到了歌手名
                                    if (artistNode.Name == SearchSongXMLNameNodeName)
                                    {
                                        information.artist.name = artistNode.InnerText;
                                    }
                                    //寻找到了歌手id
                                    else if (artistNode.Name == SearchSongXMLIDNodeName)
                                    {
                                        information.artist.id = artistNode.InnerText;
                                    }
                                    //寻找到了歌手图片url
                                    else if (artistNode.Name == SearchSongXMLPicUrlNodeName)
                                    {
                                        information.artist.picUrl = artistNode.InnerText;
                                    }
                                }
                            }
                            //寻找到了专辑信息
                            else if (songChildNode.Name == SearchSongXMLAlbumNodeName)
                            {
                                foreach (XmlNode albumNode in songChildNode.ChildNodes)
                                {
                                    //寻找到了专辑名字
                                    if (albumNode.Name == SearchSongXMLNameNodeName)
                                    {
                                        information.album.name = albumNode.InnerText;
                                    }
                                    //寻找到了专辑ID信息
                                    else if (albumNode.Name == SearchSongXMLIDNodeName)
                                    {
                                        information.album.id = albumNode.InnerText;
                                    }
                                    //寻找到了专辑歌曲大小节点信息
                                    else if (albumNode.Name == SearchSongXMLSizeNodeName)
                                    {
                                        information.album.size = albumNode.InnerText;
                                    }
                                    //寻找到了专辑图片url地址
                                    else if (albumNode.Name == SearchSongXMLPicUrlNodeName)
                                    {
                                        information.album.picUrl = albumNode.InnerText;
                                    }
                                    //寻找到了专辑歌手节点信息
                                    else if (albumNode.Name == SearchSongXMLArtistNodeName)
                                    {
                                        foreach (XmlNode artistNode in albumNode.ChildNodes)
                                        {
                                            //寻找到了专辑歌手名
                                            if (artistNode.Name == SearchSongXMLNameNodeName)
                                            {
                                                information.album.artist.name = artistNode.InnerText;
                                            }
                                            //寻找到了专辑歌手id
                                            else if (artistNode.Name == SearchSongXMLIDNodeName)
                                            {
                                                information.album.artist.id = artistNode.InnerText;
                                            }
                                            //寻找到了专辑歌手图片url
                                            else if (artistNode.Name == SearchSongXMLPicUrlNodeName)
                                            {
                                                information.album.artist.picUrl = artistNode.InnerText;
                                            }
                                        }
                                    }

                                }
                            }
                            else if (songChildNode.Name == SearchSongXMLMP3UrlNodeName)
                            {
                                information.mp3Url = songChildNode.InnerText;
                            }
                        }

                        //歌曲信息偏置自加
                        Offset++;
                        //添加到集合内
                        informations.Add(information);
                    }
                }

                return string.Empty;
            }
            catch(Exception e)
            {
                return e.Message;
            }
        }
    }
}
