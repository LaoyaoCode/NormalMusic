﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LaoyaosMedia;
using LaoyaosFile;
using System.Threading;
using System.Windows.Media.Animation;
using LaoyaosProgramMessage;
using NormalMusicPlayer.Sql;
using NormalFTP;


namespace NormalMusicPlayer
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        //gc  , 每 5MIN GC一次
        private System.Windows.Threading.DispatcherTimer GCTimer = null;
        //被选择的工具按钮
        private ToolButton ChooseToolButton = null;

        //引用于自身
        private static MainWindow _MySelf = null;

        /// <summary>
        /// 网络秘密信息控制体
        /// </summary>
        public static ProgramNetSecretControl ProgramNetSecret = null;

        /// <summary>
        /// sql数据库控制体
        /// </summary>
        public static NormalMusicSqlControl NormalMusicSql = null;

        /// <summary>
        /// ftp 服务器控制类
        /// </summary>
        public static NormalFTPControl NormalFTP = null;

        /// <summary>
        /// 主窗口自身
        /// </summary>
        public static MainWindow MySelf
        {
            get
            {
                return _MySelf;
            }
        }


        public MainWindow()
        {
            InitializeComponent();
        }

        private void NormalWindow_Loaded(object sender, RoutedEventArgs e)
        {
            int checkNet = 0;

            //初始化程序文件结构
            FileStruct.Init();
            //初始化网络秘密控制
            ProgramNetSecret = new ProgramNetSecretControl(HideSurpriseTBlock.Text);
            //初始化sql控制实例
            NormalMusicSql = new NormalMusicSqlControl(ProgramNetSecret.MySqlSeverIp, ProgramNetSecret.MySqlUserName, ProgramNetSecret.MySqlPasswords);
            //初始化ftp控制实例
            NormalFTP = new NormalFTPControl(ProgramNetSecret.FTPSeverIp, ProgramNetSecret.FTPUserName, ProgramNetSecret.FTPPasswords);

            DownLoad.Visibility = Visibility.Collapsed;
            SearchMusic.Visibility = Visibility.Collapsed;
            MusicBooks.Visibility = Visibility.Collapsed;
            UserPanel.Visibility = Visibility.Collapsed;
            CloudPanel.Visibility = Visibility.Collapsed;

            //对自己赋值，应为每一个程序只有一个唯一的main windows
            _MySelf = this;
            //工具按钮初始化
            MusicBooksPanelButton.InitToolButton(ToolsButtonClick, ToolButton.ToolButtonTypeEnum.MusicBooksPanelButton);
            NetSearchPanelButton.InitToolButton(ToolsButtonClick, ToolButton.ToolButtonTypeEnum.NetSearchPanelMusicButton);
            PeoplesMusicPanelButton.InitToolButton(ToolsButtonClick, ToolButton.ToolButtonTypeEnum.PeoplesMusicPanelButton);
            DownLoadMusicPanelButton.InitToolButton(ToolsButtonClick, ToolButton.ToolButtonTypeEnum.DownLoadPanelButton);
            UserPanelButton.InitToolButton(ToolsButtonClick, ToolButton.ToolButtonTypeEnum.UserPanelButton);

            MusicBooksPanelButton.ButtonIcon_Click(null , null);

            //检查网络连接是否正常 , 如果正常则开始连接数据库
            if (NetMusicWeb.InternetGetConnectedState(ref checkNet, 0))
            {
                NormalMusicSql.ConnectToMySqlAsync((condition , message) =>
                {
                    this.Dispatcher.Invoke(() =>
                    {
                        switch (condition)
                        {
                            case NormalMusicSqlControl.ConnectingStateEnum.Success:
                                DisplayMessage("成功连接到数据库 : Normal");
                                break;
                            case NormalMusicSqlControl.ConnectingStateEnum.Failed:
                                DisplayMessage("连接数据库 : Normal 失败");
                                break;
                        }
                    });
                });
            }

            //周期为5MIN , 强制 GC
            GCTimer = new System.Windows.Threading.DispatcherTimer();
            GCTimer.Interval = TimeSpan.FromMinutes(5);
            GCTimer.Tick += GCTimer_Tick;
            GCTimer.IsEnabled = true;
            GCTimer.Start();

        }

        private void GCTimer_Tick(object sender, EventArgs e)
        {
            GC.Collect();
            GC.WaitForPendingFinalizers();
            GC.Collect();
        }

        private void DargWindowMove(object sender, MouseButtonEventArgs e)
        {
            //move the windows
            this.DragMove();
        }

        private void CloseWindowButton_Click(object sender, RoutedEventArgs e)
        {
            ExitEvent();
            //关闭应用程序
            //Environment.Exit(0);
            Application.Current.Shutdown();
        }

        private void MinWindowButton_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }
        //--------------------------------------工具栏按钮操作----------------------------------------------------
        //工具栏按钮被点击
        private void ToolsButtonClick(ToolButton.ToolButtonTypeEnum type)
        {
            //取消之前被选择按钮的视觉
            //根据按钮类型执行事件并且更新被选择按钮引用
            switch (type)
            {
                case ToolButton.ToolButtonTypeEnum.MusicBooksPanelButton:
                    //防止重复点击
                    if(ChooseToolButton != MusicBooksPanelButton)
                    {
                        MusicBooksPanelButton_Click();
                        if(ChooseToolButton != null)
                        {
                            ChooseToolButton.VisiualRectDisappear();
                        }
                    }
                    ChooseToolButton = MusicBooksPanelButton;
                    break;
                case ToolButton.ToolButtonTypeEnum.NetSearchPanelMusicButton:
                    if(ChooseToolButton != NetSearchPanelButton)
                    {
                        NetSearchPanelButton_Click();
                        if (ChooseToolButton != null)
                        {
                            ChooseToolButton.VisiualRectDisappear();
                        }
                    }
                    ChooseToolButton = NetSearchPanelButton;
                    break;
                case ToolButton.ToolButtonTypeEnum.PeoplesMusicPanelButton:
                    if(ChooseToolButton != PeoplesMusicPanelButton)
                    {
                        PeoplesMusicPanelButton_Click();
                        if (ChooseToolButton != null)
                        {
                            ChooseToolButton.VisiualRectDisappear();
                        }
                    }              
                    ChooseToolButton = PeoplesMusicPanelButton;
                    break;
                case ToolButton.ToolButtonTypeEnum.DownLoadPanelButton:
                    if(ChooseToolButton != DownLoadMusicPanelButton)
                    {
                        DownLoadMusicPanelButton_Click();
                        if (ChooseToolButton != null)
                        {
                            ChooseToolButton.VisiualRectDisappear();
                        }
                    }
                    ChooseToolButton = DownLoadMusicPanelButton;
                    break;
                case ToolButton.ToolButtonTypeEnum.UserPanelButton:
                    if(ChooseToolButton != UserPanelButton)
                    {
                        UserPanelButton_Click();
                        if (ChooseToolButton != null)
                        {
                            ChooseToolButton.VisiualRectDisappear();
                        }
                    }
                    ChooseToolButton = UserPanelButton;
                    break;
            }
        }

        private void MusicBooksPanelButton_Click()
        {
            DownLoad.Visibility = Visibility.Collapsed;
            SearchMusic.Visibility = Visibility.Collapsed;
            MusicBooks.Visibility = Visibility.Visible;
            UserPanel.Visibility = Visibility.Collapsed;
            CloudPanel.Visibility = Visibility.Collapsed;
        }

        private void NetSearchPanelButton_Click()
        {
            DownLoad.Visibility = Visibility.Collapsed;
            SearchMusic.Visibility = Visibility.Visible;
            MusicBooks.Visibility = Visibility.Collapsed;
            UserPanel.Visibility = Visibility.Collapsed;
            CloudPanel.Visibility = Visibility.Collapsed;
        }

        private void PeoplesMusicPanelButton_Click()
        {
            DownLoad.Visibility = Visibility.Collapsed;
            SearchMusic.Visibility = Visibility.Collapsed;
            MusicBooks.Visibility = Visibility.Collapsed;
            UserPanel.Visibility = Visibility.Collapsed;
            CloudPanel.Visibility = Visibility.Visible;
        }

        private void DownLoadMusicPanelButton_Click()
        {
            DownLoad.Visibility = Visibility.Visible;
            SearchMusic.Visibility = Visibility.Collapsed;
            MusicBooks.Visibility = Visibility.Collapsed;
            UserPanel.Visibility = Visibility.Collapsed;
            CloudPanel.Visibility = Visibility.Collapsed;
        }

        private void UserPanelButton_Click()
        {
            DownLoad.Visibility = Visibility.Collapsed;
            SearchMusic.Visibility = Visibility.Collapsed;
            MusicBooks.Visibility = Visibility.Collapsed;
            UserPanel.Visibility = Visibility.Visible;
            CloudPanel.Visibility = Visibility.Collapsed;
        }

        /// <summary>
        /// 在主窗口显示信息
        /// </summary>
        /// <param name="message">信息字符串</param>
        public void DisplayMessage(string message)
        {
            Storyboard story = (Storyboard)Resources["MessageBoxDisplay"];
            MessageTextBox.Text = message;

            story.Begin();
        }

        /// <summary>
        /// 非UI线程在主窗口显示信息
        /// </summary>
        /// <param name="message">信息字符串</param>
        public void DisplayMessageNoUIThread(string message)
        {
            this.Dispatcher.Invoke(() =>
            {
                Storyboard story = (Storyboard)Resources["MessageBoxDisplay"];
                MessageTextBox.Text = message;

                story.Begin();
            });   
        }

        //程序关闭时调用
        public void ExitEvent()
        {
            MusicPlayBarGrid.SaveDataToLocal();
            MusicBooks.SaveToLocal();
            DownLoad.SaveToLocal();
            UserPanel.SaveToLocal();
            //关闭数据库连接
            NormalMusicSql.CloseConnection();
        }

        /*
        //每次加载完成之后检测向前向后按钮是否可用
        private void PageFrame_LoadCompleted(object sender, NavigationEventArgs e)
        {
            if(PageFrame.CanGoBack)
            {
                LastPageButton.IsEnabled = true;
            }
            else
            {
                LastPageButton.IsEnabled = false;
            }

            if(PageFrame.CanGoForward)
            {
                NextPageButton.IsEnabled = true;
            }
            else
            {
                NextPageButton.IsEnabled = false;
            }
        }

        private void LastPageButton_Click(object sender, RoutedEventArgs e)
        {
            if (PageFrame.CanGoBack)
            {
                PageFrame.GoBack();
            }
        }

        private void NextPageButton_Click(object sender, RoutedEventArgs e)
        {
            if(PageFrame.CanGoForward)
            {
                PageFrame.GoForward();
            }
        }*/
        //--------------------------------------------------工具栏按钮操作--------------------------------------------------------
    }
}
