﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;

namespace NormalFTP
{
    public class NormalFTPControl
    {
        /// <summary>
        /// FTP 处理时的状态枚举
        /// </summary>
        public enum FTPDisposeStateEnum
        {
            /// <summary>
            /// FTP开始处理
            /// </summary>
            Start ,
            /// <summary>
            /// FTP正在处理
            /// </summary>
            Disposing,
            /// <summary>
            /// FTP处理完成
            /// </summary>
            Finished,
            /// <summary>
            /// FTP处理出现了错误
            /// </summary>
            Error
        }

        /// <summary>
        /// FTP处理时的委托代理函数 ， 用于通知过程信息
        /// </summary>
        /// <param name="state">FTP状态</param>
        /// <param name="percentage">下载或者上传的百分比</param>
        /// <param name="message">要通知的信息</param>
        public delegate void FTPDisposeDel(FTPDisposeStateEnum state, double percentage ,  string message);

        //文件流缓冲区大小20KB
        private const int StreamBuffSize = 2048 * 10;
        //最大响应时间为5S
        private const int MaxResponseTime = 5000;
        //连接所需要的信息
        private string FTPIpAddress = string.Empty;
        private string FTPUserName = string.Empty;
        private string FTPPasswords = string.Empty;

        /// <summary>
        /// normal aliyun 服务器端的 ftp 协议
        /// </summary>
        /// <param name="ip">ftp ip地址</param>
        /// <param name="userName">用户名</param>
        /// <param name="passWords">密码</param>
        public NormalFTPControl(string ip , string userName , string passWords)
        {
            FTPIpAddress = ip;
            FTPUserName = userName;
            FTPPasswords = passWords;
        }

        /// <summary>
        /// 上传一个文件到FTP服务器上，如果保存的名字在服务器上出现了重复，之前的数据将会被删除
        /// <para>此为同步方式</para>
        /// <para>test success</para>
        /// </summary>
        /// <param name="filePath">上传的文件本地地址</param>
        /// <param name="saveFileName">上传到服务器的地址</param>
        /// <param name="disposeDel">处理状态委托函数</param>
        public void UploadFile(string filePath, string saveFileName , FTPDisposeDel disposeDel = null)
        {
            //上传文件流
            FileStream uploadFile = null;
            //FTP请求
            FtpWebRequest ftpRequest = null;
            //文件流缓冲数据
            byte[] streamBuff = new byte[StreamBuffSize];
            //一次发送的数据长度
            int sendSize = 0;
            //已发送的所有数据长度 ， 要发送的整个数据长度
            long totalSendedSize = 0, totalSendSize = 0;

            //文件打开是否成功
            try
            {
                uploadFile = File.Open(filePath, FileMode.Open);
            }
            //文件打开失败
            catch
            {
                //处理进度代理回调
                if (disposeDel != null)
                {
                    //发送进度 , 状态，错误
                    disposeDel.Invoke(FTPDisposeStateEnum.Error,0.0 , "Local File : " + filePath + " open error!");
                }

                return;
            }

            //设置IP和文件位置
            ftpRequest = (FtpWebRequest)FtpWebRequest.Create(new Uri("ftp://" + FTPIpAddress + "/" + saveFileName));
            //用户名和密码
            ftpRequest.Credentials = new NetworkCredential(FTPUserName, FTPPasswords);
            //执行完请求后连接关闭
            ftpRequest.KeepAlive = false;
            //上传文件
            ftpRequest.Method = WebRequestMethods.Ftp.UploadFile;
            // 指定数据传输类型,binary   
            ftpRequest.UseBinary = true;
            //设置上传文件长度
            ftpRequest.ContentLength = uploadFile.Length;
            //不要求身份验证
            ftpRequest.AuthenticationLevel = System.Net.Security.AuthenticationLevel.None;
            //不使用ssl安全验证
            ftpRequest.EnableSsl = false;
            ftpRequest.UsePassive = true;
            //设置最大响应时间
            ftpRequest.Timeout = MaxResponseTime;

            try
            {
                //处理进度代理回调
                if (disposeDel != null)
                {
                    //状态为开始
                    disposeDel.Invoke(FTPDisposeStateEnum.Start , 0.0 , string.Empty);
                }

                //获得总共需要发送的长度
                totalSendSize = uploadFile.Length;

                // 获得上传流
                using (Stream ftpSender = ftpRequest.GetRequestStream())
                {
                    //设置最大响应时间
                    ftpSender.WriteTimeout = MaxResponseTime;
                    //每次读文件流的2kb    
                    sendSize = uploadFile.Read(streamBuff, 0, StreamBuffSize);

                    //文件内容没有结束
                    while (sendSize != 0)
                    {
                        //将读取的文件数据发送到FTP服务器
                        ftpSender.Write(streamBuff, 0, sendSize);
                        //记录已经发送的数据长度
                        totalSendedSize += sendSize;

                        //处理进度代理回调
                        if (disposeDel != null)
                        {
                            //发送进度
                            disposeDel.Invoke(FTPDisposeStateEnum.Disposing , (double)totalSendedSize / totalSendSize,string.Empty );
                        }
                        //读取本地数据
                        sendSize = uploadFile.Read(streamBuff, 0, StreamBuffSize);
                    }

                    //处理进度代理回调
                    if (disposeDel != null)
                    {
                        //发送进度 , 状态，完成
                        disposeDel.Invoke(FTPDisposeStateEnum.Finished , 1.0 , string.Empty);
                    }
                }
            }
            //发送失误，捕捉信息返回
            catch(Exception e)
            {
                //处理进度代理回调
                if (disposeDel != null)
                {
                    //发送进度 , 状态，错误
                    disposeDel.Invoke(FTPDisposeStateEnum.Error , 0.0 , e.Message);
                }
            }
            finally
            {
                //关闭文件流
                uploadFile.Close();
            }
        }

        /// <summary>
        /// 上传一个文件到FTP服务器上，如果保存的名字在服务器上出现了重复，之前的数据将会被删除
        /// <para>此为异步方式</para>
        /// <para>test success</para>
        /// </summary>
        /// <param name="filePath">上传的文件本地地址</param>
        /// <param name="saveFileName">上传到服务器的地址</param>
        /// <param name="disposeDel">处理状态委托函数</param>
        public async void UploadFileAsync(string filePath, string saveFileName, FTPDisposeDel disposeDel = null)
        {
            await Task.Run(() =>
            {
                UploadFile(filePath, saveFileName, disposeDel);
            });
        }

        /// <summary>
        /// 在FTP服务器上删除一个文件
        /// <para>此为同步方式</para>
        /// <para>test success , 2017.5.9</para>
        /// </summary>
        /// <param name="ftpFilePath">ftp文件路径</param>
        /// <param name="disposeDel">处理事件代理</param>
        public void DeleteFile(string ftpFilePath, FTPDisposeDel disposeDel = null)
        {
            //FTP请求
            FtpWebRequest ftpRequest = null;
            //FTP回应
            FtpWebResponse response = null;

            //设置IP和文件位置
            ftpRequest = (FtpWebRequest)FtpWebRequest.Create(new Uri("ftp://" + FTPIpAddress + "/" + ftpFilePath));
            //用户名和密码
            ftpRequest.Credentials = new NetworkCredential(FTPUserName, FTPPasswords);
            //执行完请求后连接关闭
            ftpRequest.KeepAlive = false;
            //删除文件
            ftpRequest.Method = WebRequestMethods.Ftp.DeleteFile;
            //不要求身份验证
            ftpRequest.AuthenticationLevel = System.Net.Security.AuthenticationLevel.None;
            //不使用ssl安全验证
            ftpRequest.EnableSsl = false;
            ftpRequest.UsePassive = true;
            //设置最大响应时间
            ftpRequest.Timeout = MaxResponseTime;

            try
            {
                //处理进度代理回调
                if (disposeDel != null)
                {
                    //状态为开始
                    disposeDel.Invoke(FTPDisposeStateEnum.Start, 0.0, string.Empty);
                }

                //获取应答
                using (response = (FtpWebResponse)ftpRequest.GetResponse())
                {
                    if(response.StatusCode == FtpStatusCode.FileActionOK)
                    {
                        if(disposeDel != null)
                        {
                            //状态为完成
                            disposeDel.Invoke(FTPDisposeStateEnum.Finished, 0.0, string.Empty);
                        }
                    }
                    else
                    {
                        if(disposeDel != null)
                        {
                            //状态为错误，返回状态描述
                            disposeDel.Invoke(FTPDisposeStateEnum.Error, 0.0, response.StatusDescription);
                        }
                    }
                }      
            }
            catch(Exception e)
            {
                if (disposeDel != null)
                {
                    //状态为错误，返回状态描述
                    disposeDel.Invoke(FTPDisposeStateEnum.Error, 0.0, e.Message);
                }
            }
        }

        /// <summary>
        /// 在FTP服务器上删除一个文件
        /// <para>此为异步方式</para>
        /// <para>test success , 2017.5.9</para>
        /// </summary>
        /// <param name="ftpFilePath">ftp文件路径</param>
        /// <param name="disposeDel">处理事件代理</param>
        public async void DeleteFileAsync(string ftpFilePath, FTPDisposeDel disposeDel = null)
        {
            await Task.Run(() =>
            {
                DeleteFile(ftpFilePath, disposeDel);
            });
        }

        /// <summary>
        /// 在FTP服务器上创建一个文件夹
        /// <para>如果文件夹已经存在， 则会返回找不到文件的 code 550 错误</para>
        /// <para>此为同步方式</para>
        /// <para>test success , 2017.5.9</para>
        /// </summary>
        /// <param name="ftpFilePath">ftp文件夹路径</param>
        /// <param name="disposeDel">处理事件代理</param>
        public void CreateBook(string ftpBookPath, FTPDisposeDel disposeDel = null)
        {
            //FTP请求
            FtpWebRequest ftpRequest = null;
            //FTP回应
            FtpWebResponse response = null;

            //设置IP和文件位置
            ftpRequest = (FtpWebRequest)FtpWebRequest.Create(new Uri("ftp://" + FTPIpAddress + "/" + ftpBookPath));
            //用户名和密码
            ftpRequest.Credentials = new NetworkCredential(FTPUserName, FTPPasswords);
            //执行完请求后连接关闭
            ftpRequest.KeepAlive = false;
            //创造文件夹
            ftpRequest.Method = WebRequestMethods.Ftp.MakeDirectory;
            //不要求身份验证
            ftpRequest.AuthenticationLevel = System.Net.Security.AuthenticationLevel.None;
            //不使用ssl安全验证
            ftpRequest.EnableSsl = false;
            ftpRequest.UsePassive = true;
            //设置最大响应时间
            ftpRequest.Timeout = MaxResponseTime;

            try
            {
                //处理进度代理回调
                if (disposeDel != null)
                {
                    //状态为开始
                    disposeDel.Invoke(FTPDisposeStateEnum.Start, 0.0, string.Empty);
                }

                //获取应答
                using (response = (FtpWebResponse)ftpRequest.GetResponse())
                {
                    if (response.StatusCode == FtpStatusCode.PathnameCreated)
                    {
                        if (disposeDel != null)
                        {
                            //状态为完成
                            disposeDel.Invoke(FTPDisposeStateEnum.Finished, 0.0, string.Empty);
                        }
                    }
                    else
                    {
                        if (disposeDel != null)
                        {
                            //状态为错误，返回状态描述
                            disposeDel.Invoke(FTPDisposeStateEnum.Error, 0.0, response.StatusDescription);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                if (disposeDel != null)
                {
                    //状态为错误，返回状态描述
                    disposeDel.Invoke(FTPDisposeStateEnum.Error, 0.0, e.Message);
                }
            }
        }

        /// <summary>
        /// 在FTP服务器上创建一个文件夹
        /// <para>如果文件夹已经存在， 则会返回找不到文件的 code 550 错误</para>
        /// <para>此为异步方式</para>
        /// <para>test success , 2017.5.9</para>
        /// </summary>
        /// <param name="ftpFilePath">ftp文件夹路径</param>
        /// <param name="disposeDel">处理事件代理</param>
        public async void CreateBookAsync(string ftpBookPath, FTPDisposeDel disposeDel = null)
        {
            await Task.Run(() =>
            {
                CreateBook(ftpBookPath, disposeDel);
            });
        }

        /// <summary>
        /// 下载文件到本地 ， 如果本地文件名字重复了的话，原始文件将会被删除
        /// <para>此为同步方式</para>
        /// <para>test success 2017.5.9</para>
        /// </summary>
        /// <param name="saveInPCFilePath">保存到本地的文件路径</param>
        /// <param name="downloadFTPFileName">要下载的FTP文件路径</param>
        /// <param name="disposeDel">处理委托代理</param>
        public void DownLoadFile(string saveInPCFilePath, string downloadFTPFileName, FTPDisposeDel disposeDel = null)
        {
            FileStream downloadFile = null;
            FtpWebRequest ftpRequest = null;
            FtpWebResponse ftpReponse = null;
            //文件流缓冲buff
            byte[] streamBuff = new byte[StreamBuffSize];
            //一次收到的字节数
            int recieveSize = 0;
            //已经收到的字节数 ， 总共要收到的字节数
            long totalRecieveSize = 0, totalRecievedSize = 0;

            //本地文件创建是否成功
            try
            {
                downloadFile = File.Open(saveInPCFilePath, FileMode.Create);
            }
            //创建失败，直接返回
            catch
            {
                if(disposeDel != null)
                {
                    disposeDel.Invoke(FTPDisposeStateEnum.Error, 0.0, "Local File : " + saveInPCFilePath + " Create Failed");
                }

                return;
            }
 
            //如果获取文件大小失败的话，则直接返回
            if ((totalRecieveSize = GetFTPFileSize(new Uri("ftp://" + FTPIpAddress + "/" + downloadFTPFileName))) == -1)
            {
                if (disposeDel != null)
                {
                    disposeDel.Invoke(FTPDisposeStateEnum.Error, 0.0, "获取文件大小失败，无法下载");
                }

                return;
            }

            //设置IP和文件位置
            ftpRequest = (FtpWebRequest)FtpWebRequest.Create(new Uri("ftp://" + FTPIpAddress + "/" + downloadFTPFileName));
            //用户名和密码
            ftpRequest.Credentials = new NetworkCredential(FTPUserName, FTPPasswords);
            //执行完请求后连接关闭
            ftpRequest.KeepAlive = false;
            //下载文件
            ftpRequest.Method = WebRequestMethods.Ftp.DownloadFile;
            // 指定数据传输类型  ， binary   
            ftpRequest.UseBinary = true;
            //不要求身份验证
            ftpRequest.AuthenticationLevel = System.Net.Security.AuthenticationLevel.None;
            //不使用ssl安全验证
            ftpRequest.EnableSsl = false;
            ftpRequest.UsePassive = true;
            //设置最长响应时间
            ftpRequest.Timeout = MaxResponseTime;

            try
            {
                //获得FTP服务器回应
                ftpReponse = (FtpWebResponse)ftpRequest.GetResponse();

                // 获得上传流
                using (Stream ftpSender = ftpReponse.GetResponseStream())
                {
                    //处理进度代理回调
                    if (disposeDel != null)
                    {
                        //发送进度 , 状态，开始
                        disposeDel.Invoke(FTPDisposeStateEnum.Start, 0.0, string.Empty);
                    }

                    //每次读文件流的2kb    
                    recieveSize = ftpSender.Read(streamBuff, 0, StreamBuffSize);

                    //文件内容没有结束
                    while (recieveSize != 0)
                    {
                        // 把内容从download stream  写入  file stream
                        downloadFile.Write(streamBuff, 0, recieveSize);
                        //记录已经下载的数据大小
                        totalRecievedSize += recieveSize;

                        //处理进度代理回调
                        if (disposeDel != null)
                        {
                            //发送进度 , 状态，正在执行
                            disposeDel.Invoke(FTPDisposeStateEnum.Disposing, (double)totalRecievedSize / totalRecieveSize, string.Empty);
                        }

                        recieveSize = ftpSender.Read(streamBuff, 0, StreamBuffSize);
                    }

                    downloadFile.Dispose();

                    //处理进度代理回调
                    if (disposeDel != null)
                    {
                        downloadFile.Dispose();
                        //发送进度 , 状态，结束
                        disposeDel.Invoke(FTPDisposeStateEnum.Finished, 1.0, string.Empty);
                    }
                }
            }
            //发送失误，捕捉信息返回
            catch (Exception ex)
            {
                //处理进度代理回调
                if (disposeDel != null)
                {
                    //发送进度 , 状态，错误
                    disposeDel.Invoke(FTPDisposeStateEnum.Error, 0.0, ex.Message);
                }
            }
            finally
            {
                downloadFile.Dispose();
            }
        }

        /// <summary>
        /// 下载文件到本地 ， 如果本地文件名字重复了的话，原始文件将会被删除
        /// <para>此为异步方式</para>
        /// <para>test success 2017.5.9</para>
        /// </summary>
        /// <param name="saveInPCFilePath">保存到本地的文件路径</param>
        /// <param name="downloadFTPFileName">要下载的FTP文件路径</param>
        /// <param name="disposeDel">处理委托代理</param>
        public async void DownLoadFileAsync(string saveInPCFilePath, string downloadFTPFileName, FTPDisposeDel disposeDel = null)
        {
            await Task.Run(() =>
            {
                DownLoadFile(saveInPCFilePath, downloadFTPFileName, disposeDel);
            });
        }
        
        /// <summary>
        /// 获取文件长度
        /// <para>返回：-1获取失败 ， 否则则返回文件大小</para>
        /// <para>同步方式 ， 非异步</para>
        /// </summary>
        /// <param name="filePath">文件路径</param>
        /// <returns></returns>
        private long GetFTPFileSize(Uri filePath)
        {
            long fileSize;
            FtpWebResponse response;
            FtpWebRequest request;

            //设置文件地址
            request = (FtpWebRequest)FtpWebRequest.Create(filePath);
            //设置FTP方式
            request.Method = WebRequestMethods.Ftp.GetFileSize;
            //设置账号密码
            request.Credentials = new NetworkCredential(FTPUserName, FTPPasswords);

            try
            {
                //获取应答
                response = (FtpWebResponse)request.GetResponse();
                //获取文件长度
                fileSize = response.ContentLength;
                //关闭响应
                response.Close();
                //返回文件长度
                return fileSize;
            }
            catch
            {
                return -1;
            }
        }

    }
}
