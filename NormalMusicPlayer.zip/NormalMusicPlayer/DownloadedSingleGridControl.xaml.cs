﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LaoyaosProgramMessage;
using System.IO;

namespace NormalMusicPlayer
{
    /// <summary>
    /// DownloadedSingleGridControl.xaml 的交互逻辑
    /// </summary>
    public partial class DownloadedSingleGridControl : UserControl
    {
        public DLoadedMusicRecord.Record MineRecord;
        public delegate void DeleteDelEvent(DownloadedSingleGridControl sender);
        private DeleteDelEvent DeleteEvent = null;

        public DownloadedSingleGridControl()
        {
            InitializeComponent();
        }

        public DownloadedSingleGridControl(DLoadedMusicRecord.Record record , DeleteDelEvent deleteDel)
        {
            InitializeComponent();
            MineRecord = record;
            //代理事件赋值
            DeleteEvent = deleteDel;
            //信息赋值
            MusicNameTBlock.Text = record.Name;

            TimeTBlock.Text = record.Time.Year.ToString() + "-" + record.Time.Month.ToString() + "-" + record.Time.Day.ToString();
            BookTBlock.Text = record.BelongMusicBook;
            
        }

        //删除按钮被点击
        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if(DeleteEvent != null)
            {
                DeleteEvent.Invoke(this); 
            }
        }

        //在本地查看下载的文件
        private void SeeInFolderButton_Click(object sender, RoutedEventArgs e)
        {
            FileInfo checkForExist = new FileInfo(MineRecord.MusicObsolutePath);
            
            //存在则打开
            if(checkForExist.Exists)
            {
                System.Diagnostics.Process proc = new System.Diagnostics.Process();
                proc.StartInfo.FileName = "explorer";
                //打开资源管理器
                proc.StartInfo.Arguments = @"/select," + MineRecord.MusicObsolutePath;
                proc.Start();
            }
            else
            {
                string[] musicName = MineRecord.MusicObsolutePath.Split(new char[] { '\\' });

                MainWindow.MySelf.DisplayMessage("文件 " + musicName[musicName.Length - 1] + " 不存在或已经被删除");
            }
            
        }
    }
}
