﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LaoyaosImage;
using LaoyaosProgramMessage;
using LaoyaosMedia;
using DialogBox = System.Windows.Forms;

namespace NormalMusicPlayer
{
    /// <summary>
    /// MusicBookControl.xaml 的交互逻辑
    /// </summary>
    public partial class MusicBookControl : UserControl
    {
        public const int ImageSize = 100;
        private bool IsChoosed = false;
        public delegate void MusicBookClickedDel(MusicBookControl sender);
        /// <summary>
        /// 音乐集合添加音乐事件，在此之前，信息已经被添加进入了集合内部
        /// </summary>
        /// <param name="sender">发送者，要添加音乐的音乐集合</param>
        /// <param name="addMusic">添加的音乐</param>
        public delegate void MusicBookAddNewMusicDel(MusicBookControl sender , MusicPlayBarGridControl.MusicContextSingle addMusic);
        private MusicBookClickedDel MusicBookNormalClicked = null;
        private MusicBookClickedDel MusicBookDeleteClicked = null;
        private MusicBookAddNewMusicDel MusicBookAddNewMusic = null;
        //所有的音乐上下文
        public List<MusicPlayBarGridControl.MusicContextSingle> TotalContext = null;
        public List<MP3Information.InformationStruct> TotalInformations = null;
        public MusicBook Contain;

        public enum BookType
        {
            UserCreate,
            Default
        }

        public MusicBookControl()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 去除所有按钮，只保留点击事件的book control , 
        /// </summary>
        /// <param name="normalClick">普通点击事件</param>
        /// <param name="contain">包含的书本</param>
        public MusicBookControl(MusicBookClickedDel normalClick , MusicBook contain)
        {
            InitializeComponent();
            //所包含的信息
            Contain = contain;
            //点击事件赋值
            MusicBookNormalClicked = normalClick;
            //设置名字
            NameTextBlock.Text = Contain.Name;
            //设置图标
            BookIcon.Source = JPGImage.ResizeImage(Contain.ImagePath, ImageSize, ImageSize);
            DeleteButton.Visibility = Visibility.Collapsed;
            AddButton.Visibility = Visibility.Collapsed;
        }

        public MusicBookControl(MusicBookClickedDel normalClick , MusicBookClickedDel deleteClick , MusicBookAddNewMusicDel addDel , MusicBook contain , BookType type)
        {
            InitializeComponent();
            //点击事件赋值
            MusicBookNormalClicked = normalClick;
            //删除事件赋值
            MusicBookDeleteClicked = deleteClick;
            //添加音乐事件赋值
            MusicBookAddNewMusic = addDel;
            //所包含的信息
            Contain = contain;
            //设置名字
            NameTextBlock.Text = Contain.Name;
            //设置图标
            BookIcon.Source = JPGImage.ResizeImage(Contain.ImagePath, ImageSize, ImageSize);

            switch(type)
            {
                //默认文件夹无法删除
                case BookType.Default:
                    DeleteButton.Visibility = Visibility.Collapsed;
                    AddButton.Visibility = Visibility.Visible;
                    break;
                case BookType.UserCreate:
                    DeleteButton.Visibility = Visibility.Visible;
                    AddButton.Visibility = Visibility.Visible;
                    break;
            }

            TotalContext = new List<MusicPlayBarGridControl.MusicContextSingle>();
            TotalInformations = new List<MP3Information.InformationStruct>();
            //添加上下文 , 制造总文
            foreach (BookMusicDetials item in Contain.ContainMusics)
            {

                MusicPlayBarGridControl.MusicContextSingle singleContext = new MusicPlayBarGridControl.MusicContextSingle(
                    new MusicPlayBarGridControl.LocalMusicInformation(item.MusicPath, item.AlbumImagePath, item.ArtistImagePath));
                TotalContext.Add(singleContext);
                //添加音乐信息 , 不获取图片信息
                TotalInformations.Add(MP3Information.GetMP3StringInformation(item.MusicPath));
            }
        }

        private void ContainGrid_MouseEnter(object sender, MouseEventArgs e)
        {
            if(!IsChoosed)
            {
                ContainGrid.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#AFB7B7B7"));
            }
        }

        /// <summary>
        /// 取消被选择
        /// </summary>
        public void UnChoosed()
        {
            IsChoosed = false;
            //ContainGrid.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#AFB7B7B7"));
            ContainGrid.Background = null;
        }

        private void ContainGrid_MouseLeave(object sender, MouseEventArgs e)
        {
            if(!IsChoosed)
            {
                //ContainGrid.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#4CB7B7B7"));
                ContainGrid.Background = null;
            }
        }

        private void ContainGrid_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            MusicBookChoosed();
        }

        /// <summary>
        /// 音乐集合被选择事件 ， 此事件外部只能在初始化时设置默认音乐集合被选择时调用、
        /// </summary>
        public void MusicBookChoosed()
        {
            //防止被重复点击，重复执行
            if (IsChoosed)
            {
                return;
            }
            IsChoosed = true;
            ContainGrid.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#AFB7B7B7"));
            //调用委托函数
            if (MusicBookNormalClicked != null)
            {
                MusicBookNormalClicked.Invoke(this);
            }
        }

        //删除该音乐集
        //finished
        //test success , 2017-5-4
        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            //确认是否删除
            LaoyaosDialogBoxForSure sure = new LaoyaosDialogBoxForSure("确认删除该音乐集合?\n\n(所有下载的音乐都将被删除)");
            sure.Owner = Application.Current.MainWindow;

            //如果确认删除
            if(sure.ShowDialog().Value)
            {
                //调用删除委托事件
                if(MusicBookDeleteClicked != null)
                {
                    MusicBookDeleteClicked.Invoke(this);
                }
            }
        }

        //添加音乐按钮执行
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            DialogBox.OpenFileDialog dialog = new DialogBox.OpenFileDialog();
            string[] musicPaths = null;
            dialog.Title = "Add Music File";
            dialog.CheckFileExists = true;
            dialog.Filter = "Music File(*.mp3)|*.mp3";
            //选择多个
            dialog.Multiselect = true;

            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                //获得所有本地的音乐路径集合
                List<string> totalLocalPaths = (from path in Contain.ContainMusics
                                           where path.Type == BookMusicDetials.MusicType.LocalMusic
                                           select path.MusicPath).ToList<string>();
                //获得所有的选择的音乐
                musicPaths = dialog.FileNames;

                //设置为本地音乐
                foreach (string music in musicPaths)
                {
                    //防止重复添加同一音乐本地到音乐集合内
                    if(!totalLocalPaths.Contains(music))
                    {
                        AddMusicToBook(new BookMusicDetials(music, null, null, BookMusicDetials.MusicType.LocalMusic));
                    }
                }
            }
        }

        //不能重复添加音乐  ,外部调用，添加音乐到音乐集内部
        public void AddMusicToBook(BookMusicDetials musicDetials)
        {
            //添加音乐到集合内部，最新添加的在最前面
            if(!Contain.ContainMusics.Contains(musicDetials))
            {
                Contain.ContainMusics.Insert(0, musicDetials);

                //添加上下文
                MusicPlayBarGridControl.MusicContextSingle singleContext = new MusicPlayBarGridControl.MusicContextSingle(
                    new MusicPlayBarGridControl.LocalMusicInformation(musicDetials.MusicPath, musicDetials.AlbumImagePath, musicDetials.ArtistImagePath));
                TotalContext.Insert(0 , singleContext);
                //添加音乐信息 , 不获取图片信息
                TotalInformations.Insert(0 , MP3Information.GetMP3StringInformation(musicDetials.MusicPath));

                //执行事件代理
                MusicBookAddNewMusic.Invoke(this, singleContext);
            }
        }
    }
}
