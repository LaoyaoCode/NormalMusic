﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace LaoyaosFile
{
    public static class FileStruct
    {
        public static string RootOfExePath = AppDomain.CurrentDomain.BaseDirectory;
        /// <summary>
        /// 缓冲文件夹
        /// </summary>
        public static string BuffBookName = RootOfExePath + "BuffDataBook";
        /// <summary>
        /// 上传缓冲文件夹 , 没有分隔符
        /// </summary>
        public static string BuffUpLoadBookName = BuffBookName + "\\BuffULoadBook";
        /// <summary>
        /// 缓冲音乐文件夹
        /// </summary>
        public static string BuffNetMusicBookName = BuffBookName + "\\BuffMusicBook";
        /// <summary>
        /// 缓冲音乐文件名，不包含文件类型
        /// </summary>
        public static string BuffNetMusicName = BuffBookName + "\\BuffMusicBook\\BuffMusic";
        /// <summary>
        /// 用户图片缓冲文件夹名字 , 没有文件分隔符
        /// </summary>
        public static string UserIconBuffBook = BuffBookName + "\\UserIconBuff";
        /// <summary>
        /// 缓冲缩放JPG图片地址，附带后缀 .jpg
        /// </summary>
        public static string ScaleJPGImageBuffName = BuffBookName + "\\BuffJPGImage.jpg";
        /// <summary>
        /// 缓冲缩放结果JPG图片地址，附带后缀 .jpg
        /// </summary>
        public static string ScaleResultJPGImageBuffName = BuffBookName + "\\BuffResultJPGImage.jpg";
        /// <summary>
        /// 用户本地数据路劲
        /// </summary>
        public static string UserDataBookName = RootOfExePath + "UserData";
        /// <summary>
        /// 用户本地数据---音乐book image 文件夹路径 ， 最后没有分隔符
        /// </summary>
        public static string MusiBookImageSaveBook= UserDataBookName + "\\MBImage";
        /// <summary>
        /// 音乐下载保存目录，没有分隔符
        /// </summary>
        public static string MusicDownLoadSaveBook = UserDataBookName + "\\DLMusic";
        /// <summary>
        /// 音乐图片下载保存目录，没有分隔符
        /// </summary>
        public static string MusicImageDownLoadSaveBook = UserDataBookName + "\\DLMusicImage";
        /// <summary>
        /// 已经下载的音乐记录数据文件
        /// </summary>
        public static string DownLoadedRecordsFileName = UserDataBookName + "\\DLoadedMusicRecord.xml";
        /// <summary>
        /// 用户所有的音乐集
        /// </summary>
        public static string MusicBookTotalFileName = UserDataBookName + "\\UserTotalBook.xml";
        /// <summary>
        /// 用户本地数据路劲
        /// </summary>
        public static string MusicDefaultBookFileName = UserDataBookName + "\\UserDefaultBook.xml";
        /// <summary>
        /// 所有下载在本地的网易云音乐ID
        /// </summary>
        public static string TotalDownLoadToLocalNetMusicIDFileName = UserDataBookName + "\\TDNMusicID.xml";
        /// <summary>
        /// 所有下载在本地的云音乐ID
        /// </summary>
        public static string TotalDownLoadToLocalCloudMusicIDFileName = UserDataBookName + "\\TDCMusicID.xml";
        /// <summary>
        /// 用户的云头像文件地址
        /// </summary>
        public static string UserCloudIconFileName = UserDataBookName + "\\UserCloudIcon.jpg";

        /// <summary>
        /// 应用程序数据文件夹
        /// </summary>
        public static string AppDefineDataBookName = RootOfExePath + "AppDefineData";
        /// <summary>
        /// 应用程序初始化设定文件名
        /// </summary>
        public static string AppInitDataFileName = AppDefineDataBookName + "\\AppInit.xml";
        /// <summary>
        /// 应用程序秘钥文件名
        /// </summary>
        public static string AppLisenceDataFileName = AppDefineDataBookName + "\\Lisence.xml";
        /// <summary>
        /// 下载的音乐文件后缀
        /// </summary>
        public const string SaveSongAddString = ".mp3";
        /// <summary>
        /// 下载的专辑图片后缀
        /// </summary>
        public const string SaveAlbumImageAddString = "_album.jpg";
        /// <summary>
        /// 下载的歌手图片后缀
        /// </summary>
        public const string SaveArtistImageAddString = "_artist.jpg";

        /// <summary>
        /// 初始化文件结构
        /// </summary>
        /// <returns>true 初始化成功 ， false 初始化失败</returns>
        public static bool Init()
        {
            try
            {
                CheckForDir(BuffBookName);
                CheckForDir(BuffNetMusicBookName);
                CheckForDir(UserDataBookName);
                CheckForDir(AppDefineDataBookName);
                CheckForDir(MusiBookImageSaveBook);
                CheckForDir(MusicDownLoadSaveBook);
                CheckForDir(MusicImageDownLoadSaveBook);
                CheckForDir(BuffUpLoadBookName);

                //删除缓冲文件夹下所有文件
                DirectoryInfo clearBuff = new DirectoryInfo(UserIconBuffBook);

                if(clearBuff.Exists)
                {
                    clearBuff.Delete(true);
                    
                }

                clearBuff.Create();
                //CheckForDir(UserIconBuffBook);
            }
            catch
            {
                return false;
            }

            return true;
        }

        public static void CheckForDir(string path)
        {
            DirectoryInfo information = null;

            information = new DirectoryInfo(path);
            if (!information.Exists)
            {
                information.Create();
            }
        }
     
        /// <summary>
        /// 获取唯一的音乐文件名 ， 返回文件名附带后缀
        /// </summary>
        /// <param name="musicTitle">音乐名字</param>
        /// <returns></returns>
        public static string UnityMusicName(string musicTitle)
        {
            FileInfo checkForNameUnity = null;
            int counterForIndex = 1;
            //初始路径，无后缀名
            string originalPathNE = FileStruct.MusicDownLoadSaveBook + "\\" + musicTitle;
            //结果路径，无后缀名
            string resultPathNE = originalPathNE;

            //初始路径检查
            checkForNameUnity = new FileInfo(resultPathNE + SaveSongAddString);
            //直到找到不存在的文件名
            while (checkForNameUnity.Exists)
            {
                resultPathNE = originalPathNE + "(" + counterForIndex.ToString() + ")";
                counterForIndex++;
                checkForNameUnity = new FileInfo(resultPathNE + SaveSongAddString);
            }

            return resultPathNE + SaveSongAddString;
        }
    }

    public static class NormalFTPFileStruct
    {
        /// <summary>
        /// 程序引用根目录book , 没有文件分隔符
        /// </summary>
        public const string RootBookName = "NormalMusicUserData";

        /// <summary>
        /// 用户图标文件名称
        /// </summary>
        public const string UserIconName = "UserIcon.jpg";
        /// <summary>
        /// 用户图片文件文件夹名 , 没有文件分隔符
        /// </summary>
        public const string UserImageBookName = "Image";
        /// <summary>
        /// 用户音乐文件文件夹名 , 没有文件分隔符
        /// </summary>
        public const string UserMusicBookName = "Music";
    }
}
