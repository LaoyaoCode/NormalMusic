﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LaoyaosProgramMessage;
using System.IO;
using LaoyaosFile;
using LaoyaosMedia;

namespace NormalMusicPlayer
{
    /// <summary>
    /// MusicBooksControl.xaml 的交互逻辑
    /// </summary>
    public partial class MusicBooksControl : UserControl
    {
        /// <summary>
        /// 书本总集控制 , key 为ID ， value 为控件
        /// </summary>
        private Dictionary<string, MusicBookControl> AllBooksDic = null;
        private TotalBooksControl BooksControl = null;
        private DefaultBookControl DefaultBookControl = null;
        private MusicBookControl NowDisplayBook = null;
        //private List<MusicBookControl> AllBooksList = null;

        public MusicBooksControl()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            MusicBookControl book = null;
            //初始化所有音乐集集合
            //AllBooksList = new List<MusicBookControl>();
            AllBooksDic = new Dictionary<string, MusicBookControl>();
            BooksControl = new TotalBooksControl();
            DefaultBookControl = new DefaultBookControl();

            //将所有音乐集添加到显示区域
            for(int counter = 0; counter < BooksControl.TotalBooks.Count; counter++)
            {
                book = new MusicBookControl(BookNormal_Click, BookDelete_Click  , BookAddMusicDelDispose , BooksControl.TotalBooks[counter], MusicBookControl.BookType.UserCreate);
                //添加文件集到显示区域
                MusicBookViewSP.Children.Add(book);
                //添加文件集到集合
                //AllBooksList.Add(book);
                AllBooksDic.Add(book.Contain.ID, book);
            }

            book = new MusicBookControl(BookNormal_Click, null, BookAddMusicDelDispose, DefaultBookControl.Default, MusicBookControl.BookType.Default);
            //添加默认文件集到显示区域
            MusicBookViewSP.Children.Add(book);
            //添加默认文件集到集合
            AllBooksDic.Add(book.Contain.ID, book);
            //添加默认文件集到集合
            //AllBooksList.Add(book);
        }

        private void BookNormal_Click(MusicBookControl sender)
        {
            //切换显示
            if (NowDisplayBook != null)
            {
                NowDisplayBook.UnChoosed();
            }

            NowDisplayBook = sender;
            //清除所有子对象
            MusicBookDetialsSP.Children.Clear();

            for (int counter = 0; counter < NowDisplayBook.TotalContext.Count; counter++)
            {
                //添加对象
                MusicBookDetialsSP.Children.Add(new MusicBookSingleMusicGrid(NowDisplayBook.TotalInformations[counter], NowDisplayBook.TotalContext[counter], NowDisplayBook.TotalContext, BookDeleteMusicDel, NowDisplayBook));
            }
        }

        //删除事件委托 ， 删除音乐集
        //完成，测试OK了 ， 2017.5.12
        private void BookDelete_Click(MusicBookControl sender)
        {
            MusicBook deleteBook = sender.Contain;
            //从信息集合中删除引用
            BooksControl.TotalBooks.Remove(deleteBook);
            //从显示集合中删除引用
            AllBooksDic.Remove(sender.Contain.ID);
            //AllBooksList.Remove(sender);
            //从显示区域删除引用
            MusicBookViewSP.Children.Remove(sender);
            //如果正在查看的是要删除的音乐集合,则,清空所有书本显示的音乐
            if(NowDisplayBook == sender)
            {
                MusicBookDetialsSP.Children.Clear();
            }
            //清除上下文
            sender.TotalContext.Clear();

            try
            {
                //删除音乐集合代表图片
                FileInfo deleteFile = new FileInfo(deleteBook.ImagePath);
                //存在则删除
                if(deleteFile.Exists)
                {
                    deleteFile.Delete();
                }
                
                //删除音乐
                foreach (BookMusicDetials music in deleteBook.ContainMusics)
                {
                    //下载的音乐，则需要删除所有文件
                    if(music.Type == BookMusicDetials.MusicType.DownloadMusic)
                    {
                        //应为音乐地址绝对唯一存在 ， 所以可以用来反找id
                        if (MainWindow.MySelf.DownLoad.DownLoadedIDS.NetIDS.ContainsValue(music.MusicPath))
                        {
                            string id = (from pair in MainWindow.MySelf.DownLoad.DownLoadedIDS.NetIDS
                                         where pair.Value == music.MusicPath
                                         select pair.Key).ToArray<string>()[0];

                            MainWindow.MySelf.DownLoad.DownLoadedIDS.NetIDS.Remove(id);
                            //保存修改
                            MainWindow.MySelf.DownLoad.DownLoadedIDS.SaveToLocal();
                        }
                        else if (MainWindow.MySelf.DownLoad.DownLoadedIDS.CloudIDS.ContainsValue(music.MusicPath))
                        {
                            string id = (from pair in MainWindow.MySelf.DownLoad.DownLoadedIDS.CloudIDS
                                         where pair.Value == music.MusicPath
                                         select pair.Key).ToArray<string>()[0];

                            MainWindow.MySelf.DownLoad.DownLoadedIDS.CloudIDS.Remove(id);
                            //保存修改
                            MainWindow.MySelf.DownLoad.DownLoadedIDS.SaveToLocal();
                        }

                        if (music.MusicPath != string.Empty && music.MusicPath != null)
                        {
                            //删除音乐文件
                            deleteFile = new FileInfo(music.MusicPath);
                            if (deleteFile.Exists)
                            {
                                deleteFile.Delete();
                            }
                        }

                        if (music.AlbumImagePath != string.Empty && music.AlbumImagePath != null)
                        {
                            //删除专辑图片
                            deleteFile = new FileInfo(music.AlbumImagePath);
                            if (deleteFile.Exists)
                            {
                                deleteFile.Delete();
                            }
                        }

                        if (music.ArtistImagePath != string.Empty && music.ArtistImagePath != null)
                        {
                            //删除艺术家
                            deleteFile = new FileInfo(music.ArtistImagePath);
                            if (deleteFile.Exists)
                            {
                                deleteFile.Delete();
                            }
                        }
                    }
                    //本地音乐则无需删除任何文件
                    else
                    {

                    }
                }
           }
           catch
           {

           }
        }

        //音乐集合添加音乐执行代理事件，更新UI
        private void BookAddMusicDelDispose(MusicBookControl sender, MusicPlayBarGridControl.MusicContextSingle addMusic)
        {
            //如果当前显示的Book就是要添加音乐的book，则需要立即更新UI
            if (NowDisplayBook == sender)
            {
                this.Dispatcher.Invoke(() =>
                {
                    MusicBookDetialsSP.Children.Insert(0, new MusicBookSingleMusicGrid(MP3Information.GetMP3StringInformation(addMusic.LocalMusic.UriOrPath), addMusic, sender.TotalContext, BookDeleteMusicDel, NowDisplayBook));
                });
            }
        }

        //书本删除音乐的代理
        private void BookDeleteMusicDel(MusicBookSingleMusicGrid single , MusicBookControl father)
        {
            FileInfo deleteFile = null;

            //获取索引位置
            int index = MusicBookDetialsSP.Children.IndexOf(single);
            //除去显示
            MusicBookDetialsSP.Children.Remove(single);

            //获得音乐信息
            BookMusicDetials music = father.Contain.ContainMusics[index];
            //删除音乐信息
            father.Contain.ContainMusics.RemoveAt(index);
            //保存修改
            SaveToLocal();

            //去除音乐上下文
            father.TotalContext.RemoveAt(index);

            //如果是下载音乐 ， 则要删除文件以及下载ID
            if (music.Type == BookMusicDetials.MusicType.DownloadMusic)
            {
                //应为音乐地址绝对唯一存在 ， 所以可以用来反找id
                if(MainWindow.MySelf.DownLoad.DownLoadedIDS.NetIDS.ContainsValue(music.MusicPath))
                {
                    string id = (from pair in MainWindow.MySelf.DownLoad.DownLoadedIDS.NetIDS
                              where pair.Value == music.MusicPath
                              select pair.Key).ToArray<string>()[0];

                    MainWindow.MySelf.DownLoad.DownLoadedIDS.NetIDS.Remove(id);
                    //保存修改
                    MainWindow.MySelf.DownLoad.DownLoadedIDS.SaveToLocal();
                }
                else if(MainWindow.MySelf.DownLoad.DownLoadedIDS.CloudIDS.ContainsValue(music.MusicPath))
                {
                    string id = (from pair in MainWindow.MySelf.DownLoad.DownLoadedIDS.CloudIDS
                              where pair.Value == music.MusicPath
                              select pair.Key).ToArray<string>()[0];

                    MainWindow.MySelf.DownLoad.DownLoadedIDS.CloudIDS.Remove(id);
                    //保存修改
                    MainWindow.MySelf.DownLoad.DownLoadedIDS.SaveToLocal();

                    //在用户上传目录中寻找对应ID并删除记录
                    MainWindow.MySelf.UserPanel.CloudIDRecordDelete(id);
                    //在正在显示的别的用户上传文件目录中寻找对应ID并删除记录
                    MainWindow.MySelf.CloudPanel.CloudIDRecordDelete(id);
                }

                if(music.MusicPath != string.Empty && music.MusicPath != null)
                {
                    //删除音乐文件
                    deleteFile = new FileInfo(music.MusicPath);
                    if (deleteFile.Exists)
                    {
                        deleteFile.Delete();
                    }
                }

                if(music.AlbumImagePath != string.Empty && music.AlbumImagePath != null)
                {
                    //删除专辑图片
                    deleteFile = new FileInfo(music.AlbumImagePath);
                    if (deleteFile.Exists)
                    {
                        deleteFile.Delete();
                    }
                }

                if (music.ArtistImagePath != string.Empty && music.ArtistImagePath != null)
                {
                    //删除艺术家
                    deleteFile = new FileInfo(music.ArtistImagePath);
                    if (deleteFile.Exists)
                    {
                        deleteFile.Delete();
                    }
                }

                string[] deleteFileNames = music.MusicPath.Split(new char[] { '\\' });

                MainWindow.MySelf.DisplayMessage("成功删除文件 " + deleteFileNames[deleteFileNames.Length - 1]);
            }
            //手动添加的本地音乐则无需删除
            else
            {

            }
        }

        /// <summary>
        /// 保存信息到本地
        /// </summary>
        public void SaveToLocal()
        {
            BooksControl.SavToLocal();
            DefaultBookControl.SavToLocal();
        }

        /// <summary>
        /// 添加音乐到音乐集合
        /// <para>返回添加至的音乐集合名称</para>
        /// </summary>
        /// <param name="bookID">集合ID</param>
        /// <param name="music">要添加的音乐</param>
        public string AddMusicToMusicBook(string bookID , BookMusicDetials music)
        {
            //如果ID有效的话，则添加至对应的音乐集合
            if(AllBooksDic.ContainsKey(bookID))
            {
                AllBooksDic[bookID].AddMusicToBook(music);
                MainWindow.MySelf.DisplayMessage("已添加至音乐集 ： " + AllBooksDic[bookID].Contain.Name);
                return AllBooksDic[bookID].Contain.Name;
            }
            //如果ID无效 , 则添加至默认
            else
            {
                AllBooksDic["0"].AddMusicToBook(music);
                MainWindow.MySelf.DisplayMessage("音乐集合丢失，添加至默认音乐集");
                return AllBooksDic["0"].Contain.Name;
            }
        }

        private void AddBookButton_Click(object sender, RoutedEventArgs e)
        {
            AddMusicBookDispose();
        }

        /// <summary>
        /// 添加音乐集
        /// </summary>
        private void AddMusicBookDispose()
        {
            AddMusicBookDialog dialog = new AddMusicBookDialog();
            dialog.Owner = Application.Current.MainWindow;

            //确认创建了音乐文件集合
            if(dialog.ShowDialog().Value)
            {
                string imageSourcePath = dialog.ResultInformation.ImagePath;
                string musicBookName = dialog.ResultInformation.Name;
                FileInfo file = new FileInfo(imageSourcePath);
                MusicBook book = null;
                MusicBookControl bookDisplay = null;

                //音乐图片文件名+当前时间日期 产生唯一的hash字符串，确保没有文件重名
                string imageTagetPath = FileStruct.MusiBookImageSaveBook + "\\" + UnityString.UseMD5(imageSourcePath + DateTime.Now.ToString()) + ".jpg";
                //赋值到目标文件路径
                file.CopyTo(imageTagetPath);
                //以绝对唯一图片文件地址 + 集合名 + 随机double数字作为唯一绝对ID
                book = new MusicBook(imageTagetPath, musicBookName, new List<BookMusicDetials>() , UnityString.UseMD5(imageTagetPath + musicBookName + (new Random()).NextDouble().ToString()));
                //添加新的音乐文件集合
                BooksControl.TotalBooks.Insert(0, book);

                bookDisplay = new MusicBookControl(BookNormal_Click, BookDelete_Click, BookAddMusicDelDispose ,  book, MusicBookControl.BookType.UserCreate);
                //添加文件集到显示区域
                MusicBookViewSP.Children.Insert(0 , bookDisplay);
                //添加文件集到集合
                //AllBooksList.Insert( 0 , bookDisplay);
                AllBooksDic.Add(bookDisplay.Contain.ID, bookDisplay);
            }
        }

        /// <summary>
        /// 选择一个现有的音乐文件集
        /// <para>成功选择 ， 则返回ID , 如果选择取消，则返回string.empty</para>
        /// </summary>
        /// <returns></returns>
        public string SelectMusicBook_OutsideUse()
        {
            SelectMusicBookDialog dialog = new SelectMusicBookDialog(DefaultBookControl, BooksControl);
            dialog.Owner = Application.Current.MainWindow;

            //成功选择 ， 则返回ID
            if(dialog.ShowDialog().Value)
            {
                return dialog.SelectBookID;
            }
            //如果选择取消，则返回string.empty
            else
            {
                return string.Empty;
            }
        }
    }
}
