﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LaoyaosMedia;
using LaoyaosImage;
using LaoyaosFile;
using LaoyaosProgramMessage;
using System.IO;

namespace NormalMusicPlayer
{
    /// <summary>
    /// MusicPlayBarGridControl.xaml 的交互逻辑
    /// </summary>
    public partial class MusicPlayBarGridControl : UserControl
    {
        /// <summary>
        /// 音乐被成功播放事件
        /// </summary>
        public delegate void MusicSuccessPlayedDelEvent();
        /// <summary>
        /// 音乐被切换播放事件
        /// </summary>
        public delegate void MusicChangePlayDelEevent();
        /// <summary>
        /// 音乐开始缓存事件
        /// </summary>
        public delegate void MusicBeginBuffDelEevent();
        /// <summary>
        /// 音乐错误事件
        /// </summary>
        public delegate void MusicErrorDelEevent();
        public enum MusicSourceType
        {
            LocalMusicPath,
            NetMusicUri
        }

        public class NetMusicInformation
        {
            private NetMusicSearch.SongInformation _Information;

            private string _AlbumImagePath = null;
            private string _ArtistImagePath = null;

            public NetMusicSearch.SongInformation Information
            {
                get
                {
                    return _Information;
                }
            }

            public string AlbumImagePath
            {
                get
                {
                    return _AlbumImagePath;
                }
            }

            public string ArtistImagePath
            {
                get
                {
                    return _ArtistImagePath;
                }
            }

            public NetMusicInformation(NetMusicSearch.SongInformation information)
            {
                _Information = information;
            }

            /// <summary>
            /// 设置图片的地址
            /// </summary>
            /// <param name="album">专辑图片地址</param>
            /// <param name="artist">歌手图片地址</param>
            public void SetImagePath(string album, string artist)
            {
                _AlbumImagePath = album;
                _ArtistImagePath = artist;
            }

        }

        public class LocalMusicInformation
        {
            private string _UriOrPath;
            private string _AlbumImagePath;
            private string _ArtistImagePath;

            public LocalMusicInformation(string path)
            {
                _UriOrPath = path;
                _ArtistImagePath = null;
                _AlbumImagePath = null;
            }

            /// <summary>
            /// 所有路径如果存在不存在的，则设置为null
            /// </summary>
            /// <param name="path"></param>
            /// <param name="albumPath"></param>
            /// <param name="artistPath"></param>
            public LocalMusicInformation(string path, string albumPath, string artistPath)
            {
                _UriOrPath = path;

                if(albumPath == null || albumPath == string.Empty)
                {
                    _AlbumImagePath = null;
                }
                else
                {
                    _AlbumImagePath = albumPath;
                }

                if (artistPath == null || artistPath == string.Empty)
                {
                    _ArtistImagePath = null;
                }
                else
                {
                    _ArtistImagePath = artistPath;
                }
            }

            public string UriOrPath
            {
                get
                {
                    return _UriOrPath;
                }
            }

            public string AlbumImagePath
            {
                get
                {
                    return _AlbumImagePath;
                }
            }

            public string ArtistImagePath
            {
                get
                {
                    return _ArtistImagePath;
                }
            }
        }

        public class MusicContextSingle
        {
            private LocalMusicInformation _LocalMusic = null;
            private MusicSourceType _SourceType;
            private NetMusicInformation _NetMusic = null;
            private MusicSuccessPlayedDelEvent MusicSuccessPlayedEvent = null;
            private MusicChangePlayDelEevent MusicChangePlayEevent = null;
            private MusicBeginBuffDelEevent MusicBeginBuffEevent = null;
            private MusicErrorDelEevent MusicErrorEevent = null;
            private ContextConditionEnum _ContextCondition = ContextConditionEnum.None;

            public enum ContextConditionEnum
            {
                SuccessPlayed ,
                ChangePlay ,
                BeginBuff ,
                Error , 
                None
            }

            public MusicSourceType SourceType
            {
                get
                {
                    return _SourceType;
                }
            }

            public LocalMusicInformation LocalMusic
            {
                get
                {
                    return _LocalMusic;
                }
            }

            public NetMusicInformation NetMusic
            {
                get
                {
                    return _NetMusic;
                }
            }

            /// <summary>
            /// 上下文的状态
            /// </summary>
            public ContextConditionEnum ContextCondition
            {
                get
                {
                    return _ContextCondition;
                }
            }

            /// <summary>
            /// 音乐单个上下文
            /// </summary>
            /// <param name="information">本地音乐信息结构体</param>
            public MusicContextSingle(LocalMusicInformation information)
            {
                _LocalMusic = information;
                _SourceType = MusicSourceType.LocalMusicPath;
            }

            /// <summary>
            /// 音乐单个上下文
            /// </summary>
            /// <param name="information">网络音乐信息结构体</param>
            public MusicContextSingle(NetMusicSearch.SongInformation information)
            {
                _NetMusic = new NetMusicInformation(information);
                _SourceType = MusicSourceType.NetMusicUri;
            }

            /// <summary>
            /// 设置事件代理
            /// </summary>
            /// <param name="played">成功缓冲播放事件</param>
            /// <param name="change">切换播放事件</param>
            /// <param name="begin">开始缓存事件</param>
            public void SetEvent(MusicSuccessPlayedDelEvent played, MusicChangePlayDelEevent change , MusicBeginBuffDelEevent begin , MusicErrorDelEevent error)
            {
                MusicSuccessPlayedEvent = played;
                MusicChangePlayEevent = change;
                MusicBeginBuffEevent = begin;
                MusicErrorEevent = error;
            }
            /// <summary>
            /// 被选择时调用
            /// </summary>
            public void SuccessPlayed()
            {
                if (MusicSuccessPlayedEvent != null)
                {
                    MusicSuccessPlayedEvent.Invoke();
                }

                _ContextCondition = ContextConditionEnum.SuccessPlayed;
            }

            /// <summary>
            /// 被其他的选择时调用
            /// </summary>
            public void ChangePlay()
            {
                if (MusicChangePlayEevent != null)
                {
                    MusicChangePlayEevent.Invoke();
                }

                _ContextCondition = ContextConditionEnum.ChangePlay;
            }

            /// <summary>
            /// 开始缓存时调用
            /// </summary>
            public void BeginBuff()
            {
                if (MusicBeginBuffEevent != null)
                {
                    MusicBeginBuffEevent.Invoke();
                }

                _ContextCondition = ContextConditionEnum.BeginBuff;
            }

            //播放或者缓冲错误时调用
            public void Error()
            {
                if (MusicErrorEevent != null)
                {
                    MusicErrorEevent.Invoke();
                }

                _ContextCondition = ContextConditionEnum.Error;
            }
        }

        private const int InPlayBarMusicImageWH = 100;
        private const int InDetialGridMusicImageWH = 150;
        //音乐播放滑块是否正在被拖动
        private bool IsMusicPlayerSliderDraged = false;
        //音乐是否可以暂停
        private bool IsMusicCanPause = false;
        //我的音乐播放器
        private  MP3Player MyPlayer = null;
        //音乐上下文
        private List<MusicContextSingle> MusicContexts = null;
        //正在播放的音乐
        private MusicContextSingle PlayingMusicInformation;
        //网络音乐缓存是否结束
        private bool NetMusicBuffingFinished = true;
        //音乐音量控制
        private ProgramVolumeControl VolumeControl = null;

        private MusicPlayModeControl ModeControl = null;

        public MusicPlayBarGridControl()
        {
            InitializeComponent();

            //初始化音量控制实例
            VolumeControl = new ProgramVolumeControl();
            //如果之前静音的话
            if (VolumeControl.IsSlience)
            {
                VolumeSlider.Value = 0;
                VolumeSlider.IsEnabled = false;
                VolumeButtonImage.Source = new BitmapImage(new Uri("UIImage\\VolumeZeroIcon.png", UriKind.Relative));
            }
            else
            {
                VolumeSlider.Value = VolumeControl.Value;
                VolumeSlider.IsEnabled = true;
                VolumeButtonImage.Source = new BitmapImage(new Uri("UIImage\\VolumeNormalIcon.png", UriKind.Relative));
            }

            ModeControl = new MusicPlayModeControl();
            if(ModeControl.MusicMode == MusicPlayModeControl.Mode.Circle)
            {
                PlayModeButton.ToolTip = "循环播放";
                PlayModeButtonIcon.Source = new BitmapImage(new Uri("UIImage\\CirclePlayIcon.png", UriKind.Relative));
            }
            else
            {
                PlayModeButton.ToolTip = "随机播放";
                PlayModeButtonIcon.Source = new BitmapImage(new Uri("UIImage\\RandomPlayIcon.png", UriKind.Relative));
            }

            //必须要这么添加事件才能够实现只获取最终的值
            MusicPlaySlider.AddHandler(Slider.MouseLeftButtonUpEvent, new MouseButtonEventHandler(MusicPlaySlider_MouseLeftButtonUp), true);
            MusicPlaySlider.AddHandler(Slider.MouseLeftButtonDownEvent, new MouseButtonEventHandler(MusicPlaySlider_MouseLeftButtonDown), true);
            MusicPlaySlider.AddHandler(Slider.PreviewMouseLeftButtonDownEvent, new MouseButtonEventHandler(MusicPlaySlider_PreviewMouseLeftButtonDown), true);
            //网络音乐播放提示label
            NetMusicPlayMessageLabel.Content = string.Empty;
            //禁止滑动条操作
            MusicPlaySlider.IsEnabled = false;
            //切换可播放按钮形态
            PlayOrPauseMusicButton_PlayIcon();
            //禁止播放按钮
            PlayOrPauseMusicButton.IsEnabled = false;

            //初始禁止上下移动
            LastMusicButton.IsEnabled = false;
            NextMusicButton.IsEnabled = false;

            MyPlayer = new MP3Player((float)VolumeControl.Value);
        }

        //-----------------音乐滑动条事件----------finished------------------------------------------------
        private void MusicPlaySlider_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            IsMusicPlayerSliderDraged = false;
            MyPlayer.ChangePosition((float)(MusicPlaySlider.Value / 100.0));
        }

        private void MusicPlaySlider_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            IsMusicPlayerSliderDraged = true;
        }

        private void MusicPlaySlider_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            MyPlayer.ChangePosition((float)(MusicPlaySlider.Value / 100.0));
        }

        //随着滑块移动而改变数据
        private void MusicPlaySlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            UpDateSliderAndTimeMessage();
        }

        //更新滑动条和时间数据
        private void UpDateSliderAndTimeMessage()
        {
            int nowMilTime = 0;
            TimeSpan nowTime;

            nowMilTime = (int)(MyPlayer.Time.TimeInSeconds() * MusicPlaySlider.Value / 100.0);
            nowTime = new TimeSpan(0, 0, 0,nowMilTime);

            NowTimeLabel.Content = nowTime.Minutes.ToString("D2") + ":" + nowTime.Seconds.ToString("D2");
            TotalTimeLabel.Content = MyPlayer.Time.min.ToString("D2") + ":" + MyPlayer.Time.second.ToString("D2");
        }

        //设置音量值
        private void VolumeSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            //没有静音则记录值到控制对象中
            if (VolumeControl != null && !VolumeControl.IsSlience)
            {
                VolumeControl.Value = VolumeSlider.Value;
            }

            if(MyPlayer != null)
            {
                MyPlayer.SetPlayerVolume((float)VolumeSlider.Value);
            }
        }

        //------------------音乐滑动条事件-------------------------------------------------
        //---------------音乐播放暂停开始切换事件----------------------------------------
        private void PlayOrPauseMusicButton_Click(object sender, RoutedEventArgs e)
        {
            //在可暂停的情况下点击的按钮
            if (IsMusicCanPause)
            {
                //暂停音乐
                MyPlayer.MusicPause();
                //改变为课播放图标
                PlayOrPauseMusicButton_PlayIcon();
            }
            else
            {
                //继续音乐
                MyPlayer.MusicContinue();
                //改变为可暂停图标
                PlayOrPauseMusicButton_PauseIcon();
            }
        }

        private void PlayOrPauseMusicButton_PauseIcon()
        {
            //改变图标
            Image image = new Image();
            image.Source = new BitmapImage(new Uri("UIImage\\PauseMusicIcon.png", UriKind.Relative));
            PlayOrPauseMusicButton.Content = image;

            //标记为可暂停
            IsMusicCanPause = true;
        }

        private void PlayOrPauseMusicButton_PlayIcon()
        {
            //改变图标
            Image image = new Image();
            image.Source = new BitmapImage(new Uri("UIImage\\PlayMusicIcon.png", UriKind.Relative));
            PlayOrPauseMusicButton.Content = image;

            //标记为不可以暂停
            IsMusicCanPause = false;
        }

        //开始播放音乐
        public void PlayMusic(MusicContextSingle singleContext, List<MusicContextSingle> contextList)
        {
            if (singleContext.SourceType == MusicSourceType.NetMusicUri)
            {
                //如果播放的是网络流音乐而之前的音乐还没有缓冲完毕的话，直接返回不播放
                if (!NetMusicBuffingFinished)
                {
                    return;
                }
            }

            //停止之前播放的音乐
            if (MyPlayer != null)
            {
                MyPlayer.MusicStop();
            }

            //首先关闭slider功能值归零
            MusicPlaySlider.IsEnabled = false;
            MusicPlaySlider.Value = 0;

            //音乐整体上下文赋值
            MusicContexts = contextList;

            //如果是再次播放已经在播放的网络歌曲的话，则直接从本地缓存流开始播放
            if (PlayingMusicInformation == singleContext && PlayingMusicInformation.SourceType == MusicSourceType.NetMusicUri)
            {
                //设置音乐细节
                SetDetialsGird(PlayingMusicInformation);
                NetMusicPlayMessageLabel.Content = string.Empty;
                PlayLocalMusic(FileStruct.BuffNetMusicName + FileStruct.SaveSongAddString, PlayingMusicInformation.NetMusic.AlbumImagePath);
                return;
            }

            //播放本地音乐
            if (singleContext.SourceType == MusicSourceType.LocalMusicPath)
            {
                if (PlayingMusicInformation != null)
                {
                    //音乐被切换
                    PlayingMusicInformation.ChangePlay();
                }
                //更新正在播放音乐
                PlayingMusicInformation = singleContext;
                //音乐被成功播放
                PlayingMusicInformation.SuccessPlayed();

                //清空状态显示
                NetMusicPlayMessageLabel.Content = string.Empty;
                //设置音乐细节
                SetDetialsGird(PlayingMusicInformation);
                PlayLocalMusic(PlayingMusicInformation.LocalMusic.UriOrPath, PlayingMusicInformation.LocalMusic.AlbumImagePath);
            }
            else
            {
                singleContext.BeginBuff();

                //下载音乐信息
                NetMusicDownLoad downLoad = new NetMusicDownLoad(singleContext.NetMusic.Information, FileStruct.BuffNetMusicName,
                (percentage, condition) =>
                {      
                    //标志位，缓冲没有完成
                    NetMusicBuffingFinished = false;

                    //显示缓冲错误
                    if (condition == NetMusicDownLoad.DownLoadCondition.Error)
                    {
                        NetMusicPlayMessageLabel_NoUIThread("Buff Error");

                        //设置为缓冲完成
                        NetMusicBuffingFinished = true;

                        this.Dispatcher.Invoke(() =>
                        {
                            //音乐缓冲错误
                            singleContext.Error();
                        });
                        
                    }
                    //清空状态
                    else if (condition == NetMusicDownLoad.DownLoadCondition.Start)
                    {
                        NetMusicPlayMessageLabel_NoUIThread("Buffing");
                    }
                    //显示缓冲进度
                    else if (condition == NetMusicDownLoad.DownLoadCondition.Disposing)
                    {
                        NetMusicPlayMessageLabel_NoUIThread(((int)(percentage * 100)).ToString() + "%");
                    }
                    //下载完成开始播放
                    else if (condition == NetMusicDownLoad.DownLoadCondition.Finished)
                    {
                        //只有成功buff了才会切换正在播放的音乐
                        if (PlayingMusicInformation != null)
                        {
                            this.Dispatcher.Invoke(() =>
                            {
                                //音乐被切换
                                PlayingMusicInformation.ChangePlay();
                            });
                        }

                        //更新正在播放音乐
                        PlayingMusicInformation = singleContext;

                        //保存下载的图片地址
                        PlayingMusicInformation.NetMusic.SetImagePath(FileStruct.BuffNetMusicName + FileStruct.SaveAlbumImageAddString,
                            FileStruct.BuffNetMusicName + FileStruct.SaveArtistImageAddString);

                        //修改其MP3 TAG
                        MP3Information.ModifyMP3Tag(FileStruct.BuffNetMusicName + FileStruct.SaveSongAddString,
                            PlayingMusicInformation.NetMusic.Information.name , 
                                PlayingMusicInformation.NetMusic.Information.album.name,
                                    PlayingMusicInformation.NetMusic.Information.artist.name);

                        this.Dispatcher.Invoke(() =>
                        {
                            //音乐被成功缓存播放
                            PlayingMusicInformation.SuccessPlayed();
                        });


                        //设置为缓冲完成
                        NetMusicBuffingFinished = true;

                        this.Dispatcher.Invoke(() =>
                        {
                            //设置音乐细节
                            SetDetialsGird(PlayingMusicInformation);
                            NetMusicPlayMessageLabel.Content = string.Empty;
                            PlayLocalMusic(FileStruct.BuffNetMusicName + FileStruct.SaveSongAddString, PlayingMusicInformation.NetMusic.AlbumImagePath);
                        });
                    }
                });
            }


        }

        //在非UI线程下显示信息
        private void NetMusicPlayMessageLabel_NoUIThread(string message)
        {
            this.Dispatcher.Invoke(() =>
            {
                NetMusicPlayMessageLabel.Content = message;
            });
        }

        private void PlayLocalMusic(string url, string imageUrl = null)
        {
            MP3Information.InformationStruct information = MP3Information.GetMP3StringInformation(url);

            //如果没有给予图片路径
            if (imageUrl == null)
            {
                information.Images = MP3Information.GetMP3Image(url);

                //设置音乐图片,使用内部包含图片
                if (information.Images.Count != 0)
                {
                    BitmapImage image = information.Images[0];
                    image = JPGImage.ResizeImage(image, InPlayBarMusicImageWH, InPlayBarMusicImageWH);

                    if (image != null)
                    {
                        PlayingMusicImage.Source = image;
                    }
                    //无法解码图片，则设置为默认
                    else
                    {
                        PlayingMusicImage.Source = new BitmapImage(new Uri("UIImage\\AlbumImageDefaultIcon.jpg", UriKind.Relative));
                    }

                }
                //如果内部不包含封面的话
                else
                {
                    PlayingMusicImage.Source = new BitmapImage(new Uri("UIImage\\AlbumImageDefaultIcon.jpg", UriKind.Relative));
                }
            }
            //给予了图片，则设置显示
            else
            {
                //PlayingMusicImage.Source = new BitmapImage(new Uri(imageUrl, UriKind.RelativeOrAbsolute));
                //缩放图片
                BitmapImage image = JPGImage.ResizeImage(imageUrl, InPlayBarMusicImageWH, InPlayBarMusicImageWH);

                if (image != null)
                {
                    PlayingMusicImage.Source = image;
                }
                //缩放失败则设置为默认
                else
                {
                    PlayingMusicImage.Source = new BitmapImage(new Uri("UIImage\\AlbumImageDefaultIcon.jpg", UriKind.Relative));
                }
            }

            MyPlayer.PlayMP3Music(url,
                //音乐开始事件
                () =>
                {
                    MusicBeginEvent();
                },
                //音乐结束事件 , 包括自然结束和强制而结束
                (type) =>
                {
                    MusicStopEvent(type);
                },
                //音乐播放时候的事件,OK---finished
                (position) =>
                {
                    //只有当滑块没有被拖动的时候才会执行播放器更新值和message
                    //滑动的时候由value changed时间更新数据
                    if (!IsMusicPlayerSliderDraged)
                    {
                        MusicPlaySlider.Value = position * 100;
                        UpDateSliderAndTimeMessage();
                    }
                },
               (float) VolumeSlider.Value);

            //更新音量
            MyPlayer.SetPlayerVolume((float)VolumeSlider.Value);
        }

        private void MusicBeginEvent()
        {
            //当一切初始化完成之后，开启slider
            MusicPlaySlider.IsEnabled = true;
            //切换到可暂停ICON
            PlayOrPauseMusicButton_PauseIcon();
            //开启播放按钮
            PlayOrPauseMusicButton.IsEnabled = true;

            //本地歌曲且有上下文
            if (PlayingMusicInformation.SourceType == MusicSourceType.LocalMusicPath && MusicContexts != null)
            {
                //本地歌曲，开启上下移动
                LastMusicButton.IsEnabled = true;
                NextMusicButton.IsEnabled = true;
            }
            else
            {
                //网络歌曲，禁止上下移动
                LastMusicButton.IsEnabled = false;
                NextMusicButton.IsEnabled = false;
            }

        }

        private void MusicStopEvent(MP3Player.StopTypeEnum type)
        {
            //value 归零 ， slider 关闭，防止触发事件，但是音乐还没有准备好
            MusicPlaySlider.Value = 0;
            MusicPlaySlider.IsEnabled = false;
            //切换可播放按钮形态
            PlayOrPauseMusicButton_PlayIcon();
            //禁止播放按钮
            PlayOrPauseMusicButton.IsEnabled = false;

            //禁止上下文移动 ， 音乐还没有准备好
            LastMusicButton.IsEnabled = false;
            NextMusicButton.IsEnabled = false;

            //如果是自然停止且播放的是本地音乐
            if(type == MP3Player.StopTypeEnum.NormalStop && PlayingMusicInformation.SourceType == MusicSourceType.LocalMusicPath && MusicContexts != null)
            {
                int index = 0;
                Random randomIndex = new Random();

                //按照模式自动切换音乐
                switch(ModeControl.MusicMode)
                {
                    case MusicPlayModeControl.Mode.Circle:
                        if (MusicContexts != null && MusicContexts.Contains(PlayingMusicInformation))
                        {
                            int indexNow = MusicContexts.IndexOf(PlayingMusicInformation);
                            int counterTimes = 0;

                            //检查上下文是否有用
                            do
                            {
                                indexNow++;
                                counterTimes++;

                                //限制范围
                                if (indexNow > MusicContexts.Count - 1)
                                {
                                    indexNow = 0;
                                }

                                if(!CheckMusicForExist(MusicContexts[indexNow]))
                                {
                                    //通知文件丢失
                                    MainWindow.MySelf.DisplayMessage(MusicContexts[indexNow].LocalMusic.UriOrPath + " File Lost");
                                }
                                else
                                {
                                    break;
                                }
                            } while(counterTimes <= MusicContexts.Count);

                            //找遍了所有的都不存在
                            if (counterTimes > MusicContexts.Count)
                            {
                                
                            }
                            //否则则播放找到的上下文
                            else
                            {
                                PlayMusic(MusicContexts[indexNow], MusicContexts);
                            }             
                        }
                        break;

                    case MusicPlayModeControl.Mode.Random:

                        //没有任何歌曲则退出
                        if(MusicContexts.Count == 0)
                        {
                            return;
                        }

                        index = randomIndex.Next(0, MusicContexts.Count);

                        //只有存在才会播放
                        if(CheckMusicForExist(MusicContexts[index]))
                        {
                            PlayMusic(MusicContexts[index], MusicContexts);
                        }    
                        else
                        {
                            //通知文件丢失
                            MainWindow.MySelf.DisplayMessage(MusicContexts[index].LocalMusic.UriOrPath + " File Lost");
                        }           
                        break;
                }
            }
        }

        private void SetDetialsGird(MusicContextSingle single)
        {
            if (single.SourceType == MusicSourceType.LocalMusicPath)
            {
                MP3Information.InformationStruct information = MP3Information.GetInformation(single.LocalMusic.UriOrPath);
                //没有歌手图片，则使用默认图片
                if (single.LocalMusic.ArtistImagePath == null)
                {
                    DetialsAlbumImage.Source = new BitmapImage(new Uri("UIImage\\ArtistDetialsImageDefaultIcon.jpg", UriKind.Relative));
                }
                else
                {
                    BitmapImage image = null;
                    image = JPGImage.ResizeImage(single.LocalMusic.ArtistImagePath, InDetialGridMusicImageWH, InDetialGridMusicImageWH);

                    //重新设置大小失败 ， 使用默认
                    if (image == null)
                    {
                        DetialsAlbumImage.Source = new BitmapImage(new Uri("UIImage\\ArtistDetialsImageDefaultIcon.jpg", UriKind.Relative));
                    }
                    else
                    {
                        DetialsAlbumImage.Source = image;
                    }
                }

                SongTextBlock.Text = "Song : " + information.Title + "         ";
                SongArtistTextBlock.Text = "Song Artist : " + information.Artist + "        ";
                AlbumTextBlock.Text = "Album : " + information.Album + "        ";
                AlbumArtistTextBlock.Visibility = Visibility.Collapsed;
            }
            else
            {
                BitmapImage image = null;
                image = JPGImage.ResizeImage(single.NetMusic.ArtistImagePath, InDetialGridMusicImageWH, InDetialGridMusicImageWH);

                //重新设置大小失败 ， 使用默认
                if (image == null)
                {
                    DetialsAlbumImage.Source = new BitmapImage(new Uri("UIImage\\ArtistDetialsImageDefaultIcon.jpg", UriKind.Relative));
                }
                else
                {
                    DetialsAlbumImage.Source = image;
                }

                SongTextBlock.Text = "Song : " + single.NetMusic.Information.name + "       ";
                SongArtistTextBlock.Text = "Song Artist : " + single.NetMusic.Information.artist.name + "       ";
                AlbumTextBlock.Text = "Album : " + single.NetMusic.Information.album.name + "       ";
                AlbumArtistTextBlock.Visibility = Visibility.Visible;
                AlbumArtistTextBlock.Text = "Album Artist : " + single.NetMusic.Information.album.artist.name + "       ";
            }
        }

        private void VolumeButton_Click(object sender, RoutedEventArgs e)
        {
            if (VolumeControl.IsSlience)
            {
                VolumeButtonImage.Source = new BitmapImage(new Uri("UIImage\\VolumeNormalIcon.png", UriKind.Relative));
                VolumeControl.IsSlience = false;
                //使能音乐操作slider bar
                VolumeSlider.IsEnabled = true;
                //恢复音量
                VolumeSlider.Value = VolumeControl.Value;
            }
            else
            {
                VolumeButtonImage.Source = new BitmapImage(new Uri("UIImage\\VolumeZeroIcon.png", UriKind.Relative));
                VolumeControl.IsSlience = true;
                //保存静音之前音量
                VolumeControl.Value = VolumeSlider.Value;
                //禁止音量操作
                VolumeSlider.Value = 0;
                VolumeSlider.IsEnabled = false;
            }
        }
        //---------------音乐播放暂停开始切换事件----------------------------------------

        /// <summary>
        /// 程序关闭时调用
        /// </summary>
        public void SaveDataToLocal()
        {
            VolumeControl.SaveToLocal();
            ModeControl.SaveToLocal();
        }

        private void PlayModeButton_Click(object sender, RoutedEventArgs e)
        {
            //改变模式
            ModeControl.ChangeMode();
            //改变显示
            if (ModeControl.MusicMode == MusicPlayModeControl.Mode.Circle)
            {
                PlayModeButton.ToolTip = "循环播放";
                PlayModeButtonIcon.Source = new BitmapImage(new Uri("UIImage\\CirclePlayIcon.png", UriKind.Relative));
            }
            else
            {
                PlayModeButton.ToolTip = "随机播放";
                PlayModeButtonIcon.Source = new BitmapImage(new Uri("UIImage\\RandomPlayIcon.png", UriKind.Relative));
            }
        }

        //下一曲
        private void NextMusicButton_Click(object sender, RoutedEventArgs e)
        {
            if(MusicContexts != null && MusicContexts.Contains(PlayingMusicInformation))
            {
                int indexNow = MusicContexts.IndexOf(PlayingMusicInformation);
                int counterTimes = 0;

                //检查上下文是否有用
                do
                {
                    indexNow++;
                    counterTimes++;

                    //限制范围
                    if (indexNow > MusicContexts.Count - 1)
                    {
                        indexNow = 0;
                    }

                    if (!CheckMusicForExist(MusicContexts[indexNow]))
                    {
                        //通知文件丢失
                        MainWindow.MySelf.DisplayMessage(MusicContexts[indexNow].LocalMusic.UriOrPath + " File Lost");
                    }
                    else
                    {
                        break;
                    }

                } while (counterTimes <= MusicContexts.Count);

                //找遍了所有的都不存在
                if (counterTimes > MusicContexts.Count)
                {
                    return;
                }

                PlayMusic(MusicContexts[indexNow], MusicContexts);
            }
        }

        //上一曲
        private void LastMusicButton_Click(object sender, RoutedEventArgs e)
        {
            if (MusicContexts != null && MusicContexts.Contains(PlayingMusicInformation))
            {
                int indexNow = MusicContexts.IndexOf(PlayingMusicInformation);
                int counterTimes = 0;

                //检查上下文是否有用
                do
                {
                    indexNow--;
                    counterTimes++;

                    //限制范围
                    if (indexNow < 0 )
                    {
                        indexNow = MusicContexts.Count - 1;
                    }

                    if (!CheckMusicForExist(MusicContexts[indexNow]))
                    {
                        //通知文件丢失
                        MainWindow.MySelf.DisplayMessage(MusicContexts[indexNow].LocalMusic.UriOrPath + " File Lost");
                    }
                    else
                    {
                        break;
                    }

                } while (counterTimes <= MusicContexts.Count);

                //找遍了所有的都不存在
                if(counterTimes > MusicContexts.Count)
                {
                    return;
                }

                PlayMusic(MusicContexts[indexNow], MusicContexts);
            }
        }

        /// <summary>
        /// 检查该上下文文件是否存在
        /// </summary>
        /// <param name="single">要检查的上下文</param>
        /// <returns></returns>
        private bool CheckMusicForExist(MusicContextSingle single)
        {
            FileInfo check = new FileInfo(single.LocalMusic.UriOrPath);

            return check.Exists;
            
        }
    }
}
