﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NormalMusicPlayer.Sql
{
    public class NormalMusicSqlControl
    {
        /// <summary>
        /// 上传音乐图片为空的表达式
        /// </summary>
        public const string UpLoadImageNoneString = "NONE";
        /// <summary>
        /// 数据库实体
        /// </summary>
        private NormalEntities SqlEntities = null;
        //最短响应时间  30 S
        private const int MaxResponseTime = 30 * 1000;
        //最长连接时间 ， 1MIN
        private const int MaxConnectingTime = 60 * 1000;
        /// <summary>
        /// sql 数据库的连接状况
        /// </summary>
        public enum SqlConnectStateEnum
        {
            /// <summary>
            /// 正在连接
            /// </summary>
            Connecting ,
            /// <summary>
            /// 没有连接
            /// </summary>
            NotConnect ,
            /// <summary>
            /// 已连接
            /// </summary>
            Connected
        }

        /// <summary>
        /// 数据库连接状态
        /// </summary>
        private SqlConnectStateEnum _ConnectSate = SqlConnectStateEnum.NotConnect;

        /// <summary>
        /// 数据库连接状态
        /// </summary>
        public SqlConnectStateEnum ConnectSate
        {
            get
            {
                return _ConnectSate;
            }
        }

        /// <summary>
        /// 正在连接数据库执行的状态
        /// </summary>
        public enum ConnectingStateEnum
        {
            /// <summary>
            /// 成功连接
            /// </summary>
            Success ,
            /// <summary>
            /// 连接错误
            /// </summary>
            Failed 
        }

        /// <summary>
        /// 连接数据库委托代理
        /// </summary>
        /// <param name="state">连接状态</param>
        /// <param name="message">传递信息</param>
        public delegate void SqlConnectedEventDel(ConnectingStateEnum state , string message);

        public NormalMusicSqlControl(string ip , string userName , string passWords)
        {
            SqlEntities = new NormalEntities(ip, userName, passWords);
            _ConnectSate = SqlConnectStateEnum.NotConnect;
        }

        public async void ConnectToMySqlAsync(SqlConnectedEventDel del = null)
        {
            //开始连接
            _ConnectSate = SqlConnectStateEnum.Connecting; ;

            await Task.Run(() =>
            {
                try
                {
                    SqlEntities.Database.Connection.Open();
                    //成功连接
                    if (del != null)
                    {
                        del.Invoke(ConnectingStateEnum.Success, string.Empty);
                    }
                    //已连接
                    _ConnectSate = SqlConnectStateEnum.Connected;
                }
                //连接失败
                catch (Exception e)
                {
                    if (del != null)
                    {
                        del.Invoke(ConnectingStateEnum.Failed, e.Message);
                    }
                    //未连接
                    _ConnectSate = SqlConnectStateEnum.NotConnect;
                }
            });
        }

        public void ConnectToMySql()
        {
            //开始连接
            _ConnectSate = SqlConnectStateEnum.Connecting; ;

            try
            {
                SqlEntities.Database.Connection.Open();
                //已连接
                _ConnectSate = SqlConnectStateEnum.Connected;
            }
            //连接失败
            catch
            {
                //未连接
                _ConnectSate = SqlConnectStateEnum.NotConnect;
            }
        }

        /// <summary>
        /// 超找符合要求的可用的序列号
        /// <para>返回查找到的序列号，  null为没有满足要求的序列号</para>
        /// <para>可能会跑出 expection , 没有做 try catch 处理</para>
        /// </summary>
        /// <param name="lisence"></param>
        /// <returns></returns>
        public NormalMusicProgramCode CheckForLisenceCanBoUse(string lisence)
        {
            NormalMusicProgramCode findCode = SqlEntities.NormalMusicProgramCodes.First(code => code.Code == lisence && code.IsUsed == 0);
            return findCode;
        }

        /// <summary>
        /// 删除云音乐记录
        /// </summary>
        /// <param name="deleteMusic">删除音乐实体</param>
        public void DeleteCloudMusic(NormalMusicUpLoadMusic deleteMusic)
        {
            SqlEntities.NormalMusicUpLoadMusics.Remove(deleteMusic);
        }

        /// <summary>
        /// 使用机器码寻找用户资料
        /// <para>如果找到则返回对象，没有找到则返回null</para>
        /// </summary>
        /// <param name="machineCode">机器码</param>
        /// <returns></returns>
        public NormalMusicUserInformation FindUserInformationUserMachineCode(string machineCode)
        {
            List<NormalMusicUserInformation> userInformations = null;
            try
            {
                userInformations = (from user in SqlEntities.NormalMusicUserInformations where user.MachineCode == machineCode select user).ToList<NormalMusicUserInformation>();

                if(userInformations.Count >= 1)
                {
                    return userInformations[0];
                }
                else
                {
                    return null;
                }
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// 获得所有用户的信息
        /// </summary>
        /// <returns>信息集合</returns>
        public List<NormalMusicUserInformation> GetAllUserInformation()
        {
            try
            {
                List<NormalMusicUserInformation> users = (from user in SqlEntities.NormalMusicUserInformations
                                                          orderby user.Name descending select user).ToList<NormalMusicUserInformation>();

                return users;
            }
            catch
            {
                return new List<NormalMusicUserInformation>();
            }
        }

        /// <summary>
        /// 添加用户信息到表内
        /// </summary>
        /// <param name="information">用户信息</param>
        public void AddUserInformation(NormalMusicUserInformation information)
        {
            SqlEntities.NormalMusicUserInformations.Add(information);
        }

        /// <summary>
        /// 添加上传音乐文件到表中
        /// </summary>
        /// <param name="information">用户信息</param>
        public void AddUpLoadMusic(NormalMusicUpLoadMusic information)
        {
            SqlEntities.NormalMusicUpLoadMusics.Add(information);
        }

        /// <summary>
        /// 获得用户所有的上传音乐
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <returns></returns>
        public List<NormalMusicUpLoadMusic> GetUserTotalMusic(int userID)
        {
            return (from music in SqlEntities.NormalMusicUpLoadMusics
                    where music.BelongUserID == userID orderby music.ID descending
                    select music).ToList<NormalMusicUpLoadMusic>();
        }


        /// <summary>
        /// 保存改变的信息
        /// <para>如果成功保存的话返回 string.Empty ,  否则返回错误信息 </para>
        /// </summary>
        public string SaveChanges()
        {
            try
            {
                SqlEntities.SaveChanges();
                return string.Empty;
            }
            catch(Exception e)
            {
                return e.Message;
            }
        }

        /// <summary>
        /// 关闭连接
        /// </summary>
        public void CloseConnection()
        {
            if(SqlEntities != null)
            {
                SqlEntities.Dispose();
            }
        }
    }
}
