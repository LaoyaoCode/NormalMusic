﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LaoyaosMedia;
using DialogForms = System.Windows.Forms;
using System.Windows.Media.Animation;
using System.IO;
using Simple.ImageResizer;
using System.Drawing;
using LaoyaosFile;

namespace LaoyaosImage
{
    public static class JPGImage
    {
        /// <summary>
        /// 从地址中立即获取图片数据流到bitmap中，防止出现文件资源占用现象
        /// <para>返回null , 获取失败，否则则返回BitmapImage引用</para>
        /// </summary>
        /// <param name="imagePath">图片文件地址</param>
        private static BitmapImage GetBitmapImageRightNow(string imagePath)
        {
            BitmapImage bitmap = new BitmapImage();

            try
            {
                if (File.Exists(imagePath))
                {
                    bitmap.BeginInit();
                    bitmap.CacheOption = BitmapCacheOption.OnLoad;

                    using (Stream ms = new MemoryStream(File.ReadAllBytes(imagePath)))
                    {
                        bitmap.StreamSource = ms;
                        bitmap.EndInit();
                        bitmap.Freeze();
                    }
                }
            }
            catch
            {
                return null;
            }
           
            return bitmap;
        }

        //获取WPF可用的图片源
        /*
        public static BitmapFrame GetImageSource(string url)
        {
            BitmapFrame frame = null;
            try
            {
                using (System.Drawing.Bitmap bitmap = new System.Drawing.Bitmap(url))
                {
                    using (MemoryStream stream = new MemoryStream())
                    {
                        bitmap.Save(stream, bitmap.RawFormat);
                        stream.Seek(0, SeekOrigin.Begin);

                        frame = BitmapFrame.Create(stream , BitmapCreateOptions.PreservePixelFormat , BitmapCacheOption.OnLoad) ;
                        frame.Freeze();
                    }
                }
            }
            catch
            {
                return null;
            }
            return frame;
        }
        */

        /// <summary>
        /// 重新缩放图片尺寸
        /// <para>返回 null ， 错误 , 否则返回信息</para>
        /// </summary>
        /// <param name="sourceFileName">源文件路径</param>
        /// <param name="width">长度</param>
        /// <param name="height">宽度</param>
        /// <returns></returns>
        public static BitmapImage ResizeImage(string sourceFileName, int width, int height)
        {
            try
            {
                using (ImageResizer resizer = new ImageResizer(sourceFileName))
                {
                    //修剪图片符合尺寸
                    resizer.Resize(width, height, true, ImageEncoding.Jpg);
                    //保存到文件里面
                    resizer.SaveToFile(FileStruct.ScaleResultJPGImageBuffName);
                }
            }
            catch
            {
                return null;
            }

            //立刻读取图片文件流到内存中，防止出现占用资源现象
            return GetBitmapImageRightNow(FileStruct.ScaleResultJPGImageBuffName);
        }
        /*
        public static BitmapFrame ResizeImage(string sourceFileName, int width , int height)
        {
            BitmapImage image = new BitmapImage();

            try
            {
                using (ImageResizer resizer = new ImageResizer(sourceFileName))
                {
                    //修剪图片符合尺寸
                    resizer.Resize(width, height, true, ImageEncoding.Jpg);
                    //保存到文件里面
                    resizer.SaveToFile(FileStruct.ScaleResultJPGImageBuffName);
                }
            }
            catch
            {
                return null;
            }

            return GetImageSource(FileStruct.ScaleResultJPGImageBuffName);  
        }*/

        /// <summary>
        /// 重新缩放图片尺寸
        /// </summary>
        /// <para>缩放并保存成功返回 true ， 错误 , 返回 false</para>
        /// <param name="sourceFileName">源文件路径</param>
        /// <param name="saveFileName">保存文件路径</param>
        /// <param name="width">宽度</param>
        /// <param name="height">高度</param>
        /// <returns></returns>
        public static bool ResizeImage(string sourceFileName , string saveFileName  , int width , int height)
        {
            try
            {
                using (ImageResizer resizer = new ImageResizer(sourceFileName))
                {
                    //修剪图片符合尺寸
                    resizer.Resize(width, height, true, ImageEncoding.Jpg);
                    //保存到文件里面
                    resizer.SaveToFile(saveFileName);
                }

                return true;
            }
            catch
            {
                return false;
            }
        }
        /// <summary>
        /// 重新缩放图片尺寸
        /// <para>返回 null ， 错误 , 否则返回信息</para>
        /// </summary>
        /// <param name="sourceImage">源图片</param>
        /// <param name="width">长度</param>
        /// <param name="height">宽度</param>
        /// <returns></returns>
        public static BitmapImage ResizeImage(BitmapImage sourceImage, int width, int height)
        {
            BitmapEncoder encoder = new JpegBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(sourceImage));

            using (FileStream fileStream = new System.IO.FileStream(FileStruct.ScaleJPGImageBuffName, System.IO.FileMode.Create))
            {
                encoder.Save(fileStream);
            }

            return ResizeImage(FileStruct.ScaleJPGImageBuffName, width, height);
        }
        /*
        public static BitmapFrame ResizeImage(BitmapImage sourceImage , int width , int height)
        {
            BitmapEncoder encoder = new JpegBitmapEncoder();
            encoder.Frames.Add(BitmapFrame.Create(sourceImage));

            using (FileStream fileStream = new System.IO.FileStream(FileStruct.ScaleJPGImageBuffName, System.IO.FileMode.Create))
            {
                encoder.Save(fileStream);
            }

            return ResizeImage(FileStruct.ScaleJPGImageBuffName, width, height);
        }*/
    }
}
