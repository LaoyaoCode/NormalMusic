﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LaoyaosFile;
using LaoyaosProgramMessage;
using NormalMusicPlayer.Sql;

namespace NormalMusicPlayer
{
    /// <summary>
    /// DownLoadGrid.xaml 的交互逻辑
    /// </summary>
    public partial class DownLoadGrid : UserControl
    {
        private DLoadedMusicRecord DownLoadedRecords = null;
        /// <summary>
        /// 本地下载的音乐ID集合 ， 只有删除音乐或者下载音乐才能对其修改 ， 删除记录不能修改它
        /// </summary>
        public DownloadToLocalIDS DownLoadedIDS = null;

        public struct DownLoadingFTPInformation
        {
            public string SongUri;
            public string AlbumImageUri;
            public string ArtistImageUri;
            public string SaveBookPath;
        }

        public DownLoadGrid()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            DownLoadedRecords = new DLoadedMusicRecord();
            DownLoadedIDS = new DownloadToLocalIDS();
            DownloadedSingleGridControl display = null;

            //添加记录显示
            foreach (DLoadedMusicRecord.Record item in DownLoadedRecords.RecordsList)
            {
                display = new DownloadedSingleGridControl(item, DownloadedGirdDeleteDel);
                //添加显示和删除代理
                DownLoadedSPanel.Children.Add(display);
            }
        }

        //test success , 2017.5.5
        private void OpenDownLoadFolderButton_Click(object sender, RoutedEventArgs e)
        {
            System.Diagnostics.Process.Start("explorer.exe" , FileStruct.MusicDownLoadSaveBook);
        }

        /// <summary>
        /// 添加已经下载的文件记录，外部调用
        /// </summary>
        /// <param name="addRecord"></param>
        public void AddDownLoadedRecord(DLoadedMusicRecord.Record addRecord)
        {
            List<DLoadedMusicRecord.Record> records = DownLoadedRecords.RecordsList;
            DownloadedSingleGridControl display = null;

            //不包含该记录
            if (!records.Contains(addRecord))
            {
                display = new DownloadedSingleGridControl(addRecord, DownloadedGirdDeleteDel);
                //添加信息 , 最新的信息在最前面
                records.Insert(0, addRecord);
                //添加显示和删除代理 , 最新的记录显示在最上层
                DownLoadedSPanel.Children.Insert(0, display);
            }
        }

        //已下载的显示网格删除事件代理
        private void DownloadedGirdDeleteDel(DownloadedSingleGridControl sender)
        {
            //删除记录引用
            DownLoadedRecords.RecordsList.Remove(sender.MineRecord);
            //删除记录显示引用
            DownLoadedSPanel.Children.Remove(sender);
        }

        /// <summary>
        /// 下载云音乐
        /// </summary>
        /// <param name="downLoadMusic">下载音乐信息</param>
        /// <param name="bookID">保存的音乐集合ID</param>
        /// <param name="userBelongBook">属于用户的远程文件夹地址</param>
        /// <param name="success">下载成功事件代理</param>
        /// <param name="failed">下载失败事件代理</param>
        public void DownLoadCloudMusic(NormalMusicUpLoadMusic downLoadMusic , string bookID , string userBelongBook , DownLoadingSigleLineControl.DownLoadEventDel success , DownLoadingSigleLineControl.DownLoadEventDel failed)
        {
            //实例化下载控件
            DownLoadingSPanel.Children.Add(new DownLoadingSigleLineControl(downLoadMusic, bookID, userBelongBook, DownLoadingSPanel , success , failed));
        }

        /// <summary>
        /// 保存到本地
        /// </summary>
        public void SaveToLocal()
        {
            DownLoadedRecords.SaveToLocal();
            DownLoadedIDS.SaveToLocal();
        }
    }
}
