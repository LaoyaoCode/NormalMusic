﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LaoyaosProgramMessage;

namespace NormalMusicPlayer
{
    /// <summary>
    /// SelectMusicBookDialog.xaml 的交互逻辑
    /// </summary>
    public partial class SelectMusicBookDialog : Window
    {
        private string _SelectBookID = string.Empty;

        /// <summary>
        /// 选择的集合ID
        /// </summary>
        public string SelectBookID
        {
            get
            {
                return _SelectBookID;
            }
        }

        public SelectMusicBookDialog()
        {
            InitializeComponent();
        }

        public SelectMusicBookDialog(DefaultBookControl defaultBook , TotalBooksControl totalBooks)
        {
            InitializeComponent();

            //添加所有的用户创建音乐集
            foreach (MusicBook item in totalBooks.TotalBooks)
            {
                BooksDisplayPanel.Children.Add(new MusicBookControl(BookNormal_Click, item));
            }

            //添加默认音乐集
            BooksDisplayPanel.Children.Add(new MusicBookControl(BookNormal_Click, defaultBook.Default));
        }

        //单机则选择，返回true
        private void BookNormal_Click(MusicBookControl sender)
        {
            _SelectBookID = sender.Contain.ID;
            this.DialogResult = true;
        }

        //关闭了窗口，返回false
        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private void BaseTopGrid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            //move the windows
            this.DragMove();
        }
    }
}
