﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using NormalMusicPlayer.Sql;
using LaoyaosProgramMessage;
using LaoyaosFile;
using NormalFTP;
using System.IO;

namespace NormalMusicPlayer
{
    /// <summary>
    /// DownLoadingSigleLineControl.xaml 的交互逻辑
    /// </summary>
    public partial class DownLoadingSigleLineControl : UserControl
    {
        private const int MaxPrograssBarWaith = 300;
        private NormalMusicUpLoadMusic DownLoadMusic = null;
        private string MusicBookID = string.Empty;
        private string BelongBookPath = string.Empty;
        private StackPanel FatherSP = null;

        /// <summary>
        ///下载事件 , UI线程执行
        /// </summary>
        public delegate void DownLoadEventDel();

        private DownLoadEventDel SuccessDownLoadedEvent = null;
        private DownLoadEventDel FailedDownLoadedEvent = null;

        public DownLoadingSigleLineControl()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 下载云音乐
        /// </summary>
        /// <param name="downLoadMusic">下载音乐信息</param>
        /// <param name="id">保存的音乐集id</param>
        public DownLoadingSigleLineControl(NormalMusicUpLoadMusic downLoadMusic , string id ,string userBelongBookPath , StackPanel father , DownLoadEventDel success , DownLoadEventDel failed)
        {
            InitializeComponent();

            DownLoadMusic = downLoadMusic;
            MusicBookID = id;

            BelongBookPath = userBelongBookPath;
            DownLoadingSongNameLabel.Content = DownLoadMusic.MusicName;

            FatherSP = father;
            SuccessDownLoadedEvent = success;
            FailedDownLoadedEvent = failed;

            SetDownloadingBar(0);

            //开始异步下载
            DownLoadMusicAsync();
        }

        private void SetDownloadingBar(double per)
        {
            this.Dispatcher.Invoke(() =>
            {
                if(per < 0)
                {
                    per = 0;
                }

                if(per > 1)
                {
                    per = 1;
                }

                ProgressBarUp.Width = MaxPrograssBarWaith * per;
            });
        }

        private async void DownLoadMusicAsync()
        {
            Random rNumber = new Random();

            //目标音乐文件名
            string targetMusicName = FileStruct.UnityMusicName(DownLoadMusic.MusicName);

            //目标专辑图片文件名
            string targetAlbumImageName = FileStruct.MusicImageDownLoadSaveBook + "\\" +
                UnityString.UseMD5(DownLoadMusic.AlbumFileName + "Album" + DownLoadMusic.CloudMusicID +
                    rNumber.NextDouble().ToString() +
                        DateTime.Now.ToString() + targetMusicName) + ".jpg";

            //目标歌手图片文件名
            string targetArtistImageName = FileStruct.MusicImageDownLoadSaveBook + "\\" +
                UnityString.UseMD5(DownLoadMusic.ArtistFileName + "Artist" + DownLoadMusic.CloudMusicID +
                    rNumber.NextDouble().ToString() +
                        DateTime.Now.ToString() + targetMusicName) + ".jpg";

            await Task.Run(() =>
            {
                bool isTaskSuccess = false;

                if(DownLoadMusic.AlbumFileName != NormalMusicSqlControl.UpLoadImageNoneString)
                {
                    SetDownloadingBar(0);
                    //图片下载不成功则当做没有 ， 依旧进行下载
                    MainWindow.NormalFTP.DownLoadFile(targetAlbumImageName, BelongBookPath + "\\"
                        + NormalFTPFileStruct.UserImageBookName + "\\" + DownLoadMusic.AlbumFileName,
                        (state, percentage, messgae) =>
                        {
                            if (state == NormalFTPControl.FTPDisposeStateEnum.Error)
                            {
                                targetAlbumImageName = string.Empty;
                            }
                            else if (state == NormalFTPControl.FTPDisposeStateEnum.Disposing)
                            {
                                SetDownloadingBar(percentage);
                            }
                            else if (state == NormalFTPControl.FTPDisposeStateEnum.Finished)
                            {
                                SetDownloadingBar(1);
                            }
                        });
                }
                else
                {
                    targetAlbumImageName = string.Empty;
                }
                
                if(DownLoadMusic.ArtistFileName != NormalMusicSqlControl.UpLoadImageNoneString)
                {
                    SetDownloadingBar(0);
                    //图片下载不成功则当做没有 ， 依旧进行下载
                    MainWindow.NormalFTP.DownLoadFile(targetArtistImageName, BelongBookPath + "\\"
                        + NormalFTPFileStruct.UserImageBookName + "\\" + DownLoadMusic.ArtistFileName,
                        (state, percentage, messgae) =>
                        {
                            if (state == NormalFTPControl.FTPDisposeStateEnum.Error)
                            {
                                targetArtistImageName = string.Empty;
                            }
                            else if (state == NormalFTPControl.FTPDisposeStateEnum.Disposing)
                            {
                                SetDownloadingBar(percentage);
                            }
                            else if (state == NormalFTPControl.FTPDisposeStateEnum.Finished)
                            {
                                SetDownloadingBar(1);
                            }
                        });
                }
                else
                {
                    targetArtistImageName = string.Empty;
                }
                
                SetDownloadingBar(0);
                isTaskSuccess = false;
                //音乐一定要下载成功
                MainWindow.NormalFTP.DownLoadFile(targetMusicName, BelongBookPath + "\\"
                    + NormalFTPFileStruct.UserMusicBookName + "\\" + DownLoadMusic.MusicFileName,
                    (state, percentage, messgae) =>
                    {
                        if (state == NormalFTPControl.FTPDisposeStateEnum.Error)
                        {
                            
                        }
                        else if (state == NormalFTPControl.FTPDisposeStateEnum.Disposing)
                        {
                            SetDownloadingBar(percentage);
                        }
                        else if (state == NormalFTPControl.FTPDisposeStateEnum.Finished)
                        {
                            SetDownloadingBar(1);
                            isTaskSuccess = true;
                        }
                    });

                //任务没有完成，则提示错误,下载失败,并且删除已经下载的文件
                if(!isTaskSuccess)
                {
                    FileInfo deleteFile = null;

                    this.Dispatcher.Invoke(() =>
                    {
                        //下载失败事件执行
                        FailedDownLoadedEvent.Invoke();

                        FatherSP.Children.Remove(this);
                        MainWindow.MySelf.DisplayMessageNoUIThread(DownLoadMusic.MusicName + ".mp3" + "\nDwonload Failed");
                    });
                    
                    if(targetAlbumImageName != string.Empty && targetAlbumImageName != null)
                    {
                        deleteFile = new FileInfo(targetAlbumImageName);
                        if (deleteFile.Exists)
                        {
                            deleteFile.Delete();
                        }
                    }
                    
                    if(targetArtistImageName != string.Empty && targetArtistImageName != null)
                    {
                        deleteFile = new FileInfo(targetArtistImageName);
                        if (deleteFile.Exists)
                        {
                            deleteFile.Delete();
                        }
                    }
                    
                    deleteFile = new FileInfo(targetMusicName);
                    if (deleteFile.Exists)
                    {
                        deleteFile.Delete();
                    }
                }
                //下载成功
                else
                {
                    string musicBookName = string.Empty;

                    DownLoadMusic.DownloadTimes = DownLoadMusic.DownloadTimes + 1;

                    MainWindow.NormalMusicSql.SaveChanges();

                    this.Dispatcher.Invoke(() =>
                    {
                        //成功下载事件执行
                        SuccessDownLoadedEvent.Invoke();

                        BookMusicDetials music = new BookMusicDetials(targetMusicName, targetArtistImageName, targetAlbumImageName, BookMusicDetials.MusicType.DownloadMusic);
                        //添加音乐到集合内
                        musicBookName = MainWindow.MySelf.MusicBooks.AddMusicToMusicBook(MusicBookID, music);

                        //添加下载记录
                        DLoadedMusicRecord.Record record = new DLoadedMusicRecord.Record(targetMusicName, DateTime.Now, DownLoadMusic.MusicName, musicBookName);
                        record.SetCloudID(DownLoadMusic.CloudMusicID);
                        MainWindow.MySelf.DownLoad.AddDownLoadedRecord(record);

                        //添加云下载音乐IDs 和 目标音乐地址
                        MainWindow.MySelf.DownLoad.DownLoadedIDS.CloudIDS.Add(DownLoadMusic.CloudMusicID, targetMusicName);

                        FatherSP.Children.Remove(this);
                    });
                }
            });
        }
    }
}
