﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LaoyaosProgramMessage;
using LaoyaosMedia;

namespace NormalMusicPlayer
{
    /// <summary>
    /// MusicBookSingleMusicGrid.xaml 的交互逻辑
    /// </summary>
    public partial class MusicBookSingleMusicGrid : UserControl
    {
        private bool IsPlaying = false;
        private MusicPlayBarGridControl.MusicContextSingle SingleContext = null;
        private List<MusicPlayBarGridControl.MusicContextSingle> TotalContext = null;
        private MusicBookControl Father = null;

        /// <summary>
        /// 删除音乐事件代理
        /// </summary>
        /// <param name="sender"></param>
        public delegate void DeleteMusicEventDel(MusicBookSingleMusicGrid sender , MusicBookControl father);
        private DeleteMusicEventDel DeleteMusicEvent = null;

        public MusicBookSingleMusicGrid()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 需要事先验证是否能够正确获取MP3信息，获取失败则不能显示 , 保证了MP3一定存在
        /// </summary>
        /// <param name="information">音乐信息结构体</param>
        /// <param name="single">单个上下文，属于该音乐</param>
        /// <param name="total">整体上下文</param>
        /// <param name="delete">按钮删除事件委托代理</param>
        public MusicBookSingleMusicGrid(MP3Information.InformationStruct information , MusicPlayBarGridControl.MusicContextSingle single , List<MusicPlayBarGridControl.MusicContextSingle> total , DeleteMusicEventDel delete , MusicBookControl father)
        {
            InitializeComponent();
            SingleContext = single;
            TotalContext = total;
            DeleteMusicEvent = delete;
            Father = father;

            if (information.Title == string.Empty)
            {
                //设置显示
                MusicNameLabel.Content = "Music Title Lost";
            }
            else
            {
                //设置显示
                MusicNameLabel.Content = information.Title;
            }
            
            if(information.Artist == string.Empty)
            {
                //设置显示
                MusicArtistLabel.Content = "Artist Lost";
            }
            else
            {
                MusicArtistLabel.Content = information.Artist;
            }
            
            //设置事件代理
            single.SetEvent(MusicSuccessPlayed, MusicPlayingChanged, null , MusicError);

            //如果之前就已经成功播放，则再次表示为播放中
            if(single.ContextCondition == MusicPlayBarGridControl.MusicContextSingle.ContextConditionEnum.SuccessPlayed)
            {
                MusicSuccessPlayed();
            }
        }

        private void Grid_MouseEnter(object sender, MouseEventArgs e)
        {
            if(!IsPlaying)
            {
                RootGrid.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#AFB7B7B7"));
            }
        }

        private void Grid_MouseLeave(object sender, MouseEventArgs e)
        {
            if (!IsPlaying)
            {
                RootGrid.Background = null;
            }  
        }

        private void MusicSuccessPlayed()
        {
            RootGrid.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#AFB7B7B7"));
            IsPlaying = true;
            //播放状态下不能删除音乐
            DeleteButton.IsEnabled = false;
        }

        private void MusicPlayingChanged()
        {
            RootGrid.Background = null;
            IsPlaying = false;
            DeleteButton.IsEnabled = true;
        }

        private void MusicError()
        {

        }

        private void ContentControl_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            //防止多次点击
            if(!IsPlaying)
            {
                MainWindow.MySelf.MusicPlayBarGrid.PlayMusic(SingleContext, TotalContext);
            }
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            //执行外部删除事件代理
            DeleteMusicEvent.Invoke(this , Father);
        }
    }
}
