﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace NormalMusicPlayer
{
    /// <summary>
    /// ToolButton.xaml 的交互逻辑
    /// </summary>
    public partial class ToolButton : UserControl
    {
        public enum ToolButtonTypeEnum
        {
            MusicBooksPanelButton , 
            NetSearchPanelMusicButton ,
            PeoplesMusicPanelButton,
            DownLoadPanelButton ,
            UserPanelButton
        }

        private ToolButtonTypeEnum ToolButtonType;
        public delegate void ButtonClickDel(ToolButtonTypeEnum type);
        private event ButtonClickDel ButtonClickEvent;

        public ToolButton()
        {
            InitializeComponent();
            VisiualRect.Visibility = Visibility.Collapsed;
        }

        //初始化工具按钮
        public void InitToolButton(ButtonClickDel del , ToolButtonTypeEnum type)
        {
            BitmapImage image = null;

            //添加代理，分配类型
            ButtonClickEvent += del;
            ToolButtonType = type;

            //图片源赋值
            switch(ToolButtonType)
            {
                case ToolButtonTypeEnum.MusicBooksPanelButton:
                    image = new BitmapImage(new Uri("UIImage/MusicBooksPanelIcon.png", UriKind.Relative));
                    break;
                case ToolButtonTypeEnum.NetSearchPanelMusicButton:
                    image = new BitmapImage(new Uri("UIImage/SearchPanelIcon.png", UriKind.Relative));
                    break;
                case ToolButtonTypeEnum.PeoplesMusicPanelButton:
                    image = new BitmapImage(new Uri("UIImage/PeoplesMusicPanelIcon.png", UriKind.Relative));
                    break;
                case ToolButtonTypeEnum.DownLoadPanelButton:
                    image = new BitmapImage(new Uri("UIImage/DownLoadMusicPanelIcon.png", UriKind.Relative));
                    break;
                case ToolButtonTypeEnum.UserPanelButton:
                    image = new BitmapImage(new Uri("UIImage/UserPanelIcon.png", UriKind.Relative));
                    break;
            }

            ButtonImage.Source = image;
        }

        //按钮被点击事件
        public void ButtonIcon_Click(object sender, RoutedEventArgs e)
        {
            VisiualRect.Visibility = Visibility.Visible;

            if(ButtonClickEvent != null)
            {
                ButtonClickEvent.Invoke(ToolButtonType);
            }
        }

        /// <summary>
        /// 视觉矩形消失
        /// </summary>
        public void VisiualRectDisappear()
        {
            VisiualRect.Visibility = Visibility.Collapsed;
        }
    }
}
