﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Forms;
using LaoyaosImage;

namespace NormalMusicPlayer
{
    /// <summary>
    /// AddMusicBookDialog.xaml 的交互逻辑
    /// </summary>
    public partial class AddMusicBookDialog : Window
    {
        public struct ResultStruct
        {
            public string ImagePath ;
            public string Name;
        }

        public ResultStruct ResultInformation;

        private bool IsLoadImage = false;

        public AddMusicBookDialog()
        {
            InitializeComponent();
            NameTextBox.Text = string.Empty;
            MessageTextBlock.Text = string.Empty;
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private void BaseTopGrid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            //move the windows
            this.DragMove();
        }

        private void LoadImageButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();

            dialog.Title = "Select Music Book Icon Image";
            dialog.CheckFileExists = true;
            dialog.Filter = "Image Files(*.jpg;*.jpeg)|*.jpg;*.jpeg";
            //不允许选择多个
            dialog.Multiselect = false;

            if(dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                //获取图片路径
                ResultInformation.ImagePath = dialog.FileName;
                //设置已经加载图片
                IsLoadImage = true;
                //设置图片源
                BookImage.Source = JPGImage.ResizeImage(dialog.FileName, 200, 200);
            }
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            //如果没有加载图片
            if(!IsLoadImage)
            {
                MessageTextBlock.Text = "音乐集图片不能为空";
                return;
            }

            if(NameTextBox.Text == string.Empty)
            {
                MessageTextBlock.Text = "音乐集名字不能为空";
                return;
            }

            //设置信息 , 去除首尾字符空串
            ResultInformation.Name = NameTextBox.Text.Trim();
            //设置为成功选择
            this.DialogResult = true;
        }
    }
}
