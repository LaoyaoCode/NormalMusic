﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using NormalMusicPlayer.Sql;

namespace NormalMusicPlayer
{
    /// <summary>
    /// CloudPanelControl.xaml 的交互逻辑
    /// </summary>
    public partial class CloudPanelControl : UserControl
    {
        private int NowUserID = -1;
        private CloudUserLineControl ChooseLine = null;

        public CloudPanelControl()
        {
            InitializeComponent();

            LoadingGif.IsEnabled = true;
            LoadingGif.Visibility = Visibility.Visible;

            //增加用户成功登陆事件代理
            UserPanelGridControl.UserLoginInSuccessedEvent += UserSuccessLoginInEvent;
        }


        private void UserSuccessLoginInEvent(int id)
        {
            NowUserID = id;
            DisplayAllUserInformationAsync();
        }

        /// <summary>
        /// 云音乐ID被删除 ， 也就是本地被删除
        /// </summary>
        /// <param name="id"></param>
        public void CloudIDRecordDelete(string id)
        {
            foreach (UpLoadMusicLineGrid line in CloudMusicSP.Children)
            {
                if (line.CloudID == id)
                {
                    line.CloudIDRecordDeleted();
                    break;
                }
            }
        }
        /// <summary>
        /// 异步显示用户信息
        /// </summary>
        private async void DisplayAllUserInformationAsync()
        {
            UserSP.Children.Clear();

            //开启加载gif
            LoadingGif.IsEnabled = true;
            LoadingGif.Visibility = Visibility.Visible;

            await Task.Run(() =>
            {
                List<NormalMusicUserInformation> users = MainWindow.NormalMusicSql.GetAllUserInformation();
                
                //异步添加所有用户显示，除了正在使用的用户
                foreach (NormalMusicUserInformation user in users)
                {
                    if(user.ID != NowUserID)
                    {
                        this.Dispatcher.Invoke(() =>
                        {
                            UserSP.Children.Add(new CloudUserLineControl(user, LineClickEvent));
                        });
                    }                
                }

                //加载完成，隐藏加载gif
                this.Dispatcher.Invoke(() =>
                {
                    LoadingGif.IsEnabled = false;
                    LoadingGif.Visibility = Visibility.Collapsed;
                });
            });
        }

        private void LineClickEvent(CloudUserLineControl sender, NormalMusicUserInformation user)
        {
            //将之前的Line设置为没有被选择
            if (ChooseLine != null)
            {
                ChooseLine.UnChoosed();
            }
            
            //重复点击无效
            if(ChooseLine != sender)
            {
                //更新选择的线
                ChooseLine = sender;
                DisplayAllMusicInformationAsync(user);
            }
        }

        private async void DisplayAllMusicInformationAsync(NormalMusicUserInformation user)
        {
            CloudMusicSP.Children.Clear();
            //开启加载gif
            LoadingGif.IsEnabled = true;
            LoadingGif.Visibility = Visibility.Visible;

            await Task.Run(() =>
            {
                List<NormalMusicUpLoadMusic> totalMusic = MainWindow.NormalMusicSql.GetUserTotalMusic(user.ID);

                //添加所有音乐
                foreach (NormalMusicUpLoadMusic music in totalMusic)
                {
                    this.Dispatcher.Invoke(() =>
                    {
                        CloudMusicSP.Children.Add(new UpLoadMusicLineGrid(music , user , null , UpLoadMusicLineGrid.MusicBelongEnum.Others));
                    });
                }

                //加载完成，隐藏加载gif
                this.Dispatcher.Invoke(() =>
                {
                    LoadingGif.IsEnabled = false;
                    LoadingGif.Visibility = Visibility.Collapsed;
                });
            });
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {

        }

        private void RefreshUserInformationButton_Click(object sender, RoutedEventArgs e)
        {
            //去除所有音乐信息显示
            CloudMusicSP.Children.Clear();
            //异步显示用户信息
            DisplayAllUserInformationAsync();
        }
    }
}
