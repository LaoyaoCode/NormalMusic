﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using DislogBox = System.Windows.Forms;
using System.Management;
using LaoyaosProgramMessage;
using LaoyaosImage;
using System.Windows.Media.Animation;
using LaoyaosMedia;
using NormalMusicPlayer.Sql;
using LaoyaosFile;
using System.IO;
using NormalFTP;
using System.Threading;

namespace NormalMusicPlayer
{
    /// <summary>
    /// UserPanelGridControl.xaml 的交互逻辑
    /// </summary>
    public partial class UserPanelGridControl : UserControl
    {
        public delegate void UserLoginInSuccessedEventDel(int userID);
        /// <summary>
        /// 用户成功登陆事件
        /// </summary>
        public static event UserLoginInSuccessedEventDel UserLoginInSuccessedEvent;

        //CPU序列号是否已经获得
        private bool IsCPUSerialNumberGetted = false;
        //用户是否成功登陆
        private bool _IsUserSuccessedLoginIn = false;

        private string CPUSerialNumber = string.Empty;
        private LisenceControl Lisence = null;
        private UserLoginInControlClass UserLoginInControl = null;
        
        private NormalMusicUserInformation UserInformation = null;

        /// <summary>
        /// 用户登录控制类
        /// </summary>
        private class UserLoginInControlClass
        {
            /// <summary>
            /// 图片是否被选择
            /// </summary>
            public bool IsImageSelected = false;
            /// <summary>
            /// 要上传的图片地址
            /// </summary>
            public string ImagePath = string.Empty;
        }
        /// <summary>
        /// 上传的用户图标文件大小
        /// </summary>
        private const int UpLoadUserIconWH = 300;

        /// <summary>
        /// 现实的用户图标大小
        /// </summary>
        private const int DisplayUserIconWH = 200;

        public UserPanelGridControl()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            //异步获取CPU信息
            GetCPUInformationAsync();
            //清空登陆错误显示
            LoginInErrorMessageTBlock.Text = string.Empty;
            //获取序列号等机密信息
            Lisence = new LisenceControl(MainWindow.MySelf.HideSurpriseTBlock.Text);
            //登录加载UI消失
            LoginIningUIDisappear();
            //关闭激活UI的显示
            UserLoginInOrActiveGrid.Visibility = Visibility.Collapsed;
            //收起登录动画
            LoginIningGifImage.Visibility = Visibility.Collapsed;
            //收起上传按钮
            UpLoadMusicButton.Visibility = Visibility.Collapsed;
            //隐藏上传音乐显示grid
            UserUpLoadMusicGird.Visibility = Visibility.Collapsed;

            //去除功能
            UpLoadMusicButton.IsEnabled = false;

            //如果lisence 存在则更新UI
            if (Lisence.PCode != string.Empty)
            {
                LisenceTBlock.Text = "Lisence : " + Lisence.PCode;
                //开始登录中动画
                LoginIningGifImage.Visibility = Visibility.Visible;
                //异步登录
                LoginInAsync() ;
            }
            //不存在则显示登陆界面提示用户登录激活
            else
            {
                //显示激活UI
                UserLoginInOrActiveGrid.Visibility = Visibility.Visible;
                //用户登录控制体实例化
                UserLoginInControl = new UserLoginInControlClass();
            }
        }

        private void LoadImageButton_Click(object sender, RoutedEventArgs e)
        {
            DislogBox.OpenFileDialog dialog = new DislogBox.OpenFileDialog();

            dialog.Title = "Select Music Book Icon Image";
            dialog.CheckFileExists = true;
            dialog.Filter = "Image Files(*.jpg;*.jpeg)|*.jpg;*.jpeg";
            //不允许选择多个
            dialog.Multiselect = false;

            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                //获取源图片路径
                UserLoginInControl.ImagePath = dialog.FileName;
                //设置已经加载图片
                UserLoginInControl.IsImageSelected = true;
                //设置图片源
                BookImage.Source = JPGImage.ResizeImage(dialog.FileName, 200, 200);
            }
        }

        //异步获得CPU信息
        private async void GetCPUInformationAsync()
        {
            await Task.Run(() =>
            {
                //获取CPU信息
                CPUSerialNumber = GetCpuSerialNumber().Trim();
                //更新UI
                this.Dispatcher.Invoke(() =>
                {
                    CPUSerialNumberTBlock.Text = "CPU SN : " + CPUSerialNumber;

                    //如果序列号存在的话 ， 则开始登录
                    if(Lisence.PCode != string.Empty)
                    {

                    }
                });
                //设置为CPU序列号已经获取
                IsCPUSerialNumberGetted = true;
            });
        }

        private void LoginInButton_Click(object sender, RoutedEventArgs e)
        {
            int checkNet = 0;

            if(!UserLoginInControl.IsImageSelected)
            {
                LoginInErrorMessageTBlock.Text = "用户图标不能为空";
                return;
            }

            if(LoginInNameTextBox.Text.Trim() == string.Empty)
            {
                LoginInErrorMessageTBlock.Text = "用户名不能为空";
                return;
            }

            if (LoginInLisenceTextBox.Text.Trim() == string.Empty)
            {
                LoginInErrorMessageTBlock.Text = "序列号不能为空";
                return;
            }

            if(LoginInLisenceTextBox.Text.Trim().Length != 32)
            {
                LoginInErrorMessageTBlock.Text = "序列号长度必须为32";
                return;
            }

            if(!IsCPUSerialNumberGetted)
            {
                MainWindow.MySelf.DisplayMessage("请等待CPU序列号读取完毕");
                return;
            }

            //检查网络连接是否正常 , 如果不正常则提示网络连接有问题
            if (!NetMusicWeb.InternetGetConnectedState(ref checkNet, 0))
            {
                MainWindow.MySelf.DisplayMessage("无法连接到网络");
                return;
            }

            if(MainWindow.NormalMusicSql.ConnectSate == NormalMusicSqlControl.SqlConnectStateEnum.Connecting)
            {
                MainWindow.MySelf.DisplayMessage("数据库正在连接\n请等待连接完毕");
                return;
            }

            //如果数据库没有连接，则开始连接数据库
            if (MainWindow.NormalMusicSql.ConnectSate == NormalMusicSqlControl.SqlConnectStateEnum.NotConnect)
            {
                MainWindow.NormalMusicSql.ConnectToMySqlAsync((condition, message) =>
                {
                    this.Dispatcher.Invoke(() =>
                    {
                        switch (condition)
                        {
                            case NormalMusicSqlControl.ConnectingStateEnum.Success:
                                MainWindow.MySelf.DisplayMessage("成功连接到数据库 : Normal");
                                break;
                            case NormalMusicSqlControl.ConnectingStateEnum.Failed:
                                MainWindow.MySelf.DisplayMessage("连接数据库 : Normal 失败");
                                break;
                        }
                    });
                });

                MainWindow.MySelf.DisplayMessage("数据库正在连接\n请等待连接完毕");

                return;
            }

            //登录加载UI出现
            LoginIningUIAppear();

            //隐藏登录按钮
            LoginInButton.Visibility = Visibility.Collapsed;
            //静止参数被修改
            LoginInSelectImageGird.IsEnabled = false;
            LoginInNameTextBox.IsEnabled = false;
            LoginInLisenceTextBox.IsEnabled = false;

            LoginInErrorMessageTBlock.Text = string.Empty;

            //异步注册
            NewUserLoginInAsync(LoginInNameTextBox.Text.Trim(), LoginInLisenceTextBox.Text.Trim(), UserLoginInControl.ImagePath);
        }

        public void LoginIningUIDisappear()
        {
            //隐藏下载loading界面
            LoginIningAnimatioGrid.Visibility = Visibility.Collapsed;
            //禁止下载界面
            LoginIningAnimatioGrid.IsEnabled = false;
        }

        public void LoginIningUIAppear()
        {
            Storyboard story = (Storyboard)Resources["LoginIningAnimation"];

            //隐藏下载loading界面
            LoginIningAnimatioGrid.Visibility = Visibility.Visible;
            //禁止下载界面
            LoginIningAnimatioGrid.IsEnabled = true;
            story.Begin();

        }

        ///   <summary> 
        ///   获取cpu序列号     
        ///   <para>耗费时间较长 ， 建议异步进行</para>
        ///   </summary> 
        ///   <returns> 序列号 </returns> 
        private static string GetCpuSerialNumber()
        {
            string cpuInfo = "";
            try
            {
                using (ManagementClass cimobject = new ManagementClass("Win32_Processor"))
                {
                    ManagementObjectCollection moc = cimobject.GetInstances();

                    foreach (ManagementObject mo in moc)
                    {
                        cpuInfo = mo.Properties["ProcessorId"].Value.ToString();
                        mo.Dispose();
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return cpuInfo.ToString();
        }

        //异步注册 , 成功
        private async void NewUserLoginInAsync(string userName , string lisence , string sourceImagePath)
        {
            FileInfo deleteBuffImage = null;
            //上传图片缓存地址
            StringBuilder upLoadImagePath = null;
            StringBuilder hashEnter = null;

            //是否成功激活
            bool isSuccessActive = false;

            await Task.Run(() =>
            {
                upLoadImagePath = new StringBuilder();
                hashEnter = new StringBuilder();

                Random number = new Random();
                NormalMusicProgramCode matchProgramCode = null;
                bool taskDisposeSuccess = false;
                string errorMessage = string.Empty;

                upLoadImagePath.Append(FileStruct.BuffUpLoadBookName);
                upLoadImagePath.Append("\\");

                hashEnter.Append(sourceImagePath);
                hashEnter.Append(userName);
                hashEnter.Append(lisence);
                hashEnter.Append(DateTime.Now.ToString());
                hashEnter.Append(number.NextDouble());

                upLoadImagePath.Append(UnityString.UseMD5(hashEnter.ToString()));
                upLoadImagePath.Append(".jpg");
                
                //生成上传图片本地缓存地址
                /*
                upLoadImagePath = FileStruct.BuffUpLoadBookName + "\\" +
                    UnityString.UseMD5(sourceImagePath + userName + lisence + DateTime.Now.ToString() + number.NextDouble())
                        + ".jpg";*/

                if (!JPGImage.ResizeImage(sourceImagePath, upLoadImagePath.ToString(), UpLoadUserIconWH, UpLoadUserIconWH))
                {
                    MainWindow.MySelf.DisplayMessageNoUIThread(sourceImagePath + " 丢失或者不符合要求");
                    return;
                }

                try
                {
                    matchProgramCode = MainWindow.NormalMusicSql.CheckForLisenceCanBoUse(lisence);

                    if (matchProgramCode == null)
                    {
                        MainWindow.MySelf.DisplayMessageNoUIThread("序列号不可用或已被使用");
                        return;
                    }
                    else
                    {
                        MainWindow.MySelf.DisplayMessageNoUIThread("序列号有效");
                    }
                }
                catch
                {
                    MainWindow.MySelf.DisplayMessageNoUIThread("序列号不可用或已被使用");
                    return;
                }

                //已经成功获取了有效的序列号

                //生成机器码
                string machineCode = UnityString.UseMD5(CPUSerialNumber + lisence);

                hashEnter.Clear();
                hashEnter.Append(machineCode);
                hashEnter.Append(matchProgramCode.Code);
                hashEnter.Append(matchProgramCode.ID);
                hashEnter.Append(number.NextDouble());

                //生成属于用户的文件夹路径
                //string belongBookPath = NormalFTPFileStruct.RootBookName + "\\" + UnityString.UseMD5(machineCode + matchProgramCode.Code + matchProgramCode.ID + number.NextDouble());
                string belongBookPath = NormalFTPFileStruct.RootBookName + "\\" + UnityString.UseMD5(hashEnter.ToString());
                //刷新变量
                taskDisposeSuccess = false;
                //ftp 创建用户根文件夹
                MainWindow.NormalFTP.CreateBook(belongBookPath, (state, percentage, messgae) =>
               {
                   //如果创建错误，返回错误信息
                   if (state == NormalFTPControl.FTPDisposeStateEnum.Error)
                   {
                       //返回信息里面有550则代表文件夹已经存在了
                       if(messgae.Contains("550"))
                       {
                           taskDisposeSuccess = true;
                       }
                       else
                       {
                           taskDisposeSuccess = false;
                           MainWindow.MySelf.DisplayMessageNoUIThread(messgae);
                       }
                   }

                   if (state == NormalFTPControl.FTPDisposeStateEnum.Finished)
                   {
                       taskDisposeSuccess = true;
                   }
               });
                //没有成功则返回
                if (!taskDisposeSuccess)
                {
                    return;
                }

                //刷新变量
                taskDisposeSuccess = false;
                //ftp 创建用户图片文件夹
                MainWindow.NormalFTP.CreateBook(belongBookPath + "\\" + NormalFTPFileStruct.UserImageBookName, (state, percentage, messgae) =>
                {
                //如果创建错误，返回错误信息
                if (state == NormalFTPControl.FTPDisposeStateEnum.Error)
                    {
                        //返回信息里面有550则代表文件夹已经存在了
                        if (messgae.Contains("550"))
                        {
                            taskDisposeSuccess = true;
                        }
                        else
                        {
                            taskDisposeSuccess = false;
                            MainWindow.MySelf.DisplayMessageNoUIThread(messgae);
                        }
                    }

                    if (state == NormalFTPControl.FTPDisposeStateEnum.Finished)
                    {
                        taskDisposeSuccess = true;
                    }
                });
                //没有成功则返回
                if (!taskDisposeSuccess)
                {
                    return;
                }

                //刷新变量
                taskDisposeSuccess = false;
                //ftp 创建用户音乐文件夹
                MainWindow.NormalFTP.CreateBook(belongBookPath + "\\" + NormalFTPFileStruct.UserMusicBookName, (state, percentage, messgae) =>
                {
                    //如果创建错误，返回错误信息
                    if (state == NormalFTPControl.FTPDisposeStateEnum.Error)
                    {
                        //返回信息里面有550则代表文件夹已经存在了
                        if (messgae.Contains("550"))
                        {
                            taskDisposeSuccess = true;
                        }
                        else
                        {
                            taskDisposeSuccess = false;
                            MainWindow.MySelf.DisplayMessageNoUIThread(messgae);
                        }
                    }

                    if (state == NormalFTPControl.FTPDisposeStateEnum.Finished)
                    {
                        taskDisposeSuccess = true;
                    }
                });
                //没有成功则返回
                if (!taskDisposeSuccess)
                {
                    return;
                }

                //刷新变量
                taskDisposeSuccess = false;
                //ftp 上传用户图标文件
                MainWindow.NormalFTP.UploadFile(upLoadImagePath.ToString() , belongBookPath + "\\" + NormalFTPFileStruct.UserIconName , (state, percentage, messgae) =>
                {
                    //如果创建错误，返回错误信息
                    if (state == NormalFTPControl.FTPDisposeStateEnum.Error)
                    {
                        taskDisposeSuccess = false;
                        MainWindow.MySelf.DisplayMessageNoUIThread(messgae);
                    }

                    if (state == NormalFTPControl.FTPDisposeStateEnum.Finished)
                    {
                        taskDisposeSuccess = true;
                    }
                });
                //没有成功则返回
                if (!taskDisposeSuccess)
                {
                    return;
                }

                //ftp 文件结构以及图标都完成

                //创建用户信息
                NormalMusicUserInformation userInformation = new NormalMusicUserInformation();
                userInformation.MachineCode = machineCode;
                userInformation.MatchProgramCodeID = matchProgramCode.ID.ToString();
                userInformation.BelongBookPath = belongBookPath;
                userInformation.Name = userName;

                //标记为该序列号已经被使用了
                matchProgramCode.IsUsed = 1;

                //添加用户信息
                MainWindow.NormalMusicSql.AddUserInformation(userInformation);

                //保存修改的信息到表内
                errorMessage = MainWindow.NormalMusicSql.SaveChanges();
                if (errorMessage == string.Empty)
                {
                    //保存秘钥
                    Lisence.PCode = lisence;
                    //标记为用户注册成功
                    isSuccessActive = true;

                    MainWindow.MySelf.DisplayMessageNoUIThread("用户注册成功");
                }
                else
                {
                    MainWindow.MySelf.DisplayMessageNoUIThread("注册失败\n" + errorMessage);
                    return;
                }
            }) ;


            //最后删除缓存图片
            deleteBuffImage = new FileInfo(upLoadImagePath.ToString());
            if(deleteBuffImage.Exists)
            {
                deleteBuffImage.Delete();
            }
            
            //如果成功激活则开始登录
            //test success
            if(isSuccessActive)
            {
                this.Dispatcher.Invoke(() =>
                {
                    //关闭激活UI的显示
                    UserLoginInOrActiveGrid.Visibility = Visibility.Collapsed;
                    
                    LisenceTBlock.Text = "Lisence : " + Lisence.PCode;
                    //开始登录中动画
                    LoginIningGifImage.Visibility = Visibility.Visible;

                });

                //异步登录
                LoginInAsync();
            }

            //test success
            this.Dispatcher.Invoke(() =>
            {
                //开启登录按钮
                LoginInButton.Visibility = Visibility.Visible;
                //使能参数修改
                LoginInSelectImageGird.IsEnabled = true;
                LoginInNameTextBox.IsEnabled = true;
                LoginInLisenceTextBox.IsEnabled = true;
                //加载条消失
                LoginIningUIDisappear();
            });
        }

        private async void LoginInAsync()
        {
            await Task.Run(() =>
            {

                int checkNet = 0;
                //计算机器唯一识别码
                string machineCode = null;

                //检查网络连接是否正常 , 如果不正常则停止线程0.5S再检测
                while (!NetMusicWeb.InternetGetConnectedState(ref checkNet, 0))
                {
                    Thread.Sleep(500);
                }

                //等待CPU 序列号读取完成
                while(!IsCPUSerialNumberGetted)
                {
                    Thread.Sleep(500);
                }

                machineCode = UnityString.UseMD5(CPUSerialNumber + Lisence.PCode);

                //如果正在连接，则等待连接完成
                if (MainWindow.NormalMusicSql.ConnectSate == NormalMusicSqlControl.SqlConnectStateEnum.Connecting)
                {
                    while(MainWindow.NormalMusicSql.ConnectSate != NormalMusicSqlControl.SqlConnectStateEnum.Connected)
                    {
                        //正在连接则等待
                        if(MainWindow.NormalMusicSql.ConnectSate == NormalMusicSqlControl.SqlConnectStateEnum.Connecting)
                        {
                            Thread.Sleep(500);
                        }
                        //如果数据库没有连接，则开始连接数据库
                        else if (MainWindow.NormalMusicSql.ConnectSate == NormalMusicSqlControl.SqlConnectStateEnum.NotConnect)
                        {
                            //一直连接数据库直到连接成功
                            do
                            {
                                //同步方式连接数据库
                                MainWindow.NormalMusicSql.ConnectToMySql();
                            } while (MainWindow.NormalMusicSql.ConnectSate != NormalMusicSqlControl.SqlConnectStateEnum.Connected);

                            MainWindow.MySelf.DisplayMessageNoUIThread("成功连接到数据库: Normal");
                        }
                    }
                }

                //如果数据库没有连接，则开始连接数据库
                if (MainWindow.NormalMusicSql.ConnectSate == NormalMusicSqlControl.SqlConnectStateEnum.NotConnect)
                {
                    //一直连接数据库直到连接成功
                    do
                    {
                        //同步方式连接数据库
                        MainWindow.NormalMusicSql.ConnectToMySql();
                    } while (MainWindow.NormalMusicSql.ConnectSate != NormalMusicSqlControl.SqlConnectStateEnum.Connected);

                    MainWindow.MySelf.DisplayMessageNoUIThread("成功连接到数据库: Normal");
                }

                //连接数据库成功
                //寻找用户资料
                UserInformation = MainWindow.NormalMusicSql.FindUserInformationUserMachineCode(machineCode);

                if(UserInformation == null)
                {
                    //测试成功
                    this.Dispatcher.Invoke(() =>
                    {
                        //显示激活UI
                        UserLoginInOrActiveGrid.Visibility = Visibility.Visible;
                        //用户登录控制体实例化
                        UserLoginInControl = new UserLoginInControlClass();
                        //收起登录动画
                        LoginIningGifImage.Visibility = Visibility.Collapsed;
                        //提示重新激活
                        MainWindow.MySelf.DisplayMessage("用户序列号不可用\n请重新激活");
                        //隐藏正常登陆信息显示grid

                    });
                    return; 
                }

                //成功获取用户信息
                //标识用户成功登陆
                _IsUserSuccessedLoginIn = true;

                //调用用户登陆成功事件
                this.Dispatcher.Invoke(() =>
                {
                    if(UserLoginInSuccessedEvent != null)
                    {
                        UserLoginInSuccessedEvent.Invoke(UserInformation.ID);
                    }
                });
                
                //显示登陆成功
                MainWindow.MySelf.DisplayMessageNoUIThread("登录成功\n" + "Welcome : " + UserInformation.Name);

                //显示用户名
                this.Dispatcher.Invoke(() =>
                {
                    UserNameTBlock.Text = UserInformation.Name;
                });

                //同步下载用户图片
                MainWindow.NormalFTP.DownLoadFile(FileStruct.UserCloudIconFileName, UserInformation.BelongBookPath + "\\" + NormalFTPFileStruct.UserIconName, (state, percentage, messgae) =>
                {
                    //如果创建错误，返回错误信息
                    if (state == NormalFTPControl.FTPDisposeStateEnum.Error)
                    {
                        //标记为用户文件没有获得
                        //IsUserIconGetted = false;
                        //返回信息里面有550则代表文件不存在
                        if (messgae.Contains("550"))
                        {
                            MainWindow.MySelf.DisplayMessageNoUIThread("用户图标文件丢失");
                        }
                        else
                        {
                            MainWindow.MySelf.DisplayMessageNoUIThread(messgae);
                        }
                    }

                    if (state == NormalFTPControl.FTPDisposeStateEnum.Finished)
                    {
                        //标记为用户文件已经获得
                        //IsUserIconGetted = true;
                        this.Dispatcher.Invoke(() =>
                        {
                            //显示用户图标
                            UserImage.ImageSource = JPGImage.ResizeImage(FileStruct.UserCloudIconFileName, DisplayUserIconWH, DisplayUserIconWH);
                        });
                    }
                });

                //获取用户上传的音乐信息
                List<NormalMusicUpLoadMusic> totalMusic = MainWindow.NormalMusicSql.GetUserTotalMusic(UserInformation.ID);

                //添加用户上传音乐显示
                foreach (NormalMusicUpLoadMusic music in totalMusic)
                {
                    this.Dispatcher.Invoke(() =>
                    {
                        UpLoadSP.Children.Add(new UpLoadMusicLineGrid(music , UserInformation , UpLoadMusicDeleteDispose , UpLoadMusicLineGrid.MusicBelongEnum.Mine));
                    });
                }

                //停止登陆动画
                this.Dispatcher.Invoke(() =>
                {
                    //开始登录中动画
                    LoginIningGifImage.Visibility = Visibility.Collapsed;
                    //显示上传按钮
                    UpLoadMusicButton.Visibility = Visibility.Visible;
                    //开启功能
                    UpLoadMusicButton.IsEnabled = true;

                    //显示上传音乐显示grid
                    UserUpLoadMusicGird.Visibility = Visibility.Visible;
                });

            });
        }

        public void SaveToLocal()
        {
            //加密保存到本地
            Lisence.SaveToLocal(MainWindow.MySelf.HideSurpriseTBlock.Text);
        }

        private void UpLoadMusicButton_Click(object sender, RoutedEventArgs e)
        {
            UpLoadMusicDialog dialog = new UpLoadMusicDialog();

            //如果成功选择则开始上传
            if(dialog.ShowDialog().Value)
            {
                UpLoadMusicLineGrid line = new UpLoadMusicLineGrid(dialog.MusicPath, dialog.AlbumImagePath, dialog.ArtistImagePath,
                    dialog.MusicTitle, dialog.Artist, dialog.Comment, UserInformation , UpLoadMusicDeleteDispose , UpLoadingMusicFailedDispose , UpLoadMusicLineGrid.MusicBelongEnum.Mine);

                UpLoadSP.Children.Insert(0, line);
            }
        }

        //云音乐删除事件代理
        private void UpLoadMusicDeleteDispose(UpLoadMusicLineGrid sender , NormalMusicUpLoadMusic music)
        {
            UpLoadMusicDeleteAsync(sender, music);
        }

        //异步删除云音乐
        private async void UpLoadMusicDeleteAsync(UpLoadMusicLineGrid sender, NormalMusicUpLoadMusic music)
        {
            //禁止再操作该行
            sender.IsEnabled = false;

            await Task.Run(() =>
            {
                string result = string.Empty;

                //删除记录
                MainWindow.NormalMusicSql.DeleteCloudMusic(music);
                //保存到远程数据库
                result = MainWindow.NormalMusicSql.SaveChanges();

                //有错误则无法删除
                if(result != string.Empty)
                {
                    //再次使能该行
                    this.Dispatcher.Invoke(() =>
                    {
                        sender.IsEnabled = true;
                    });
                    MainWindow.MySelf.DisplayMessageNoUIThread(music.MusicName + "\nDelete Failed");
                    return;
                }
                //只要在数据库中成功删除则代表着已经删除了
                else
                {
                    //直接删除改行
                    this.Dispatcher.Invoke(() =>
                    {
                        UpLoadSP.Children.Remove(sender);
                    });
                    MainWindow.MySelf.DisplayMessageNoUIThread(music.MusicName + "\nDelete Success");
                }

                //开始在远程FTP删除 , 无论是否成功 ， 只要sql删除成功就算成功
                if (music.AlbumFileName != NormalMusicSqlControl.UpLoadImageNoneString)
                {
                    MainWindow.NormalFTP.DeleteFile(UserInformation.BelongBookPath + "\\"
                        + NormalFTPFileStruct.UserImageBookName + "\\" + music.AlbumFileName,
                        null);
                }

                if (music.ArtistFileName != NormalMusicSqlControl.UpLoadImageNoneString)
                {
                    MainWindow.NormalFTP.DeleteFile(UserInformation.BelongBookPath + "\\"
                        + NormalFTPFileStruct.UserImageBookName + "\\" + music.ArtistFileName,
                        null);
                }

                MainWindow.NormalFTP.DeleteFile(UserInformation.BelongBookPath + "\\"
                        + NormalFTPFileStruct.UserMusicBookName + "\\" + music.MusicFileName,
                        null);
            });
        }

        //云音乐上传失败代理
        private void UpLoadingMusicFailedDispose(UpLoadMusicLineGrid sender)
        {
            UpLoadSP.Children.Remove(sender);
        }

        /// <summary>
        /// 云音乐ID被删除 ， 也就是本地被删除
        /// </summary>
        /// <param name="id"></param>
        public void CloudIDRecordDelete(string id)
        {
            foreach (UpLoadMusicLineGrid line in UpLoadSP.Children)
            {
                if(line.CloudID == id)
                {
                    line.CloudIDRecordDeleted();
                    break;
                }
            }
        }

    }
}
