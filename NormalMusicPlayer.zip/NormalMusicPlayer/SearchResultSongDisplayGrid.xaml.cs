﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LaoyaosMedia;
using System.IO;
using LaoyaosFile;
using LaoyaosProgramMessage;

namespace NormalMusicPlayer
{
    /// <summary>
    /// SearchResultSongDisplayGrid.xaml 的交互逻辑
    /// </summary>
    public partial class SearchResultSongDisplayGrid : UserControl
    {
        //属于自己的单个上下文
        private MusicPlayBarGridControl.MusicContextSingle MineSingleContext = null;
        //属于的全局上下文
        //private List<MusicPlayBarGridControl.MusicContextSingle> TotalContext = null;
        //是否被双击
        private bool IsDoubleClicked = false;
        /// <summary>
        /// 双击事件委托
        /// </summary>
        /// <param name="sender">发送者</param>
        public delegate void DoubleClickEventDel(SearchResultSongDisplayGrid sender);

        private DoubleClickEventDel DoubleClickEvent;

        public SearchResultSongDisplayGrid(MusicPlayBarGridControl.MusicContextSingle single/* , List<MusicPlayBarGridControl.MusicContextSingle> total*/ , DoubleClickEventDel del)
        {
            InitializeComponent();

            //检查参数是否合格
            if(single.SourceType != MusicPlayBarGridControl.MusicSourceType.NetMusicUri)
            {
                throw new Exception("Net Search Context Must Be Set To Net Music Type");
            }

            //隐藏正在播放图标
            IsPlayingIcon.Visibility = Visibility.Collapsed;
            //添加委托
            DoubleClickEvent += del;

            //如果该网易云歌曲已经下载到了本地的话 , 作为本地音乐播放
            if (MainWindow.MySelf.DownLoad.DownLoadedIDS.NetIDS.ContainsKey(single.NetMusic.Information.id))
            {
                MineSingleContext = new MusicPlayBarGridControl.MusicContextSingle((new MusicPlayBarGridControl.LocalMusicInformation(MainWindow.MySelf.DownLoad.DownLoadedIDS.NetIDS[single.NetMusic.Information.id])));
            }
            else
            {
                MineSingleContext = single;
            }
            //设置代理事件
            MineSingleContext.SetEvent(MusicSuccessPlayed, MusicChange, MusicBeginBuff , MusicError);
            //TotalContext = total;
            //隐藏下载按钮
            DownLoadButton.Visibility = Visibility.Collapsed;
            //更新值
            UpdataMessage(single);
        }
        
        //音乐被成功选择并播放
        private void MusicSuccessPlayed()
        {
            //显示正在播放图标
            IsPlayingIcon.Visibility = Visibility.Visible;

            MainWindow.MySelf.SearchMusic.LoadingUIDisappear();

            //只有不是本地的才会有下载按钮
            if (MineSingleContext.SourceType == MusicPlayBarGridControl.MusicSourceType.NetMusicUri)
            {
                //成功缓冲才会有显示下载按钮
                DownLoadButton.Visibility = Visibility.Visible;
            }

            //只有当成功播放的时候才会双击执行委托事件
            DoubleClickEvent.Invoke(this);
        }

        private void MusicChange()
        {
            //隐藏正在播放图标
            IsPlayingIcon.Visibility = Visibility.Collapsed;
            //隐藏下载按钮
            DownLoadButton.Visibility = Visibility.Collapsed;
        }

        //发生错误，则恢复没预选中状态
        private void MusicError()
        {
            UnChoosed();

            MainWindow.MySelf.SearchMusic.LoadingUIDisappear();
        }

        private void MusicBeginBuff()
        {
            IsDoubleClicked = true;
            //设置背景色
            BaseRectangle.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#4C6C6C6C"));

            MainWindow.MySelf.SearchMusic.LoadingUIAppear();
        }

        //更新信息
        private void UpdataMessage(MusicPlayBarGridControl.MusicContextSingle single)
        {
            SongNameTextBlock.Text = single.NetMusic.Information.name;
            SongArtistTextBlock.Text = single.NetMusic.Information.artist.name;
        }

        private void RootGrid_MouseEnter(object sender, MouseEventArgs e)
        {
            if (!IsDoubleClicked)
            {
                BaseRectangle.Fill = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#4C6C6C6C"));
            }              
        }

        private void RootGrid_MouseLeave(object sender, MouseEventArgs e)
        {
            if(!IsDoubleClicked)
            {
                BaseRectangle.Fill = null;
            }
        }

        //双击则播放音乐
        private void ContentControl_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            //缓冲音乐
            MainWindow.MySelf.MusicPlayBarGrid.PlayMusic(MineSingleContext, null);
        }

        //设置为没有被选择
        public void UnChoosed()
        {
            IsDoubleClicked = false;
            BaseRectangle.Fill = null;
        }

        private void DownLoadButton_Click(object sender, RoutedEventArgs e)
        {
            string id = string.Empty;
            id = MainWindow.MySelf.MusicBooks.SelectMusicBook_OutsideUse();

            //如果取得了ID的话 ， 也就是选择了文件夹
            if(id != string.Empty)
            {
                string bookName = string.Empty;
                FileInfo musicFile = new FileInfo(FileStruct.BuffNetMusicName + FileStruct.SaveSongAddString);
                FileInfo albumFile = new FileInfo(FileStruct.BuffNetMusicName + FileStruct.SaveAlbumImageAddString);
                FileInfo artistFile = new FileInfo(FileStruct.BuffNetMusicName + FileStruct.SaveArtistImageAddString);

                Random rNumber = new Random();
                //目标音乐文件名
                string targetMusicName = FileStruct.UnityMusicName(MineSingleContext.NetMusic.Information.name);

                //目标专辑图片文件名
                string targetAlbumImageName =FileStruct.MusicImageDownLoadSaveBook + "\\" + 
                    UnityString.UseMD5(MineSingleContext.NetMusic.Information.album.name + "Album" + 
                        rNumber.NextDouble().ToString() + 
                            DateTime.Now.ToString() + targetMusicName) + ".jpg";

                //目标歌手图片文件名
                string targetArtistImageName = FileStruct.MusicImageDownLoadSaveBook + "\\" + 
                    UnityString.UseMD5(MineSingleContext.NetMusic.Information.artist.name + "Artist" +
                        rNumber.NextDouble().ToString() +
                            DateTime.Now.ToString() + targetMusicName) + ".jpg";

                //拷贝文件
                musicFile.CopyTo(targetMusicName);
                albumFile.CopyTo(targetAlbumImageName);
                artistFile.CopyTo(targetArtistImageName);

                //添加到音乐集
                BookMusicDetials music = new BookMusicDetials(targetMusicName, targetArtistImageName, targetAlbumImageName, BookMusicDetials.MusicType.DownloadMusic);
                bookName = MainWindow.MySelf.MusicBooks.AddMusicToMusicBook(id, music);

                //添加网易云下载音乐IDs 和 目标音乐地址
                MainWindow.MySelf.DownLoad.DownLoadedIDS.NetIDS.Add(MineSingleContext.NetMusic.Information.id , targetMusicName);

                DLoadedMusicRecord.Record record = new DLoadedMusicRecord.Record(targetMusicName, DateTime.Now, MineSingleContext.NetMusic.Information.name , bookName);
                record.SetNetID(MineSingleContext.NetMusic.Information.id);
                //添加下载记录
                MainWindow.MySelf.DownLoad.AddDownLoadedRecord(record);

                //成功下载则下载按钮消失
                DownLoadButton.Visibility = Visibility.Collapsed;
            } 
        }
    }
}
