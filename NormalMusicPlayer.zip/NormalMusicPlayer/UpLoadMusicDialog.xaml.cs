﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Forms;
using LaoyaosFile;
using LaoyaosMedia;
using LaoyaosImage;

namespace NormalMusicPlayer
{
    /// <summary>
    /// UpLoadMusicDialog.xaml 的交互逻辑
    /// </summary>
    public partial class UpLoadMusicDialog : Window
    {
        private const int ImageWH = 60;

        //音乐路径
        private string _MusicPath = string.Empty;
        private string _Comment = string.Empty;
        //是否已经获取了图片
        private bool IsAlbumImageHad = false;
        private bool IsArtistImageHad = false;
        //音乐图片路径
        private string _AlbumImagePath = string.Empty;
        private string _ArtistImagePath = string.Empty;

        private string _Title = string.Empty;
        private string _Artist = string.Empty;

        /// <summary>
        /// 选择的音乐路径
        /// </summary>
        public string MusicPath
        {
            get
            {
                return _MusicPath;
            }
        }

        /// <summary>
        /// 选择的专辑图片路径 ， 如果为 string.empty , 则代表MP3文件中自带了专辑图片
        /// </summary>
        public string AlbumImagePath
        {
            get
            {
                return _AlbumImagePath;
            }
        }

        /// <summary>
        /// 选择的歌手图片路径
        /// </summary>
        public string ArtistImagePath
        {
            get
            {
                return _ArtistImagePath;
            }
        }

        /// <summary>
        /// 音乐名
        /// </summary>
        public string MusicTitle
        {
            get
            {
                return _Title;
            }
        }

        /// <summary>
        /// 艺术家
        /// </summary>
        public string Artist
        {
            get
            {
                return _Artist;
            }
        }

        /// <summary>
        /// 注释
        /// </summary>
        public string Comment
        {
            get
            {
                return _Comment;
            }
        }

        public UpLoadMusicDialog()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadAlbumImageButton.IsEnabled = false;
            LoadArtistImageButton.IsEnabled = false;
            OKButton.IsEnabled = false;
            OKButton.Visibility = Visibility.Collapsed;

            TitleTextBox.IsEnabled = false;
            ArtistTextBox.IsEnabled = false;


            MessageTextBlock.Text = string.Empty;
        }

        //点击离开，直接返回false
        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        private void BaseTopGrid_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            //move the windows
            this.DragMove();
        }

        private void LoadAlbumImageButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();

            dialog.Title = "Select Album Image";
            dialog.CheckFileExists = true;
            dialog.Filter = "Image Files(*.jpg;*.jpeg)|*.jpg;*.jpeg";
            //不允许选择多个
            dialog.Multiselect = false;
            dialog.InitialDirectory = FileStruct.MusicImageDownLoadSaveBook;

            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                _AlbumImagePath = dialog.FileName;
                //设置已经加载图片
                IsAlbumImageHad = true;
                //设置图片源
                AlbumImage.Source = JPGImage.ResizeImage(dialog.FileName, ImageWH, ImageWH);
            }
        }

        private void LoadArtistImageButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();

            dialog.Title = "Select Artist Image";
            dialog.CheckFileExists = true;
            dialog.Filter = "Image Files(*.jpg;*.jpeg)|*.jpg;*.jpeg";
            //不允许选择多个
            dialog.Multiselect = false;
            dialog.InitialDirectory = FileStruct.MusicImageDownLoadSaveBook;

            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                _ArtistImagePath = dialog.FileName;
                //设置已经加载图片
                IsArtistImageHad = true;
                //设置图片源
                ArtistImage.Source = JPGImage.ResizeImage(dialog.FileName, ImageWH, ImageWH);
            }
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            if(TitleTextBox.Text == string.Empty)
            {
                MessageTextBlock.Text = "Title Can Not Be Empty";
                return;
            }

            if(ArtistTextBox.Text == string.Empty)
            {
                MessageTextBlock.Text = "Artist Can Not Be Empty";
                return;
            }

            if(!IsAlbumImageHad)
            {
                MessageTextBlock.Text = "Album Image Can Not Be Empty";
                return;
            }

            if(!IsArtistImageHad)
            {
                MessageTextBlock.Text = "Artist Image Can Not Be Empty";
                return;
            }

            _Title = TitleTextBox.Text.Trim();
            _Artist = ArtistTextBox.Text.Trim();
            _Comment = CommentTBox.Text.Replace("\n\n", "\n");

            //都选择了，则返回true
            this.DialogResult = true;
        }

        private void SelectLocalMusicButton_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();

            dialog.Title = "Select Music";
            dialog.CheckFileExists = true;
            dialog.Filter = "Music Files(*.mp3)|*.mp3";

            //不允许选择多个
            dialog.Multiselect = false;

            dialog.InitialDirectory = FileStruct.MusicDownLoadSaveBook;

            if (dialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                LoadAlbumImageButton.IsEnabled = true;
                LoadArtistImageButton.IsEnabled = true;
                OKButton.IsEnabled = true;
                OKButton.Visibility = Visibility.Visible;

                TitleTextBox.IsEnabled = true;
                ArtistTextBox.IsEnabled = true;

                //获取图片路径
                _MusicPath = dialog.FileName;

                //重新选择音乐 ， 清除之前所有的设置
                TitleTextBox.Text = string.Empty;
                ArtistTextBox.Text = string.Empty;
                AlbumImage.Source = null;
                ArtistImage.Source = null;
                _AlbumImagePath = string.Empty;
                _ArtistImagePath = string.Empty;
                //标志位恢复初始状态
                IsAlbumImageHad = false;
                IsArtistImageHad = false;

                MP3Information.InformationStruct information = MP3Information.GetInformation(dialog.FileName);

                if(information.Title != null && information.Title != null)
                {
                    TitleTextBox.Text = information.Title;
                }

                if(information.Artist != null && information.Artist != null)
                {
                    ArtistTextBox.Text = information.Artist;
                }

                //如果有图片则加载图片并使用其作为上传图片，不用再次上传
                if(information.Images != null && information.Images.Count > 0)
                {
                    BitmapImage image = information.Images[0];
                    image = JPGImage.ResizeImage(image, ImageWH, ImageWH);
                    AlbumImage.Source = image;
                    IsAlbumImageHad = true;
                }
            }
        }
    }
}
