﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Controls;
using NAudio;
using NAudio.Wave;

namespace LaoyaosMedia
{
    //由于只能有一首歌
    public class MP3Player
    {
        /*
        //时钟
        private  System.Windows.Threading.DispatcherTimer InsideSecondTimer = null;
        //只拥有一个media player组件，
        private   MediaPlayer MusicPlayer = null;
        //音乐开始或者结束事件
        public delegate void MusicBeginEventDel();
        public delegate void MusicStopEventDel(StopTypeEnum type);
        public delegate void MusicPlayingEventDel(double position);
        //音乐播放时候的事件代理
        private  MusicPlayingEventDel MusicPlayingEvent = null;
        //音乐开始事件
        private  MusicBeginEventDel MusicBeginEvent = null;
        //音乐自主结束事件
        private  MusicStopEventDel MusicStopEvent = null;
        //开始事件是否已经调用了
        private  bool IsBeginEventInvoked = false;
        //整体所有的时间
        private  TimeSpan _TotalTime;

        public enum StopTypeEnum
        {
            OutsideStop ,
            NormalStop
        }

        /// <summary>
        /// 歌曲的时长
        /// </summary>
        public  TimeSpan TotalTime
        {
            get
            {
                return _TotalTime;
            }
        }

        public MP3Player(string musicFilePath , MusicBeginEventDel begin , MusicStopEventDel stop , MusicPlayingEventDel playing , double volume)
        {
            MusicPlayer = new MediaPlayer();
            MusicPlayer.MediaEnded += MusicPlayer_MediaEnded;

            //初始化时钟
            InsideSecondTimer = new System.Windows.Threading.DispatcherTimer();
            //每一秒触发一次
            InsideSecondTimer.Interval = TimeSpan.FromSeconds(1);
            //关闭定时器
            InsideSecondTimer.IsEnabled = false;
            InsideSecondTimer.Tick += InsideSecondTimer_Tick;

            MusicBeginEvent = begin;
            MusicStopEvent = stop;
            MusicPlayingEvent = playing;

            //重置标志位
            IsBeginEventInvoked = false;

            //初始化media player并直接播放
            MusicPlayer.Open(new Uri(musicFilePath, UriKind.RelativeOrAbsolute));
            MusicPlayer.Play();

            SetPlayerVolume(volume);
            //开启定时器
            InsideSecondTimer.IsEnabled = true;
        }

        //每一秒的时间代理
        private  void InsideSecondTimer_Tick(object sender, EventArgs e)
        {
            if (MusicPlayer.NaturalDuration.HasTimeSpan)
            {
                //如果没有调用开始事件，则调用仅仅一次
                if(!IsBeginEventInvoked)
                {
                    IsBeginEventInvoked = true;
                    //获取整体的时间
                    _TotalTime = MusicPlayer.NaturalDuration.TimeSpan;
                    //调用映月开始事件代理事件
                    if(MusicBeginEvent != null)
                    {
                        MusicBeginEvent.Invoke();
                    } 
                }

                //计算位置百分比
                double position = MusicPlayer.Position.TotalSeconds / MusicPlayer.NaturalDuration.TimeSpan.TotalSeconds;

                if(MusicPlayingEvent != null)
                {
                    //通知外部播放进度
                    MusicPlayingEvent.Invoke(position);
                }
            }
        }

        //媒体自主停止事件，即播放到了末尾
        private  void MusicPlayer_MediaEnded(object sender, EventArgs e)
        {
            MusicPlayer.Stop();
            MusicPlayer.Close();

            //关闭定时器
            InsideSecondTimer.IsEnabled = false;

            if (MusicStopEvent != null)
            {
                MusicStopEvent.Invoke(StopTypeEnum.NormalStop);
            }         
        }

        /// <summary>
        /// 设置音乐播放位置
        /// </summary>
        /// <param name="percentPosition">百分比位置</param>
        public  void ChangePosition(double percentPosition)
        {
            double position = MusicPlayer.NaturalDuration.TimeSpan.TotalMilliseconds * percentPosition;

            MusicPlayer.Position = new TimeSpan(0, 0, 0, 0, (int)position);
        }

        /// <summary>
        /// 设置媒体音量
        /// </summary>
        /// <param name="value">音量值 0 - 1</param>
        public  void SetPlayerVolume(double value)
        {
            if(MusicPlayer != null)
            {
                MusicPlayer.Volume = value;
            }
        }

        /// <summary>
        /// 暂停音乐
        /// </summary>
        public void MusicPause()
        {
            MusicPlayer.Pause();
        }

        /// <summary>
        /// 彻底停止音乐播放音乐 , 外部作用，没有到达媒体流底部，故而不会触发MediaEnded事件
        /// </summary>
        public void MusicStop()
        {
            MusicPlayer.Stop();
            MusicPlayer.Close();

            //关闭定时器
            InsideSecondTimer.IsEnabled = false;

            if (MusicStopEvent != null)
            {
                MusicStopEvent.Invoke(StopTypeEnum.OutsideStop);
            }
        }

        /// <summary>
        /// 继续音乐
        /// </summary>
        public void MusicContinue()
        {
            MusicPlayer.Play();
        }*/

        /// <summary>
        /// 播放设备
        /// </summary>
        private IWavePlayer WaveOutDevice = null;
        /// <summary>
        /// mp3 音乐文件读取
        /// </summary>
        private AudioFileReader MP3FileReader = null;

        //时钟
        private System.Windows.Threading.DispatcherTimer InsideSecondTimer = null;

        public enum StopTypeEnum
        {
            OutsideStop,
            NormalStop
        }

        //音乐开始或者结束事件
        public delegate void MusicBeginEventDel();
        public delegate void MusicStopEventDel(StopTypeEnum type);
        public delegate void MusicPlayingEventDel(double position);

        //音乐播放时候的事件代理
        private MusicPlayingEventDel MusicPlayingEvent = null;
        //音乐开始事件
        private MusicBeginEventDel MusicBeginEvent = null;
        //音乐自主结束事件
        private MusicStopEventDel MusicStopEvent = null;
        //开始事件是否已经调用了
        private bool IsBeginEventInvoked = false;
        //以秒计算的音乐时间
        private MP3Information.TimeStruct _Time ;

        //音量值
        private float VolumeValue = 1.0f;

        /// <summary>
        /// 以秒计算的音乐时间
        /// </summary>
        public MP3Information.TimeStruct Time
        {
            get
            {
                return _Time;
            }
        }

        public MP3Player(float volume )
        {
            //设置音量
            VolumeValue = volume;

            //初始化时钟
            InsideSecondTimer = new System.Windows.Threading.DispatcherTimer();
            //每一秒触发一次
            InsideSecondTimer.Interval = TimeSpan.FromSeconds(1);
            //关闭定时器
            InsideSecondTimer.Stop();
            InsideSecondTimer.IsEnabled = true;
            //InsideSecondTimer.IsEnabled = false;
            InsideSecondTimer.Tick += InsideSecondTimer_Tick;
        }

        public void PlayMP3Music(string musicFilePath , MusicBeginEventDel begin, MusicStopEventDel stop, MusicPlayingEventDel playing , float volume)
        {
            _Time = MP3Information.GetMP3Time(musicFilePath);

            VolumeValue = volume;

            MusicBeginEvent = begin;
            MusicStopEvent = stop;
            MusicPlayingEvent = playing;

            WaveOutDevice = new WaveOut();
            MP3FileReader = new AudioFileReader(musicFilePath);
            //设置音量值
            MP3FileReader.Volume = VolumeValue;
            //自然停止事件引用
            WaveOutDevice.PlaybackStopped += WaveOutDevice_PlaybackStopped;
            WaveOutDevice.Init(MP3FileReader);
            //表示为没有使用
            IsBeginEventInvoked = false;
            
            WaveOutDevice.Play();

            //开启定时器
            //InsideSecondTimer.IsEnabled = true;
            InsideSecondTimer.Start();
            
        }

        //媒体自主停止事件，即播放到了末尾
        private void WaveOutDevice_PlaybackStopped(object sender, StoppedEventArgs e)
        {
            //关闭流
            CloseWaveOut();
            _Time.Clear();

            //关闭定时器
            //InsideSecondTimer.IsEnabled = false;
            InsideSecondTimer.Stop();

            //调用事件
            if (MusicStopEvent != null)
            {
                MusicStopEvent.Invoke(StopTypeEnum.NormalStop);
            }
        }

        /// <summary>
        /// 设置音乐播放位置
        /// </summary>
        /// <param name="percentPosition">百分比位置</param>
        public void ChangePosition(float percentPosition)
        {
            long position =(long)( MP3FileReader.Length * percentPosition);

            MP3FileReader.Position = position;
        }

        /// <summary>
        /// 彻底停止音乐播放音乐 , 外部作用，没有到达媒体流底部，故而不会触发MediaEnded事件
        /// </summary>
        public void MusicStop()
        {

            //关闭流
            CloseWaveOut();
            _Time.Clear();

            //关闭定时器
            //InsideSecondTimer.IsEnabled = false;
            InsideSecondTimer.Stop();

            if (MusicStopEvent != null)
            {
                MusicStopEvent.Invoke(StopTypeEnum.OutsideStop);
            }
        }

        //关闭流
        private void CloseWaveOut()
        {
            if (WaveOutDevice != null)
            {
                WaveOutDevice.Stop();
            }
            if (MP3FileReader != null)
            {
                MP3FileReader.Dispose();
                MP3FileReader = null;
            }
            if (WaveOutDevice != null)
            {
                WaveOutDevice.Dispose();
                WaveOutDevice = null;
            }
        }

        /// <summary>
        /// 设置媒体音量
        /// </summary>
        /// <param name="value">音量值 0 - 1</param>
        public void SetPlayerVolume(float value)
        {
            if (MP3FileReader != null)
            {
                MP3FileReader.Volume = value;
            }

            VolumeValue = value;
        }

        /// <summary>
        /// 暂停音乐
        /// </summary>
        public void MusicPause()
        {
            if(WaveOutDevice!= null)
            {
                WaveOutDevice.Pause();
            }  
        }

        /// <summary>
        /// 继续音乐
        /// </summary>
        public void MusicContinue()
        {
            if(WaveOutDevice != null)
            {
                WaveOutDevice.Play();
            }
        }

        //每一秒的时间代理
        private void InsideSecondTimer_Tick(object sender, EventArgs e)
        {
            if (WaveOutDevice != null && WaveOutDevice.PlaybackState == PlaybackState.Playing)
            {
                //如果没有调用开始事件，则调用仅仅一次
                if (!IsBeginEventInvoked)
                {
                    IsBeginEventInvoked = true;
                    //调用映月开始事件代理事件
                    if (MusicBeginEvent != null)
                    {
                        MusicBeginEvent.Invoke();
                    }
                }

                //计算百分比
                if (MP3FileReader != null)
                {
                    //计算位置百分比
                    double position = MP3FileReader.Position /(double) MP3FileReader.Length;

                    if (MusicPlayingEvent != null)
                    {
                        //通知外部播放进度
                        MusicPlayingEvent.Invoke(position);
                    }
                }
            }
        }
    }
}
