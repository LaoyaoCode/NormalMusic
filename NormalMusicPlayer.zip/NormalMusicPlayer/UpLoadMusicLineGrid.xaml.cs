﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media.Animation;
using NormalMusicPlayer.Sql;
using NormalFTP;
using LaoyaosProgramMessage;
using LaoyaosFile;
using System.IO;
using LaoyaosImage;
using LaoyaosMedia;

namespace NormalMusicPlayer
{
    /// <summary>
    /// UpLoadMusicLineGrid.xaml 的交互逻辑
    /// </summary>
    public partial class UpLoadMusicLineGrid : UserControl
    {
        //上传音乐进度条最大长度
        private const int UpLoadingBarMaxWidth = 300;
        private const int UpLoadImageWH = 200;
        private bool IsCommentAppear = false;
        private NormalMusicUpLoadMusic UpLoadMusic = null;
        //音乐是否已经上传
        private bool IsMusicUpLoaded = false;

        private NormalMusicUserInformation UserInformation = null;
        //上传信息
        private string UpLoadingMusicPath = string.Empty;
        private string UpLoadingAlbumPath = string.Empty;
        private string UpLoadingArtistPath = string.Empty;
        private string UpLoadingMusicName = string.Empty;
        private string UpLoadingArtistName = string.Empty;
        private string UpLoadingComment = string.Empty;

        private MusicBelongEnum MusicBelong;

        /// <summary>
        /// 云音乐ID
        /// </summary>
        public string CloudID
        {
            get
            {
                if(UpLoadMusic != null && IsMusicUpLoaded)
                {
                    return UpLoadMusic.CloudMusicID;
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        /// <summary>
        /// 音乐归属枚举体
        /// </summary>
        public enum MusicBelongEnum
        {
            /// <summary>
            /// 属于自己的
            /// </summary>
            Mine , 
            /// <summary>
            /// 属于其他人的
            /// </summary>
            Others
        }

        /// <summary>
        /// 删除事件代理
        /// </summary>
        /// <param name="sender">发送者</param>
        /// <param name="musicInformation">音乐信息</param>
        public delegate void DeleteEventDel(UpLoadMusicLineGrid sender, NormalMusicUpLoadMusic musicInformation);
        /// <summary>
        /// 上传音乐失败事件代理
        /// </summary>
        /// <param name="sender">发送者</param>
        public delegate void UpLoadingFailedEventDel(UpLoadMusicLineGrid sender);

        private DeleteEventDel DeleteEvent = null;

        private UpLoadingFailedEventDel UpLoadingFailedEvent = null;

        public UpLoadMusicLineGrid()
        {
            InitializeComponent();
        }

        /// <summary>
        /// 显示已经上传的音乐
        /// </summary>
        /// <param name="information">音乐信息</param>
        /// <param name="delete">删除事件代理</param>
        /// <param name="user">用户信息</param>
        /// <param name="belong">音乐的归属</param>
        public UpLoadMusicLineGrid(NormalMusicUpLoadMusic information ,NormalMusicUserInformation user ,  DeleteEventDel delete , MusicBelongEnum belong)
        {
            InitializeComponent();

            //显示已上传信息
            UpLoadedMusicGrid.Visibility = Visibility.Visible;
            UpLoadingMusicGrid.Visibility = Visibility.Collapsed;

            //如果该云歌曲已经下载到了本地的话不可再次下载
            if (MainWindow.MySelf.DownLoad.DownLoadedIDS.CloudIDS.ContainsKey(information.CloudMusicID))
            {
                DownLoadButton.Visibility = Visibility.Collapsed;
            }
           
            UpLoadMusic = information;

            DeleteEvent = delete;
            UserInformation = user;

            MusicBelong = belong;

            //表示为音乐已经上传
            IsMusicUpLoaded = true;

            DisplayUpLoadedMusic();
        }

        /// <summary>
        /// 显示正在上传的音乐
        /// </summary>
        /// <param name="musicSource">音乐文件源地址</param>
        /// <param name="album">专辑图片源地址</param>
        /// <param name="artist">歌手图片源地址</param>
        /// <param name="musicName">音乐名</param>
        /// <param name="artistName">艺术家名字</param>
        /// <param name="comment">注释</param>
        /// <param name="userInformation">用户信息</param>
        /// <param name="delete">删除事件代理</param>
        /// <param name="failed">上传事件失败事件代理</param>
        public UpLoadMusicLineGrid(string musicSource , string album , string artist , string musicName , string artistName ,string comment ,  NormalMusicUserInformation userInformation ,  DeleteEventDel delete, UpLoadingFailedEventDel failed , MusicBelongEnum belong)
        {
            InitializeComponent();

            //显示正在上传信息
            UpLoadedMusicGrid.Visibility = Visibility.Collapsed;
            UpLoadingMusicGrid.Visibility = Visibility.Visible;

            //获取上传信息
            UpLoadingMusicPath = musicSource;
            UpLoadingAlbumPath = album;
            UpLoadingArtistPath = artist;

            UpLoadingMusicName = musicName;
            UpLoadingArtistName = artistName;
            UpLoadingComment = comment;

            UserInformation = userInformation;

            DeleteEvent = delete;
            UpLoadingFailedEvent = failed;

            //显示音乐上传音乐名
            MusicNameLabel.Content = musicName;

            MusicBelong = belong;

            //更新上传bar
            UpDateUpLoadingBar(0);

            //更新信息
            UpDateInformation(string.Empty);

            //异步上传音乐
            UpLoadingAsync();
        }

        //显示已经上传的音乐信息
        private void DisplayUpLoadedMusic()
        {
            if(MusicBelong == MusicBelongEnum.Mine)
            {
                DeleteButton.Visibility = Visibility.Visible;
            }
            else
            {
                DeleteButton.Visibility = Visibility.Collapsed;
            }

            MusicNameLabel.Content = UpLoadMusic.MusicName;
            UploadTimeLabel.Content = UpLoadMusic.UpLoadTimeYear + "-" + UpLoadMusic.UpLoadTimeMonth + "-" + UpLoadMusic.UpLoadTimeDay;
            ArtistLabel.Content = UpLoadMusic.ArtistName;
            DownLoadTimesLabel.Content = UpLoadMusic.DownloadTimes;
            CommentTBox.Text = UpLoadMusic.Comment;
        }

        private void UpDateUpLoadingBar(double percentage)
        {
            this.Dispatcher.Invoke(() =>
            {
                //更新长度变化
                UpLoadingBarUp.Width = UpLoadingBarMaxWidth * percentage;
            });
        }

        private void UpDateInformation(string information)
        {
            this.Dispatcher.Invoke(() =>
            {
                UpLoadingInformationTBlock.Text = information;
            });
        }

        private async void UpLoadingAsync()
        {
            Random randomNumber = new Random();
            FileInfo copyFile = null;

            string localMusicBuffName =FileStruct.BuffUpLoadBookName + "\\" + UnityString.UseMD5(UpLoadingMusicPath + DateTime.Now.ToString() + randomNumber.NextDouble()) + ".mp3";
            string localAlbumBuffName = string.Empty;
            string localArtistBuffName = string.Empty;

            //sql 文件路径值
            string sqlMusicPathValue = string.Empty;
            string sqlAlbumPathValue = string.Empty;
            string sqlArtistPathValue = string.Empty;

            string cloudMusicID = string.Empty;

            await Task.Run(() =>
            {
                bool uploadingResult = false;

                //生成cloud music id
                cloudMusicID = UnityString.UseMD5(UserInformation.MatchProgramCodeID + UserInformation.MachineCode + DateTime.Now.ToString() + UpLoadingMusicPath);
                //sql 存储值
                sqlMusicPathValue = cloudMusicID + ".mp3";
                
                //赋值音乐到缓存文件夹
                copyFile = new FileInfo(UpLoadingMusicPath);
                if(copyFile.Exists)
                {
                    copyFile.CopyTo(localMusicBuffName, true);
                }
                else
                {
                    UpDateInformation("Local Music File Lost");
                    this.Dispatcher.Invoke(() =>
                    {
                        UpLoadingFailedEvent.Invoke(this);
                    });
                    return;
                }

                //生成缓冲唯一字符串
                if (UpLoadingAlbumPath != string.Empty && UpLoadingAlbumPath != null)
                {
                    localAlbumBuffName = FileStruct.BuffUpLoadBookName + "\\" + UnityString.UseMD5(UpLoadingAlbumPath + DateTime.Now.ToString() + randomNumber.NextDouble()) + ".jpg";

                    sqlAlbumPathValue = UnityString.UseMD5(cloudMusicID + "Album" + randomNumber.NextDouble()) + ".jpg";

                    //裁剪大小复制到缓存文件架
                    copyFile = new FileInfo(UpLoadingAlbumPath);
                    if (copyFile.Exists)
                    {
                        JPGImage.ResizeImage(UpLoadingAlbumPath, localAlbumBuffName, UpLoadImageWH, UpLoadImageWH);
                    }
                    else
                    {
                        UpDateInformation("Local Album Image File Lost");
                        this.Dispatcher.Invoke(() =>
                        {
                            UpLoadingFailedEvent.Invoke(this);
                        });
                        return;
                    }

                }
                else
                {
                    sqlAlbumPathValue = NormalMusicSqlControl.UpLoadImageNoneString;
                }

                if (UpLoadingArtistPath != string.Empty && UpLoadingArtistPath != null)
                {
                    localArtistBuffName = FileStruct.BuffUpLoadBookName + "\\" + UnityString.UseMD5(UpLoadingArtistPath + DateTime.Now.ToString() + randomNumber.NextDouble()) + ".jpg";

                    sqlArtistPathValue = UnityString.UseMD5(cloudMusicID + "Artist" + randomNumber.NextDouble()) + ".jpg";

                    copyFile = new FileInfo(UpLoadingArtistPath);
                    if (copyFile.Exists)
                    {
                        JPGImage.ResizeImage(UpLoadingArtistPath, localArtistBuffName, UpLoadImageWH, UpLoadImageWH);
                    }
                    else
                    {
                        UpDateInformation("Local Artist Image File Lost");
                        this.Dispatcher.Invoke(() =>
                        {
                            UpLoadingFailedEvent.Invoke(this);
                        });
                        return;
                    }
                }
                else
                {
                    sqlArtistPathValue = NormalMusicSqlControl.UpLoadImageNoneString;
                }


                if (localAlbumBuffName != string.Empty)
                {
                    uploadingResult = false;

                    //更新信息
                    UpDateUpLoadingBar(0);
                    UpDateInformation("UpLoading Album Image");
                    MainWindow.NormalFTP.UploadFile(localAlbumBuffName,
                        UserInformation.BelongBookPath + "\\" + NormalFTPFileStruct.UserImageBookName + "\\" + sqlAlbumPathValue,
                        (state, per, message) =>
                        {
                            if(state == NormalFTPControl.FTPDisposeStateEnum.Finished)
                            {
                                //更新信息
                                UpDateUpLoadingBar(1);
                                UpDateInformation("Album Image Finsihed");
                                uploadingResult = true;
                            }
                            else if(state == NormalFTPControl.FTPDisposeStateEnum.Disposing)
                            {
                                //更新信息
                                UpDateUpLoadingBar(per);
                            }
                            else if(state == NormalFTPControl.FTPDisposeStateEnum.Error)
                            {
                                //更新信息
                                UpDateUpLoadingBar(0);
                                UpDateInformation("Album Image Failed");
                            }
                        });

                    if(!uploadingResult)
                    {
                        this.Dispatcher.Invoke(() =>
                        {
                            UpLoadingFailedEvent.Invoke(this);
                        });
                        return;
                    }
                }

                if (localArtistBuffName != string.Empty)
                {
                    uploadingResult = false;

                    //更新信息
                    UpDateUpLoadingBar(0);
                    UpDateInformation("UpLoading Artist Image");
                    MainWindow.NormalFTP.UploadFile(localArtistBuffName,
                        UserInformation.BelongBookPath + "\\" + NormalFTPFileStruct.UserImageBookName + "\\" + sqlArtistPathValue,
                        (state, per, message) =>
                        {
                            if (state == NormalFTPControl.FTPDisposeStateEnum.Finished)
                            {
                                //更新信息
                                UpDateUpLoadingBar(1);
                                UpDateInformation("Artist Image Finsihed");
                                uploadingResult = true;
                            }
                            else if (state == NormalFTPControl.FTPDisposeStateEnum.Disposing)
                            {
                                //更新信息
                                UpDateUpLoadingBar(per);
                            }
                            else if (state == NormalFTPControl.FTPDisposeStateEnum.Error)
                            {
                                //更新信息
                                UpDateUpLoadingBar(0);
                                UpDateInformation("Artist Image Failed");
                            }
                        });

                    if (!uploadingResult)
                    {
                        this.Dispatcher.Invoke(() =>
                        {
                            UpLoadingFailedEvent.Invoke(this);
                        });
                        return;
                    }
                }

                uploadingResult = false;

                //更新信息
                UpDateUpLoadingBar(0);
                UpDateInformation("UpLoading Music");
                //修改mp3 tag 信息
                MP3Information.ModifyMP3Tag(localMusicBuffName, UpLoadingMusicName, string.Empty, UpLoadingArtistName);

                MainWindow.NormalFTP.UploadFile(localMusicBuffName,
                    UserInformation.BelongBookPath + "\\" + NormalFTPFileStruct.UserMusicBookName + "\\" + sqlMusicPathValue,
                    (state, per, message) =>
                    {
                        if (state == NormalFTPControl.FTPDisposeStateEnum.Finished)
                        {
                                //更新信息
                                UpDateUpLoadingBar(1);
                                UpDateInformation("Music Finsihed");
                                uploadingResult = true;
                        }
                        else if (state == NormalFTPControl.FTPDisposeStateEnum.Disposing)
                        {
                             //更新信息
                                UpDateUpLoadingBar(per);
                        }
                        else if (state == NormalFTPControl.FTPDisposeStateEnum.Error)
                        {
                            //更新信息
                                UpDateUpLoadingBar(0);
                                UpDateInformation("Music Failed");
                        }
                    });

                if (!uploadingResult)
                {
                    this.Dispatcher.Invoke(() =>
                    {
                        UpLoadingFailedEvent.Invoke(this);
                    });
                    return;
                }

                if (UpLoadingComment == string.Empty || UpLoadingComment == null)
                {
                    UpLoadingComment = NormalMusicSqlControl.UpLoadImageNoneString;
                }

                //所有文件全部上传完成之后 , 开始写入数据库
                UpLoadMusic = new NormalMusicUpLoadMusic();
                UpLoadMusic.AlbumFileName = sqlAlbumPathValue;
                UpLoadMusic.ArtistFileName = sqlArtistPathValue;
                UpLoadMusic.ArtistName = UpLoadingArtistName;
                UpLoadMusic.BelongUserID = UserInformation.ID;
                UpLoadMusic.CloudMusicID = cloudMusicID;
                UpLoadMusic.DownloadTimes = 0;
                UpLoadMusic.Comment = UpLoadingComment;
                UpLoadMusic.MusicFileName = sqlMusicPathValue;
                UpLoadMusic.MusicName = UpLoadingMusicName;
                UpLoadMusic.UpLoadTimeDay =(sbyte) DateTime.Now.Day;
                UpLoadMusic.UpLoadTimeMonth = (sbyte)DateTime.Now.Month;
                UpLoadMusic.UpLoadTimeYear = (sbyte)( DateTime.Now.Year - 2000 );
            
                MainWindow.NormalMusicSql.AddUpLoadMusic(UpLoadMusic);

                string errorMessage = string.Empty;

                errorMessage = MainWindow.NormalMusicSql.SaveChanges();
               
                if(errorMessage == string.Empty)
                {
                    //表示为音乐已经上传
                    IsMusicUpLoaded = true;

                    MainWindow.MySelf.DisplayMessageNoUIThread(UpLoadingMusicName + "\nUpLoad Scuuess");
                    this.Dispatcher.Invoke(() =>
                    {
                        //显示已经上传信息
                        UpLoadedMusicGrid.Visibility = Visibility.Visible;
                        UpLoadingMusicGrid.Visibility = Visibility.Collapsed;
                        DisplayUpLoadedMusic();
                    });
                }
                else
                {
                    this.Dispatcher.Invoke(() =>
                    {
                        UpLoadingFailedEvent.Invoke(this);
                    });
                    MainWindow.MySelf.DisplayMessageNoUIThread(UpLoadingMusicName + "UpLoad Failed\n" + "写入数据库失败");
                }
            });


            //无论结果如何，删除缓存文件
            FileInfo deleteFile = null;

            if(localAlbumBuffName != string.Empty)
            {
                deleteFile = new FileInfo(localAlbumBuffName);
                if(deleteFile.Exists)
                {
                    deleteFile.Delete(); 
                }
            }

            if (localArtistBuffName != string.Empty)
            {
                deleteFile = new FileInfo(localArtistBuffName);
                if (deleteFile.Exists)
                {
                    deleteFile.Delete();
                }
            }

            if (localMusicBuffName != string.Empty)
            {
                deleteFile = new FileInfo(localMusicBuffName);
                if (deleteFile.Exists)
                {
                    deleteFile.Delete();
                }
            }
        }

        private void SeeCommentButton_Click(object sender, RoutedEventArgs e)
        {
            Storyboard story = null;

            if(IsCommentAppear)
            {
                IsCommentAppear = false;
                SeeCommentButton.ToolTip = "See Comment";
                story = (Storyboard)Resources["CommentDisappear"];
            }
            else
            {
                IsCommentAppear = true;
                SeeCommentButton.ToolTip = "Close Comment";
                story = (Storyboard)Resources["CommentAppear"];
            }

            story.Begin();
        }

        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            //调用事件代理
            DeleteEvent.Invoke(this, UpLoadMusic);
        }

        private void DownLoadButton_Click(object sender, RoutedEventArgs e)
        {
            string id = string.Empty;
            id = MainWindow.MySelf.MusicBooks.SelectMusicBook_OutsideUse();

            DownLoadButton.IsEnabled = false;

            //如果取得了ID的话 ， 也就是选择了文件夹
            if (id != string.Empty)
            {
                //下载音乐
                MainWindow.MySelf.DownLoad.DownLoadCloudMusic(UpLoadMusic, id, UserInformation.BelongBookPath,
                    //下载成功
                    ()=>
                {
                    //下载按钮消失
                    DownLoadButton.Visibility = Visibility.Collapsed;
                    DownLoadTimesLabel.Content = UpLoadMusic.DownloadTimes;
                } , 
                    //下载失败
                    ()=>
                {
                    //下载按钮重新使能
                    DownLoadButton.IsEnabled = true;
                });
            }
        }

        /// <summary>
        /// 云音乐ID被删除，也就是云本地音乐被删除 ， 故而可以再次下载
        /// </summary>
        public void CloudIDRecordDeleted()
        {
            DownLoadButton.IsEnabled = true;
            DownLoadButton.Visibility = Visibility.Visible;
        }

    }
}
