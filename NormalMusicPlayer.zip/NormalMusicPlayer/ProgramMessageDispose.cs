﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LaoyaosFile;
using System.Xml;
using System.Xml.Serialization;
using System.Xml.Linq;
using System.IO;
using System.Windows.Controls;
using NormalMusicPlayer;
using System.Security.Cryptography;

namespace LaoyaosProgramMessage
{
    
    public static class AppInitXmlDataNode
    {
        public const string RootNodeName = "InitData";
        public const string VolumeControlNodeName = "VolumeInit";
        public const string VolumeIsSlienceNodeName = "IsSlience";
        public const string VolumeValueNodeName = "VolumeValue";
        public const string MusicPlayModeNodeName = "MusicPlayMode";
        public const string FTPControlNodeName = "FTPInit";
        public const string UserNameNodeName = "UserName";
        public const string PasswordsNodeName = "Passwords";
        public const string SeverIpNodeName = "Ip";
        public const string MySqlControlNodeName = "MySqlInit";
    }
    /// <summary>
    /// 程序音量控制，包括大小，本地存储等等
    /// </summary>
    public class ProgramVolumeControl
    {
        private double _Value = 0.0;
        private bool _IsSlience = false;

        public double Value
        {
            get
            {
                return _Value;
            }

            set
            {
                if(value > 1 || value < 0)
                {
                    throw new Exception("Volume must between 0 - 1");
                }

                _Value = value;
            }
        }

        public bool IsSlience
        {
            get
            {
                return _IsSlience;
            }

            set
            {
                _IsSlience = value;
            }
        }

        public ProgramVolumeControl()
        {
            
            XmlDocument doc = new XmlDocument();
            XmlNode rootNode = null;
            XmlNode VolumeControlNode = null;
            //获取XML文档
            doc.Load(FileStruct.AppInitDataFileName);
            //获取根节点
            rootNode = doc.SelectSingleNode(AppInitXmlDataNode.RootNodeName);
            //获取 volume control节点
            VolumeControlNode = rootNode.SelectSingleNode(AppInitXmlDataNode.VolumeControlNodeName);

            _Value = double.Parse(VolumeControlNode.SelectSingleNode(AppInitXmlDataNode.VolumeValueNodeName).InnerText);
            _IsSlience = bool.Parse(VolumeControlNode.SelectSingleNode(AppInitXmlDataNode.VolumeIsSlienceNodeName).InnerText);
            
        }

        /// <summary>
        /// 将数据保存到本地
        /// </summary>
        public void SaveToLocal()
        {
            
            XmlDocument doc = new XmlDocument();
            XmlNode rootNode = null;
            XmlNode VolumeControlNode = null;
            //获取XML文档
            doc.Load(FileStruct.AppInitDataFileName);
            //获取根节点
            rootNode = doc.SelectSingleNode(AppInitXmlDataNode.RootNodeName);
            //获取 volume control节点
            VolumeControlNode = rootNode.SelectSingleNode(AppInitXmlDataNode.VolumeControlNodeName);

            VolumeControlNode.SelectSingleNode(AppInitXmlDataNode.VolumeValueNodeName).InnerText = _Value.ToString();
            VolumeControlNode.SelectSingleNode(AppInitXmlDataNode.VolumeIsSlienceNodeName).InnerText = _IsSlience.ToString();

            doc.Save(FileStruct.AppInitDataFileName);
        }
    }

    public class MusicPlayModeControl
    {
        public enum Mode
        {
            Circle , 
            Random
        }

        private Mode _MusicMode;

        public Mode MusicMode
        {
            get
            {
                return _MusicMode;
            }
        }

        public MusicPlayModeControl()
        {
            XmlDocument doc = new XmlDocument();
            XmlNode rootNode = null;
            XmlNode VolumeControlNode = null;
            //获取XML文档
            doc.Load(FileStruct.AppInitDataFileName);
            //获取根节点
            rootNode = doc.SelectSingleNode(AppInitXmlDataNode.RootNodeName);
            //获取 music play mode节点
            VolumeControlNode = rootNode.SelectSingleNode(AppInitXmlDataNode.MusicPlayModeNodeName);
            //获取音乐播放模式
            _MusicMode =(Mode) Enum.Parse(typeof(Mode), VolumeControlNode.InnerText);
        }

        //改变模式
        public void ChangeMode()
        {
            switch(_MusicMode)
            {
                case Mode.Circle:
                    _MusicMode = Mode.Random;
                    break;
                case Mode.Random:
                    _MusicMode = Mode.Circle;
                    break;
            }
        }

        public void SaveToLocal()
        {
            XmlDocument doc = new XmlDocument();
            XmlNode rootNode = null;
            XmlNode VolumeControlNode = null;
            //获取XML文档
            doc.Load(FileStruct.AppInitDataFileName);
            //获取根节点
            rootNode = doc.SelectSingleNode(AppInitXmlDataNode.RootNodeName);
            //获取 music play mode节点
            VolumeControlNode = rootNode.SelectSingleNode(AppInitXmlDataNode.MusicPlayModeNodeName);
            //设置 节点内容
            VolumeControlNode.InnerText = _MusicMode.ToString();
            //保存到本地
            doc.Save(FileStruct.AppInitDataFileName);
        }
    }

    public class ProgramNetSecretControl
    {
        private string _FTPUserName = string.Empty;
        private string _FTPPasswords = string.Empty;
        private string _FTPSeverIp = string.Empty;
        private string _MySqlUserName = string.Empty;
        private string _MySqlPasswords = string.Empty;
        private string _MySqlSeverIp = string.Empty;

        /// <summary>
        /// FTP的登录用户名
        /// </summary>
        public string FTPUserName
        {
            get
            {
                return _FTPUserName;
            }
        }
        /// <summary>
        /// FTP的登录密码
        /// </summary>
        public string FTPPasswords
        {
            get
            {
                return _FTPPasswords;
            }
        }

        /// <summary>
        /// FTP服务器IP
        /// </summary>
        public string FTPSeverIp
        {
            get
            {
                return _FTPSeverIp;
            }
        }

        /// <summary>
        /// mysql 数据库登录密码
        /// </summary>
        public string MySqlPasswords
        {
            get
            {
                return _MySqlPasswords;
            }
        }

        /// <summary>
        /// mysql 登录用户名
        /// </summary>
        public string MySqlUserName
        {
            get
            {
                return _MySqlUserName;
            }
        }

        /// <summary>
        /// mysql 服务器地址
        /// </summary>
        public string MySqlSeverIp
        {
            get
            {
                return _MySqlSeverIp;
            }
        }

        public ProgramNetSecretControl(string key)
        {
            XmlDocument doc = new XmlDocument();
            XmlNode rootNode = null;
            XmlNode ftpControlNode = null;
            XmlNode mysqlControlNode = null;

            //获取XML文档
            doc.Load(FileStruct.AppInitDataFileName);
            //获取根节点
            rootNode = doc.SelectSingleNode(AppInitXmlDataNode.RootNodeName);
            //获取 ftp control node
            ftpControlNode = rootNode.SelectSingleNode(AppInitXmlDataNode.FTPControlNodeName);
            //获取mysql control node
            mysqlControlNode = rootNode.SelectSingleNode(AppInitXmlDataNode.MySqlControlNodeName);

            _FTPUserName = ftpControlNode.SelectSingleNode(AppInitXmlDataNode.UserNameNodeName).InnerText;
            _FTPPasswords = ftpControlNode.SelectSingleNode(AppInitXmlDataNode.PasswordsNodeName).InnerText;
            _FTPSeverIp = ftpControlNode.SelectSingleNode(AppInitXmlDataNode.SeverIpNodeName).InnerText;

            _MySqlUserName = mysqlControlNode.SelectSingleNode(AppInitXmlDataNode.UserNameNodeName).InnerText;
            _MySqlPasswords = mysqlControlNode.SelectSingleNode(AppInitXmlDataNode.PasswordsNodeName).InnerText;
            _MySqlSeverIp = mysqlControlNode.SelectSingleNode(AppInitXmlDataNode.SeverIpNodeName).InnerText;

            _FTPUserName = UnityString.DecryptString(_FTPUserName, key);
            _FTPPasswords = UnityString.DecryptString(_FTPPasswords, key);
            _FTPSeverIp = UnityString.DecryptString(_FTPSeverIp, key);

            _MySqlUserName = UnityString.DecryptString(_MySqlUserName, key);
            _MySqlPasswords = UnityString.DecryptString(_MySqlPasswords, key);
            _MySqlSeverIp = UnityString.DecryptString(_MySqlSeverIp, key);
        }
    }

    public class LisenceControl
    {
        private const string RootNodeName = "ProgramLisence";
        private const string PCodeNodeName = "PCode";

        private string _PCode = string.Empty;

        /// <summary>
        /// 程序序列号
        /// </summary>
        public string PCode
        {
            get
            {
                return _PCode;
            }

            set
            {
                _PCode = value;
            }
        }

        public LisenceControl(string key)
        {
            XmlDocument doc = new XmlDocument();
            XmlNode rootNode = null;
           
            //获取XML文档
            doc.Load(FileStruct.AppLisenceDataFileName);
            //获取根节点
            rootNode = doc.SelectSingleNode(RootNodeName);
            //获取 PCode节点
            _PCode = rootNode.SelectSingleNode(PCodeNodeName).InnerText;
            //解密字符串
            _PCode = UnityString.DecryptString(_PCode, key);
        }

        public void SaveToLocal(string key)
        {
            XmlDocument doc = new XmlDocument();
            XmlNode rootNode = null;

            //获取XML文档
            doc.Load(FileStruct.AppLisenceDataFileName);
            //获取根节点
            rootNode = doc.SelectSingleNode(RootNodeName);
            //获取 PCode节点 , 写入加密字符串到其中
            rootNode.SelectSingleNode(PCodeNodeName).InnerText = UnityString.EncryptString(_PCode , key);
            //保存文档
            doc.Save(FileStruct.AppLisenceDataFileName);
        }
    }
    public class DLoadedMusicRecord
    {
        [Serializable]
        public class Record
        {
            /// <summary>
            /// 音乐文件绝对路径
            /// </summary>
            public string MusicObsolutePath;
            /// <summary>
            /// 下载的时间
            /// </summary>
            public DateTime Time;
            /// <summary>
            /// 音乐名字
            /// </summary>
            public string Name;
            /// <summary>
            /// 属于的音乐名
            /// </summary>
            public string BelongMusicBook;
            /// <summary>
            /// 网易云下载的ID , 默认为string.Empty
            /// </summary>
            public string NetMusicID = string.Empty;
            /// <summary>
            /// 从云上下载的音乐ID , 默认为string.Empty
            /// </summary>
            public string CloudMusicID = string.Empty;

            /// <summary>
            /// 音乐下载记录
            /// </summary>
            /// <param name="musicPath">音乐文件路径</param>
            /// <param name="time">下载时间</param>
            /// <param name="name">音乐名字</param>
            public Record(string musicPath , DateTime time , string name , string belongMusicBook)
            {
                MusicObsolutePath = musicPath;
                Time = time;
                Name = name;
                BelongMusicBook = belongMusicBook;
            }

            public Record()
            {
                MusicObsolutePath = string.Empty ;
                Time = new DateTime();
                Name = string.Empty ;
            }

            public void SetNetID(string id)
            {
                NetMusicID = id;
            }

            public void SetCloudID(string id)
            {
                CloudMusicID = id;
            }
        }

        /// <summary>
        /// 记录集合
        /// </summary>
        public List<Record> RecordsList = null;

        public DLoadedMusicRecord()
        {
            FileInfo checkExist = new FileInfo(FileStruct.DownLoadedRecordsFileName);

            //之前存在记录的话则反序列化
            if(checkExist.Exists)
            {
                XmlSerializer xmlFormat = new XmlSerializer(typeof(List<Record>));
                using (Stream fStream = new FileStream(FileStruct.DownLoadedRecordsFileName
                    , FileMode.Open, FileAccess.ReadWrite))
                {
                    RecordsList = (List <Record> )xmlFormat.Deserialize(fStream);
                }
            }
            //之前不存在记录的话，则直接初始化
            else
            {
                RecordsList = new List<Record>();
            }
        }

        /// <summary>
        /// 保存数据到本地
        /// </summary>
        public void SaveToLocal()
        {
            XmlSerializer xmlFormat = new XmlSerializer(typeof(List<Record>));
            using (Stream fStream = new FileStream(FileStruct.DownLoadedRecordsFileName
                , FileMode.Create, FileAccess.ReadWrite))
            {
                xmlFormat.Serialize(fStream , RecordsList);
            }
        }
    }

    /// <summary>
    /// 音乐集中音乐详情
    /// </summary>
    [Serializable]
    public class BookMusicDetials
    {
        /// <summary>
        /// 音乐绝对地址
        /// </summary>
        public string MusicPath;
        /// <summary>
        /// 艺术家图片地址
        /// </summary>
        public string ArtistImagePath;
        /// <summary>
        /// 专辑图片地址
        /// </summary>
        public string AlbumImagePath;

        public MusicType Type;

        public enum MusicType
        {
            DownloadMusic ,
            LocalMusic
        }

        public BookMusicDetials()
        {
            MusicPath = string.Empty;
            ArtistImagePath = string.Empty;
            AlbumImagePath = string.Empty;
        }

        /// <summary>
        /// 音乐集中音乐详情
        /// </summary>
        /// <param name="music">音乐地址</param>
        /// <param name="artist">歌手图片地址</param>
        /// <param name="album">专辑图片地址</param>
        /// <param name="type">音乐类型</param>
        public BookMusicDetials(string music , string artist , string album , MusicType type)
        {
            MusicPath = music;
            ArtistImagePath = artist;
            AlbumImagePath = album;
            Type = type;
        }
    }

    /// <summary>
    /// 音乐集
    /// </summary>
    [Serializable]
    public class MusicBook
    {
        /// <summary>
        /// 音乐集合地址
        /// </summary>
        public string ImagePath;
        /// <summary>
        /// 音乐集合名字
        /// </summary>
        public string Name;
        /// <summary>
        /// 包含的音乐
        /// </summary>
        public List<BookMusicDetials> ContainMusics;

        public string ID = string.Empty;

        public MusicBook()
        {
            ImagePath = string.Empty;
            Name = string.Empty;
            ContainMusics = null;
        }

        /// <summary>
        /// 音乐集
        /// </summary>
        /// <param name="image">音乐集图片地址</param>
        /// <param name="name">音乐集名字</param>
        /// <param name="contain">音乐集内包含的音乐</param>
        /// <param name="id">音乐集的唯一ID</param>
        public MusicBook(string image , string name , List<BookMusicDetials> contain , string id)
        {
            ImagePath = image;
            Name = name;
            ContainMusics = contain;
            ID = id;
        }
    }

    public class DownloadToLocalIDS
    {
        public const string RootNodeName = "RootNode";
        public const string IDAndPathCollectionName = "IAPC";
        public const string IDName = "ID";
        public const string PathName = "Path";

        /// <summary>
        /// 网易云下载到本地的音乐ID集合 ， key 为 ID ， value 为 本地音乐的path
        /// </summary>
        public Dictionary<string , string> NetIDS = null;
        /// <summary>
        /// cloud 下载到本地的音乐ID集合 ， key 为 ID ， value 为 本地音乐的path
        /// <para>cloud id 为了和 net id 区别 ， 取用5提取出来的 长度为 32 的16进制字符串作为ID</para>
        /// </summary>
        public Dictionary<string , string> CloudIDS = null;

        public DownloadToLocalIDS()
        {
            ReadADictionary(out NetIDS , FileStruct.TotalDownLoadToLocalNetMusicIDFileName);
            ReadADictionary(out CloudIDS , FileStruct.TotalDownLoadToLocalCloudMusicIDFileName);
        }

        private void ReadADictionary(out Dictionary<string, string> collection , string path)
        {
            FileInfo checkExist = new FileInfo(FileStruct.TotalDownLoadToLocalNetMusicIDFileName);

            collection = new Dictionary<string, string>();

            //网易云下载音乐ID
            //之前存在记录的话则反序列化
            if (checkExist.Exists)
            {
                XmlDocument doc = new XmlDocument();
                XmlNode rootNode = null;

                //加载xml文档
                doc.Load(path);

                //获取根节点
                rootNode = doc.SelectSingleNode(RootNodeName);

                //获取所有集合值
                foreach (XmlNode node in rootNode.ChildNodes)
                {
                    if(node.Name == IDAndPathCollectionName)
                    {
                        string id = node.SelectSingleNode(IDName).InnerText;
                        string musicPath = node.SelectSingleNode(PathName).InnerText;

                        collection.Add(id, musicPath);
                    }
                }
            }
        }

        private void SaveADictionary(Dictionary<string, string> collection, string path)
        {
            XElement doc = new XElement(RootNodeName);

            var collectionsNode = from iapc in collection
                                  select new XElement(IDAndPathCollectionName, new XElement(IDName, iapc.Key), new XElement(PathName, iapc.Value));

            doc.Add(collectionsNode);

            doc.Save(path);
        }

        public void SaveToLocal()
        {
            SaveADictionary(NetIDS, FileStruct.TotalDownLoadToLocalNetMusicIDFileName);
            SaveADictionary(CloudIDS, FileStruct.TotalDownLoadToLocalCloudMusicIDFileName);
        }
    }

    public class TotalBooksControl
    {
        public List<MusicBook> TotalBooks = null;

        public TotalBooksControl()
        {
            FileInfo checkExist = new FileInfo(FileStruct.MusicBookTotalFileName);

            //之前存在记录的话则反序列化
            if (checkExist.Exists)
            {
                XmlSerializer xmlFormat = new XmlSerializer(typeof(List<MusicBook>));
                using (Stream fStream = new FileStream(FileStruct.MusicBookTotalFileName
                    , FileMode.Open, FileAccess.ReadWrite))
                {
                    TotalBooks = (List<MusicBook>)xmlFormat.Deserialize(fStream);
                }
            }
            //之前不存在记录的话，则直接初始化
            else
            {
                TotalBooks = new List<MusicBook>();
            }
        }

        /// <summary>
        /// 保存到本地
        /// </summary>
        public void SavToLocal()
        {
            XmlSerializer xmlFormat = new XmlSerializer(typeof(List<MusicBook>));
            using (Stream fStream = new FileStream(FileStruct.MusicBookTotalFileName
                , FileMode.Create, FileAccess.ReadWrite))
            {
                xmlFormat.Serialize(fStream , TotalBooks);
            }
        }
    }

    public class DefaultBookControl
    {
        public MusicBook Default = null;

        public DefaultBookControl()
        {
            FileInfo checkExist = new FileInfo(FileStruct.MusicDefaultBookFileName);

            //之前存在记录的话则反序列化
            if (checkExist.Exists)
            {
                XmlSerializer xmlFormat = new XmlSerializer(typeof(MusicBook));
                using (Stream fStream = new FileStream(FileStruct.MusicDefaultBookFileName
                    , FileMode.Open, FileAccess.ReadWrite))
                {
                    Default = (MusicBook)xmlFormat.Deserialize(fStream);
                }
            }
            //之前不存在记录的话，则直接初始化
            else
            {
                throw new Exception("Default Book Lost");
            }
        }

        /// <summary>
        /// 保存到本地
        /// </summary>
        public void SavToLocal()
        {
            XmlSerializer xmlFormat = new XmlSerializer(typeof(MusicBook));
            using (Stream fStream = new FileStream(FileStruct.MusicDefaultBookFileName
                , FileMode.Create, FileAccess.ReadWrite))
            {
                xmlFormat.Serialize(fStream, Default);
            }
        }
    }

    public static class UnityString
    {
        /// <summary>
        /// 使用MD5 Hash 算法转化输入字符为 32 位字符串
        /// </summary>
        /// <param name="input">需要转化的字符串</param>
        /// <returns>转化的字符串</returns>
        public static string UseMD5(string input)
        {
            MD5 md5Hasher = MD5.Create();
            byte[] data = md5Hasher.ComputeHash(Encoding.UTF8.GetBytes(input));

            StringBuilder sBuilder = new StringBuilder();
            //将每个字节转为16进制
            for (int i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }

            return sBuilder.ToString();
        }

        public static string DecryptString(string input, string sKey)
        {
            string[] sInput = input.Split("-".ToCharArray());
            byte[] data = new byte[sInput.Length];

            for (int i = 0; i < sInput.Length; i++)
            {
                data[i] = byte.Parse(sInput[i], System.Globalization.NumberStyles.HexNumber);
            }

            using (DESCryptoServiceProvider des = new DESCryptoServiceProvider())
            {
                des.Key = ASCIIEncoding.ASCII.GetBytes(sKey);
                des.IV = ASCIIEncoding.ASCII.GetBytes(sKey);
                ICryptoTransform desencrypt = des.CreateDecryptor();
                byte[] result = desencrypt.TransformFinalBlock(data, 0, data.Length);
                return Encoding.UTF8.GetString(result);
            }
        }

        /// <summary>
        /// 加密字符串
        /// </summary>
        /// <param name="input"></param>
        /// <param name="sKey"></param>
        /// <returns></returns>
        public static string EncryptString(string input, string sKey)
        {
            byte[] data = Encoding.UTF8.GetBytes(input);
            using (DESCryptoServiceProvider des = new DESCryptoServiceProvider())
            {
                des.Key = ASCIIEncoding.ASCII.GetBytes(sKey);
                des.IV = ASCIIEncoding.ASCII.GetBytes(sKey);
                ICryptoTransform desencrypt = des.CreateEncryptor();
                byte[] result = desencrypt.TransformFinalBlock(data, 0, data.Length);
                return BitConverter.ToString(result);
            }
        }
    }

}
